---
name: release
description: >
  Cut a release of Alexandria. Verifies version consistency, checks
  CHANGELOG, runs the build standard, tags, and pushes to trigger the release
  workflow. Use when asked to "release", "cut a release", "tag a release",
  or "ship a version".
requires:
  adherence: high
  reasoning: low
  precision: high
  volume: low
---

# Release

Cut a release of Alexandria. This skill verifies everything is ready,
then tags and pushes to trigger the CI release workflow.

## Prerequisites

The release workflow (`.github/workflows/release.yml`) handles the actual build:
tarball packaging, Alexandria deployment to sociotechnica.org, and GitHub Release
creation. This skill just ensures the repo is ready and pulls the trigger.

## Steps

### Step 1: Pre-flight checks

Run these checks and stop if any fail:

```bash
# 1. Clean working tree
git status --porcelain

# 2. On main branch
git branch --show-current

# 3. Up to date with remote
git fetch origin main
git diff HEAD origin/main --stat

# 4. Version files in sync
VERSION=$(cat VERSION | tr -d '[:space:]')
PKG_VERSION=$(node -e "process.stdout.write(JSON.parse(require('fs').readFileSync('package.json','utf8')).version)")
PLUGIN_VERSION=$(node -e "process.stdout.write(JSON.parse(require('fs').readFileSync('.claude-plugin/plugin.json','utf8')).version)")
# All three must match

# 5. CHANGELOG has an entry for this version
grep -q "\[$VERSION\]" CHANGELOG.md

# 6. Tag doesn't already exist
git tag -l "v$VERSION"

# 7. Build standard passes
bun run check
bun test
```

Report each check as pass/fail. If any fail, tell the user what to fix and stop.

### Step 2: Confirm with user

Show the user:
- Version being released (from VERSION file)
- CHANGELOG entry for this version
- Number of commits since last tag (or since repo start if no tags)
- Any open PRs targeting main

Ask for explicit confirmation before proceeding.

### Step 3: Tag and push

```bash
VERSION=$(cat VERSION | tr -d '[:space:]')
git tag "v$VERSION"
git push origin "v$VERSION"
```

### Step 4: Monitor release workflow

```bash
# Wait for the workflow to start
sleep 10

# Find the release workflow run
gh run list --workflow=release.yml --limit 1

# Watch it
gh run watch <run-id>
```

Report the status of each job:
- `build-release` — builds tarball, runs checks
- `publish-alexandria` — deploys to sociotechnica.org/alexandria/
- `create-github-release` — creates GitHub Release with tarball

### Step 5: Verify deployment

After the workflow completes successfully:

```bash
# Check GitHub Release exists
gh release view "v$VERSION"

# Check Alexandria deployment (may take a minute for Netlify)
curl -fsSL "https://sociotechnica.org/alexandria/latest-version.txt"
```

Report:
- GitHub Release URL
- Whether `latest-version.txt` returns the correct version
- The curl install command users should run:
  `curl -fsSL https://sociotechnica.org/alexandria/install.sh | bash`

### Step 6: Post-release

Remind the user:
- If this is a significant release, announce it
- The next development cycle should bump VERSION for the next release
- Any deferred items from the completed plan should be tracked
