---
requires:
  adherence: low
  reasoning: low
  precision: low
  volume: low
---

# Play Protocol

Shared conventions for all agents executing plays. Load this when starting any multi-step
job or coordinated team motion.

## Completion Status

Every job or play ends with one of these statuses. Report it explicitly.

| Status | Meaning | What Happens Next |
|--------|---------|-------------------|
| DONE | Completed successfully. All gates passed. | Next play in the lifecycle can proceed. |
| DONE_WITH_CONCERNS | Completed, but something is off. Not blocking. | Next play can proceed. Concerns logged for human review. |
| BLOCKED | Cannot proceed. Missing input, unresolvable conflict, or quality gate failed. | Human decides: fix the blocker and retry, or skip with documented rationale. |
| NEEDS_CONTEXT | Insufficient information to execute. Not a failure — a request. | Human provides the missing context. Play resumes. |

When in doubt between DONE and DONE_WITH_CONCERNS, choose DONE_WITH_CONCERNS and log
the concern. False negatives (missed concerns) are worse than false positives.

## Shared Preamble

Before starting any job, orient yourself:

1. **Read the library README** (`docs/alexandria/README.md`) if you haven't this
   session — understand the library's current state and structure.
2. **Check the feedback queue** (`docs/alexandria/feedback-queue.jsonl`) for items
   relevant to your task — prior assemblies may have surfaced gaps or weak cards that
   affect your work.
3. **Note active concerns** from prior plays — if a previous play exited
   DONE_WITH_CONCERNS, check whether your work is affected by or can address those
   concerns.

This is not a formality. Agents working without orientation produce context-free output.

## Downstream Sync Rule

After completing ANY job that changes library structure (new cards, renames, folder changes,
type changes, bulk creation/deletion, template changes):

1. Conan runs Job 9 (Downstream Sync) — verifies and fixes meta-files
2. Nit runs Sweep 6 (path resolution) — catches broken references

This is mandatory. Do not wait for the human to ask.

## Interrupt-Driven Usage

The lifecycle runs Genesis → Construction → Quality → Service → Maintenance → Evolution,
but real usage is interrupt-driven. A founder builds 10 cards, needs a briefing tomorrow,
goes back to building.

- Later-stage plays can be invoked before earlier stages complete
- They just produce more DONE_WITH_CONCERNS exits
- Bridget must assemble from incomplete libraries and be honest about what's missing
- This is by design, not a failure mode

## Model Discipline

Agent definitions specify their model in frontmatter (`model: sonnet` or `model: opus`). However,
when an Opus orchestrator launches agents via the Agent tool, the frontmatter model does **not**
flow through automatically. The orchestrator must pass the model explicitly on every
Agent tool call — consult the table below for the correct value.

**Default model assignments:**

| Agent | Model | Rationale |
|-------|-------|-----------|
| Raven | sonnet | Runs well on sonnet; opus is a boost, not a requirement |
| Solomon | opus | Eval-tested: triage quality degrades on sonnet |
| Conan | sonnet | Grading and surgery planning follow defined rubrics |
| Sam | sonnet | Executes surgery plans and build instructions |
| Nit | sonnet | Mechanical sweeps with boolean checks |
| Bridget | sonnet | Assembly follows retrieval profiles |

**Rule:** If you are orchestrating a multi-agent play, pass the model explicitly. Do not rely on
defaults. The cost difference between opus and sonnet is significant, and most agent work is
execution, not reasoning.

## Playbook Reference

The full play definitions live in `docs/design/playbook.md`. When executing a specific
play, load it from there for the complete step-by-step sequence, agent assignments, and
exit criteria.
