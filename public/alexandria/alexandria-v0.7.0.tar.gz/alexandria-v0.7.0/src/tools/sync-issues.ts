/**
 * Alexandria — Filesystem-to-GitHub Issue Sync
 *
 * Reads ticket markdown files from a plan directory (docs/alexandria/plans/<feature>/tickets/*.md),
 * parses YAML frontmatter, and creates GitHub issues so Symphony can execute them.
 * The filesystem plan remains the source of truth; GitHub issues are derived artifacts.
 *
 * Idempotency key: title prefix "[TICKET-ID]". The script searches existing issues
 * (open and closed) before creating a new one. Safe to run multiple times.
 *
 * Usage:
 *   alexandria-sync-issues <plan-dir>
 *   alexandria-sync-issues <plan-dir> --repo owner/repo
 *   alexandria-sync-issues <plan-dir> --dry-run
 *   alexandria-sync-issues <plan-dir> --plan-label plan:release-v0.6
 *   alexandria-sync-issues <plan-dir> --update
 *   alexandria-sync-issues --all [--root docs/alexandria/plans/]
 *
 * Options:
 *   --repo owner/repo    GitHub repository (default: detected from git remote)
 *   --dry-run            Print actions without creating/updating issues
 *   --plan-label <lbl>   Extra label added to all issues
 *   --state open|all     Issue search state (default: all)
 *   --update             Update body of existing issues if ticket content changed
 *   --all                Sync every plan dir found under --root
 *   --root <dir>         Root dir for --all mode (default: docs/alexandria/plans)
 *   -h, --help           Show this help
 */

import { existsSync, readdirSync, statSync } from "fs";
import { join, basename, resolve } from "path";
import { type TicketFrontmatter } from "../lib/frontmatter.js";
import { readMarkdownFile, listMarkdownFiles } from "../lib/markdown.js";

// ── Types ──────────────────────────────────────────────────────────────

interface TicketEntry {
  fm: TicketFrontmatter;
  body: string;
  filepath: string;
}

type SyncStatus = "created" | "exists" | "updated" | "failed" | "error";

interface SyncRow {
  status: SyncStatus;
  ticketId: string;
  msg: string;
}

interface ParsedTicketFile {
  fm: TicketFrontmatter;
  body: string;
}

interface IssueRef {
  number: number;
  id: number;
  title: string;
  body?: string;
}

interface TicketSyncResult {
  status: SyncStatus;
  msg: string;
  issueRef: IssueRef | null;
}

interface DesiredRelationships {
  blockedByTicketIds: string[];
  blocksTicketIds: string[];
}

interface RelationshipDelta {
  addBlockedBy: IssueRef[];
  removeBlockedBy: IssueRef[];
  addBlocks: IssueRef[];
  removeBlocks: IssueRef[];
}

// ── Help text ──────────────────────────────────────────────────────────

const HELP_TEXT = `Alexandria — Filesystem-to-GitHub Issue Sync

Reads ticket markdown files from a plan directory (docs/alexandria/plans/<feature>/tickets/*.md),
parses YAML frontmatter, and creates GitHub issues so Symphony can execute them.
The filesystem plan remains the source of truth; GitHub issues are derived artifacts.

Idempotency key: title prefix "[TICKET-ID]". The script searches existing issues
(open and closed) before creating a new one. Safe to run multiple times.

Usage:
  alexandria-sync-issues <plan-dir>
  alexandria-sync-issues <plan-dir> --repo owner/repo
  alexandria-sync-issues <plan-dir> --dry-run
  alexandria-sync-issues <plan-dir> --plan-label plan:release-v0.6
  alexandria-sync-issues <plan-dir> --update
  alexandria-sync-issues --all [--root docs/alexandria/plans/]

Options:
  --repo owner/repo    GitHub repository (default: detected from git remote)
  --dry-run            Print actions without creating/updating issues
  --plan-label <lbl>   Extra label added to all issues
  --state open|all     Issue search state (default: all)
  --update             Update body of existing issues if ticket content changed
  --all                Sync every plan dir found under --root
  --root <dir>         Root dir for --all mode (default: docs/alexandria/plans)
  -h, --help           Show this help`;

// ── Frontmatter compatibility ──────────────────────────────────────────

function hasCompleteFrontmatter(markdown: string): boolean {
  return markdown.startsWith("---") && markdown.indexOf("---", 3) !== -1;
}

function parseLegacyTicket(markdown: string): ParsedTicketFile | null {
  if (!hasCompleteFrontmatter(markdown)) {
    return null;
  }

  const end = markdown.indexOf("---", 3);
  if (end === -1) {
    return null;
  }

  const yamlText = markdown.slice(3, end).trim();
  const body = markdown.slice(end + 3).trim();
  const fm: TicketFrontmatter = {};

  for (const rawLine of yamlText.split("\n")) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) {
      continue;
    }

    const match = line.match(/^([\w-]+)\s*:\s*(.*)$/);
    if (!match) {
      continue;
    }

    const key = match[1];
    const rawValue = match[2];
    if (key == null || rawValue == null) {
      continue;
    }
    const value = rawValue.trim();

    if (value.startsWith("[") && value.endsWith("]")) {
      const items = value.slice(1, -1).trim();
      fm[key] = items
        ? items
            .split(",")
            .map((item) => item.trim().replace(/^['"]|['"]$/g, ""))
        : [];
      continue;
    }

    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      fm[key] = value.slice(1, -1);
      continue;
    }

    if (value.toLowerCase() === "true" || value.toLowerCase() === "false") {
      fm[key] = value.toLowerCase() === "true";
      continue;
    }

    fm[key] = value;
  }

  return { fm, body };
}

// ── Load tickets from plan directory ───────────────────────────────────

function loadTickets(planDir: string): {
  tickets: TicketEntry[];
  errors: string[];
} {
  const tickets: TicketEntry[] = [];
  const errors: string[] = [];

  const ticketsDir = join(planDir, "tickets");
  if (!existsSync(ticketsDir) || !statSync(ticketsDir).isDirectory()) {
    errors.push(`No tickets/ directory found in ${planDir}`);
    return { tickets, errors };
  }

  const files = listMarkdownFiles(ticketsDir);
  for (const fpath of files) {
    const md = readMarkdownFile(fpath);
    if (!md) {
      errors.push(`${basename(fpath)}: could not parse frontmatter`);
      continue;
    }

    if (!hasCompleteFrontmatter(md.content)) {
      errors.push(`${basename(fpath)}: could not parse frontmatter`);
      continue;
    }

    let parsed: ParsedTicketFile = {
      fm: md.frontmatter as TicketFrontmatter,
      body: md.body.trim(),
    };

    if (!parsed.fm.id || !parsed.fm.title) {
      const legacyParsed = parseLegacyTicket(md.content);
      if (legacyParsed) {
        parsed = legacyParsed;
      }
    }

    if (!parsed.fm.id) {
      errors.push(`${basename(fpath)}: missing 'id' in frontmatter`);
      continue;
    }
    if (!parsed.fm.title) {
      errors.push(`${basename(fpath)}: missing 'title' in frontmatter`);
      continue;
    }

    tickets.push({ fm: parsed.fm, body: parsed.body, filepath: fpath });
  }

  return { tickets, errors };
}

// ── Detect GitHub repo from git remote ─────────────────────────────────

function detectRepo(): string | null {
  try {
    const result = Bun.spawnSync(["git", "remote", "get-url", "origin"], {
      stdout: "pipe",
      stderr: "pipe",
    });
    if (result.exitCode !== 0) return null;
    const url = new TextDecoder().decode(result.stdout).trim();

    // Handle SSH: git@github.com:owner/repo.git
    let m = url.match(/^git@github\.com[:/](.+?)(?:\.git)?$/);
    if (m) return m[1]!;

    // Handle HTTPS: https://github.com/owner/repo.git
    m = url.match(/^https?:\/\/github\.com\/(.+?)(?:\.git)?$/);
    if (m) return m[1]!;
  } catch {
    // ignore
  }
  return null;
}

// ── GitHub CLI helpers ─────────────────────────────────────────────────

function gh(
  args: string[],
  options?: { inputText?: string },
): { stdout: string; stderr: string; exitCode: number } {
  const { inputText } = options ?? {};

  try {
    const proc = Bun.spawnSync(["gh", ...args], {
      stdout: "pipe",
      stderr: "pipe",
      stdin: inputText ? new TextEncoder().encode(inputText) : undefined,
    });

    return {
      stdout: new TextDecoder().decode(proc.stdout).trim(),
      stderr: new TextDecoder().decode(proc.stderr).trim(),
      exitCode: proc.exitCode ?? 127,
    };
  } catch {
    return { stdout: "", stderr: "gh: command not found", exitCode: 127 };
  }
}

function checkGh(): void {
  const { exitCode } = gh(["auth", "status"]);
  if (exitCode !== 0) {
    console.error(
      "Error: GitHub CLI (gh) is not installed or not authenticated.",
    );
    console.error("  Install: https://cli.github.com/");
    console.error("  Auth:    gh auth login");
    process.exit(2);
  }
}

function ensureLabels(repo: string, planLabel: string | null): void {
  const needed: Record<string, [string, string]> = {
    "cl-ticket": ["Alexandria filesystem ticket", "0075ca"],
    "tier:must": ["Scope tier: must-have", "d93f0b"],
    "tier:should": ["Scope tier: should-have", "e4e669"],
    "tier:could": ["Scope tier: could-have", "cfd3d7"],
  };
  if (planLabel) {
    needed[planLabel] = ["Release plan label", "5319e7"];
  }

  // Fetch existing labels
  const { stdout: out, exitCode: rc } = gh([
    "label",
    "list",
    "--repo",
    repo,
    "--limit",
    "200",
    "--json",
    "name",
  ]);
  if (rc !== 0) return; // Non-fatal

  let existing: Set<string>;
  try {
    const labels = JSON.parse(out) as Array<{ name: string }>;
    existing = new Set(labels.map((l) => l.name));
  } catch {
    existing = new Set();
  }

  for (const [name, [desc, color]] of Object.entries(needed)) {
    if (!existing.has(name)) {
      gh([
        "label",
        "create",
        "--repo",
        repo,
        name,
        "--description",
        desc,
        "--color",
        color,
      ]);
    }
  }
}

function findExistingIssue(
  repo: string,
  ticketId: string,
  state: string,
): number | null {
  const searchQuery = `[${ticketId}] in:title repo:${repo}`;
  const { stdout: out, exitCode: rc } = gh([
    "issue",
    "list",
    "--repo",
    repo,
    "--search",
    searchQuery,
    "--state",
    state,
    "--limit",
    "10",
    "--json",
    "number,title,state",
  ]);
  if (rc !== 0 || !out) return null;

  let issues: Array<{ number: number; title: string; state: string }>;
  try {
    issues = JSON.parse(out);
  } catch {
    return null;
  }

  const prefix = `[${ticketId}]`;
  for (const issue of issues) {
    if (issue.title?.startsWith(prefix)) {
      return issue.number;
    }
  }
  return null;
}

function getIssueRef(repo: string, issueNumber: number): IssueRef | null {
  const { stdout: out, exitCode: rc } = gh([
    "api",
    `repos/${repo}/issues/${issueNumber}`,
  ]);
  if (rc !== 0 || !out) return null;

  try {
    const issue = JSON.parse(out) as {
      number?: number;
      id?: number;
      title?: string;
      body?: string;
    };
    if (
      typeof issue.number !== "number" ||
      typeof issue.id !== "number" ||
      typeof issue.title !== "string"
    ) {
      return null;
    }
    return {
      number: issue.number,
      id: issue.id,
      title: issue.title,
      body: issue.body ?? "",
    };
  } catch {
    return null;
  }
}

function findExistingIssueRef(
  repo: string,
  ticketId: string,
  state: string,
): IssueRef | null {
  const issueNumber = findExistingIssue(repo, ticketId, state);
  if (issueNumber === null) return null;
  return getIssueRef(repo, issueNumber);
}

function getIssueDependencies(
  repo: string,
  issueNumber: number,
  kind: "blocked_by" | "blocking",
): IssueRef[] | null {
  const { stdout: out, exitCode: rc } = gh([
    "api",
    `repos/${repo}/issues/${issueNumber}/dependencies/${kind}`,
  ]);
  if (rc !== 0 || !out) return null;

  try {
    const issues = JSON.parse(out) as Array<{
      number?: number;
      id?: number;
      title?: string;
      body?: string;
    }>;

    return issues.flatMap((issue) => {
      if (
        typeof issue.number !== "number" ||
        typeof issue.id !== "number" ||
        typeof issue.title !== "string"
      ) {
        return [];
      }

      return [
        {
          number: issue.number,
          id: issue.id,
          title: issue.title,
          ...(typeof issue.body === "string" ? { body: issue.body } : {}),
        },
      ];
    });
  } catch {
    return null;
  }
}

function addBlockedByDependency(
  repo: string,
  issueNumber: number,
  blockerIssueId: number,
): boolean {
  const { exitCode } = gh([
    "api",
    "-X",
    "POST",
    `repos/${repo}/issues/${issueNumber}/dependencies/blocked_by`,
    "-F",
    `issue_id=${blockerIssueId}`,
  ]);
  return exitCode === 0;
}

function removeBlockedByDependency(
  repo: string,
  issueNumber: number,
  blockerIssueId: number,
): boolean {
  const { exitCode } = gh([
    "api",
    "-X",
    "DELETE",
    `repos/${repo}/issues/${issueNumber}/dependencies/blocked_by/${blockerIssueId}`,
  ]);
  return exitCode === 0;
}

// ── Issue body builder ─────────────────────────────────────────────────

function buildIssueTitle(ticketId: string, title: string): string {
  return `[${ticketId}] ${title}`;
}

function toListString(val: unknown): string {
  if (Array.isArray(val)) {
    return val.length > 0 ? val.join(", ") : "(none)";
  }
  if (typeof val === "string") return val || "(none)";
  return "(none)";
}

function toTicketIdArray(val: unknown): string[] {
  if (Array.isArray(val)) {
    return val.filter(
      (item): item is string => typeof item === "string" && item.length > 0,
    );
  }
  if (typeof val === "string" && val.length > 0) {
    return [val];
  }
  return [];
}

function buildIssueBody(
  fm: TicketFrontmatter,
  body: string,
  planName: string,
): string {
  const ticketId = fm.id ?? "";
  const outcome = fm.outcome ?? "—";
  const tier = fm.tier ?? "—";
  const enabler = fm.enabler ? "yes" : "no";
  const blockedByStr = toListString(fm["blocked-by"]);
  const blocksStr = toListString(fm.blocks);
  const cardsStr = toListString(fm.cards);

  const lines = [
    `<!-- cl-ticket: ${ticketId} | plan: ${planName} -->`,
    "",
    `**Plan:** ${planName}  `,
    `**Outcome:** ${outcome} | **Tier:** ${tier} | **Enabler:** ${enabler}  `,
    `**Blocked by:** ${blockedByStr} | **Blocks:** ${blocksStr}  `,
    `**Cards:** ${cardsStr}`,
    "",
    "---",
    "",
  ];

  if (body) {
    lines.push(body);
  }

  return lines.join("\n");
}

function extractIssueNumber(output: string): number | null {
  const match = output.match(/\/issues\/(\d+)/);
  if (!match) return null;

  const issueNumber = Number(match[1]);
  return Number.isFinite(issueNumber) ? issueNumber : null;
}

// ── Sync a single ticket ───────────────────────────────────────────────

function syncTicket(
  fm: TicketFrontmatter,
  body: string,
  planName: string,
  repo: string,
  planLabel: string | null,
  state: string,
  update: boolean,
  dryRun: boolean,
): TicketSyncResult {
  const ticketId = fm.id!;
  const title = fm.title ?? ticketId;
  const tier = fm.tier ?? "could";

  const issueTitle = buildIssueTitle(ticketId, title);
  const issueBody = buildIssueBody(fm, body, planName);

  const labels = ["cl-ticket", `tier:${tier}`];
  if (planLabel) labels.push(planLabel);

  const existing = findExistingIssueRef(repo, ticketId, state);

  if (existing) {
    if (update) {
      if (existing.body === issueBody) {
        return {
          status: "exists",
          msg: `#${existing.number} (body unchanged)`,
          issueRef: existing,
        };
      }
      if (dryRun) {
        return {
          status: "updated",
          msg: `#${existing.number} (dry-run: body would be updated)`,
          issueRef: existing,
        };
      }
      const { stderr: err, exitCode: rc } = gh([
        "issue",
        "edit",
        String(existing.number),
        "--repo",
        repo,
        "--body",
        issueBody,
      ]);
      if (rc !== 0) {
        return {
          status: "failed",
          msg: `#${existing.number}: ${err}`,
          issueRef: existing,
        };
      }
      const refreshed = getIssueRef(repo, existing.number) ?? existing;
      return {
        status: "updated",
        msg: `#${existing.number}`,
        issueRef: refreshed,
      };
    }
    return { status: "exists", msg: `#${existing.number}`, issueRef: existing };
  }

  // Create new issue
  if (dryRun) {
    return {
      status: "created",
      msg: `(dry-run) would create: '${issueTitle}'`,
      issueRef: null,
    };
  }

  const labelArgs: string[] = [];
  for (const lbl of labels) {
    labelArgs.push("--label", lbl);
  }

  const {
    stdout: out,
    stderr: err,
    exitCode: rc,
  } = gh([
    "issue",
    "create",
    "--repo",
    repo,
    "--title",
    issueTitle,
    "--body",
    issueBody,
    ...labelArgs,
  ]);
  if (rc !== 0) {
    return { status: "failed", msg: err, issueRef: null };
  }

  const createdIssueNumber = extractIssueNumber(`${out}\n${err}`);
  const created = createdIssueNumber
    ? getIssueRef(repo, createdIssueNumber)
    : findExistingIssueRef(repo, ticketId, "all");
  if (!created) {
    return {
      status: "failed",
      msg: `created issue for ${ticketId} but could not resolve it for dependency sync`,
      issueRef: null,
    };
  }

  return { status: "created", msg: `#${created.number}`, issueRef: created };
}

function appendRowMessage(row: SyncRow, extra: string): void {
  row.msg = row.msg ? `${row.msg}; ${extra}` : extra;
}

function buildDesiredRelationshipMap(
  tickets: TicketEntry[],
): Map<string, DesiredRelationships> {
  const desired = new Map<
    string,
    { blockedBy: Set<string>; blocks: Set<string> }
  >();

  for (const { fm } of tickets) {
    const ticketId = fm.id!;
    desired.set(ticketId, {
      blockedBy: new Set(
        toTicketIdArray(fm["blocked-by"]).filter(
          (id) => id.length > 0 && id !== ticketId,
        ),
      ),
      blocks: new Set(
        toTicketIdArray(fm.blocks).filter(
          (id) => id.length > 0 && id !== ticketId,
        ),
      ),
    });
  }

  for (const [ticketId, relationships] of desired) {
    for (const depTicketId of relationships.blockedBy) {
      desired.get(depTicketId)?.blocks.add(ticketId);
    }

    for (const depTicketId of relationships.blocks) {
      desired.get(depTicketId)?.blockedBy.add(ticketId);
    }
  }

  return new Map(
    Array.from(desired.entries(), ([ticketId, relationships]) => [
      ticketId,
      {
        blockedByTicketIds: Array.from(relationships.blockedBy).sort(),
        blocksTicketIds: Array.from(relationships.blocks).sort(),
      },
    ]),
  );
}

function resolveTicketIssueRef(
  repo: string,
  ticketId: string,
  state: string,
  issueCache: Map<string, IssueRef | null>,
): IssueRef | null {
  if (issueCache.has(ticketId)) {
    return issueCache.get(ticketId) ?? null;
  }

  const issueRef = findExistingIssueRef(repo, ticketId, state);
  issueCache.set(ticketId, issueRef);
  return issueRef;
}

function formatRelationshipDelta(delta: RelationshipDelta): string {
  const changeParts: string[] = [];
  if (delta.addBlockedBy.length > 0)
    changeParts.push(
      `+blocked-by ${delta.addBlockedBy.map((i) => i.number).join(",")}`,
    );
  if (delta.removeBlockedBy.length > 0)
    changeParts.push(
      `-blocked-by ${delta.removeBlockedBy.map((i) => i.number).join(",")}`,
    );
  if (delta.addBlocks.length > 0)
    changeParts.push(
      `+blocks ${delta.addBlocks.map((i) => i.number).join(",")}`,
    );
  if (delta.removeBlocks.length > 0)
    changeParts.push(
      `-blocks ${delta.removeBlocks.map((i) => i.number).join(",")}`,
    );

  return changeParts.length > 0 ? `relationships ${changeParts.join(" ")}` : "";
}

function syncRelationships(
  desiredRelationships: DesiredRelationships,
  issueRef: IssueRef,
  repo: string,
  state: string,
  issueCache: Map<string, IssueRef | null>,
  dryRun: boolean,
): { ok: boolean; msg: string } {
  const unresolved: string[] = [];
  const desiredBlockedBy = desiredRelationships.blockedByTicketIds.flatMap(
    (depTicketId) => {
      const depIssue = resolveTicketIssueRef(
        repo,
        depTicketId,
        state,
        issueCache,
      );
      if (!depIssue) {
        unresolved.push(`${depTicketId} (blocked-by)`);
        return [];
      }
      return [depIssue];
    },
  );
  const desiredBlocks = desiredRelationships.blocksTicketIds.flatMap(
    (depTicketId) => {
      const depIssue = resolveTicketIssueRef(
        repo,
        depTicketId,
        state,
        issueCache,
      );
      if (!depIssue) {
        unresolved.push(`${depTicketId} (blocks)`);
        return [];
      }
      return [depIssue];
    },
  );

  if (unresolved.length > 0) {
    return {
      ok: false,
      msg: `unresolved dependency tickets: ${unresolved.join(", ")}`,
    };
  }

  const currentBlockedBy = getIssueDependencies(
    repo,
    issueRef.number,
    "blocked_by",
  );
  const currentBlocking = getIssueDependencies(
    repo,
    issueRef.number,
    "blocking",
  );
  if (!currentBlockedBy || !currentBlocking) {
    return {
      ok: false,
      msg: "could not read current GitHub issue dependencies",
    };
  }

  const desiredBlockedByIds = new Set(
    desiredBlockedBy.map((issue) => issue.id),
  );
  const desiredBlocksIds = new Set(desiredBlocks.map((issue) => issue.id));
  const currentBlockedByIds = new Set(
    currentBlockedBy.map((issue) => issue.id),
  );
  const currentBlockingIds = new Set(currentBlocking.map((issue) => issue.id));

  const delta: RelationshipDelta = {
    addBlockedBy: desiredBlockedBy.filter(
      (issue) => !currentBlockedByIds.has(issue.id),
    ),
    removeBlockedBy: currentBlockedBy.filter(
      (issue) => !desiredBlockedByIds.has(issue.id),
    ),
    addBlocks: desiredBlocks.filter(
      (issue) => !currentBlockingIds.has(issue.id),
    ),
    removeBlocks: currentBlocking.filter(
      (issue) => !desiredBlocksIds.has(issue.id),
    ),
  };

  if (dryRun) {
    return { ok: true, msg: formatRelationshipDelta(delta) };
  }

  const failures: string[] = [];

  for (const depIssue of delta.addBlockedBy) {
    if (!addBlockedByDependency(repo, issueRef.number, depIssue.id)) {
      failures.push(`add blocked-by ${depIssue.number}`);
    }
  }

  for (const depIssue of delta.removeBlockedBy) {
    if (!removeBlockedByDependency(repo, issueRef.number, depIssue.id)) {
      failures.push(`remove blocked-by ${depIssue.number}`);
    }
  }

  for (const depIssue of delta.addBlocks) {
    if (!addBlockedByDependency(repo, depIssue.number, issueRef.id)) {
      failures.push(`add blocks ${depIssue.number}`);
    }
  }

  for (const depIssue of delta.removeBlocks) {
    if (!removeBlockedByDependency(repo, depIssue.number, issueRef.id)) {
      failures.push(`remove blocks ${depIssue.number}`);
    }
  }

  if (failures.length > 0) {
    return { ok: false, msg: failures.join(", ") };
  }

  return { ok: true, msg: formatRelationshipDelta(delta) };
}

// ── Sync a plan directory ──────────────────────────────────────────────

function syncPlanDir(
  planDir: string,
  repo: string,
  planLabel: string | null,
  state: string,
  update: boolean,
  dryRun: boolean,
): { rows: SyncRow[]; planName: string } {
  const planName = basename(resolve(planDir));
  const { tickets, errors } = loadTickets(planDir);
  const desiredRelationshipMap = buildDesiredRelationshipMap(tickets);

  const rows: SyncRow[] = [];
  const rowByTicketId = new Map<string, SyncRow>();
  const issueCache = new Map<string, IssueRef | null>();

  for (const err of errors) {
    rows.push({ status: "error", ticketId: err, msg: "" });
  }

  for (const { fm, body } of tickets) {
    const ticketId = fm.id!;
    const { status, msg, issueRef } = syncTicket(
      fm,
      body,
      planName,
      repo,
      planLabel,
      state,
      update,
      dryRun,
    );
    const row = { status, ticketId, msg };
    rows.push(row);
    rowByTicketId.set(ticketId, row);
    if (issueRef) {
      issueCache.set(ticketId, issueRef);
    }
  }

  for (const { fm } of tickets) {
    const ticketId = fm.id!;
    const desiredRelationships = desiredRelationshipMap.get(ticketId);
    if (
      !desiredRelationships ||
      (desiredRelationships.blockedByTicketIds.length === 0 &&
        desiredRelationships.blocksTicketIds.length === 0)
    ) {
      continue;
    }

    const row = rowByTicketId.get(ticketId);
    const issueRef = issueCache.get(ticketId);
    if (
      !row ||
      row.status === "failed" ||
      row.status === "error" ||
      !issueRef
    ) {
      continue;
    }

    const result = syncRelationships(
      desiredRelationships,
      issueRef,
      repo,
      state,
      issueCache,
      dryRun,
    );
    if (!result.ok) {
      row.status = "failed";
      appendRowMessage(row, result.msg);
    } else if (result.msg) {
      appendRowMessage(row, result.msg);
    }
  }

  return { rows, planName };
}

// ── Find all plan dirs under a root ────────────────────────────────────

function findPlanDirs(root: string): string[] {
  const dirs: string[] = [];
  if (!existsSync(root) || !statSync(root).isDirectory()) return dirs;

  for (const name of readdirSync(root).sort()) {
    const candidate = join(root, name);
    try {
      const ticketsDir = join(candidate, "tickets");
      if (
        statSync(candidate).isDirectory() &&
        statSync(ticketsDir).isDirectory()
      ) {
        dirs.push(candidate);
      }
    } catch {
      // skip
    }
  }
  return dirs;
}

// ── Output ─────────────────────────────────────────────────────────────

const STATUS_ICON: Record<SyncStatus, string> = {
  created: "+",
  exists: "=",
  updated: "~",
  failed: "!",
  error: "E",
};

function printReport(
  planName: string,
  rows: SyncRow[],
  dryRun: boolean,
): Record<SyncStatus, number> {
  const prefix = dryRun ? "[dry-run] " : "";
  console.log(`\n${prefix}Plan: ${planName}`);

  const counts: Record<SyncStatus, number> = {
    created: 0,
    exists: 0,
    updated: 0,
    failed: 0,
    error: 0,
  };

  for (const { status, ticketId, msg } of rows) {
    const icon = STATUS_ICON[status] ?? "?";
    counts[status]++;
    console.log(`  [${icon}] ${ticketId}  ${msg}`);
  }

  const summaryParts: string[] = [];
  if (counts.created) summaryParts.push(`${counts.created} created`);
  if (counts.exists) summaryParts.push(`${counts.exists} already exist`);
  if (counts.updated) summaryParts.push(`${counts.updated} updated`);
  if (counts.failed) summaryParts.push(`${counts.failed} failed`);
  if (counts.error) summaryParts.push(`${counts.error} parse errors`);
  console.log(`  → ${summaryParts.join(", ") || "nothing to do"}`);

  return counts;
}

// ── Main ───────────────────────────────────────────────────────────────

function main(): void {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === "-h" || args[0] === "--help") {
    console.log(HELP_TEXT);
    process.exit(0);
  }

  // Parse flags
  const planDirsArg: string[] = [];
  let repo: string | null = null;
  let dryRun = false;
  let planLabel: string | null = null;
  let state = "all";
  let update = false;
  let allMode = false;
  let root: string | null = null;

  let i = 0;
  while (i < args.length) {
    const a = args[i]!;
    if (a === "--dry-run") {
      dryRun = true;
    } else if (a === "--update") {
      update = true;
    } else if (a === "--all") {
      allMode = true;
    } else if (a === "--repo") {
      i++;
      if (i >= args.length) {
        console.error("Error: --repo requires a value");
        process.exit(2);
      }
      repo = args[i]!;
    } else if (a === "--plan-label") {
      i++;
      if (i >= args.length) {
        console.error("Error: --plan-label requires a value");
        process.exit(2);
      }
      planLabel = args[i]!;
    } else if (a === "--state") {
      i++;
      if (i >= args.length) {
        console.error("Error: --state requires a value");
        process.exit(2);
      }
      state = args[i]!;
      if (!["open", "closed", "all"].includes(state)) {
        console.error("Error: --state must be open, closed, or all");
        process.exit(2);
      }
    } else if (a === "--root") {
      i++;
      if (i >= args.length) {
        console.error("Error: --root requires a value");
        process.exit(2);
      }
      root = args[i]!;
    } else if (a.startsWith("--")) {
      console.error(`Error: unknown flag: ${a}`);
      process.exit(2);
    } else {
      planDirsArg.push(a);
    }
    i++;
  }

  if (!allMode && planDirsArg.length === 0) {
    console.error("Error: provide a plan directory or use --all");
    console.error("Usage: alexandria-sync-issues <plan-dir> [--dry-run]");
    process.exit(2);
  }

  // Resolve repo
  if (!repo) {
    repo = detectRepo();
  }
  if (!repo) {
    console.error("Error: could not detect GitHub repo from git remote.");
    console.error("  Use --repo owner/repo to specify explicitly.");
    process.exit(2);
  }

  // Check gh (skip in pure dry-run if gh unavailable — allow offline testing)
  if (!dryRun) {
    checkGh();
  }

  // Resolve plan directories
  let planDirs: string[];
  if (allMode) {
    const resolvedRoot = root ?? "docs/alexandria/plans";
    planDirs = findPlanDirs(resolvedRoot);
    if (planDirs.length === 0) {
      console.log(
        `No plan directories with tickets/ found under ${resolvedRoot}`,
      );
      process.exit(0);
    }
  } else {
    planDirs = planDirsArg;
    for (const d of planDirs) {
      if (!existsSync(d) || !statSync(d).isDirectory()) {
        console.error(`Error: ${d} is not a directory`);
        process.exit(2);
      }
    }
  }

  // Ensure labels exist (best-effort)
  if (!dryRun) {
    ensureLabels(repo, planLabel);
  }

  // Sync each plan dir
  let anyFailed = false;
  for (const planDir of planDirs) {
    const { rows, planName } = syncPlanDir(
      planDir,
      repo,
      planLabel,
      state,
      update,
      dryRun,
    );
    const counts = printReport(planName, rows, dryRun);
    if (counts.failed > 0 || counts.error > 0) {
      anyFailed = true;
    }
  }

  if (dryRun) {
    process.exit(3);
  }
  process.exit(anyFailed ? 1 : 0);
}

main();
