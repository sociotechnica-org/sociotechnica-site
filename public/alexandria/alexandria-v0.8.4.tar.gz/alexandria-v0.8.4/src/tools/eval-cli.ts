/**
 * Alexandria — Eval CLI
 *
 * A comprehensive CLI for managing, running, and reporting on skill evals.
 *
 * Usage:
 *   alexandria-eval list                      # list available eval cases
 *   alexandria-eval status                    # show last run info + staleness
 *   alexandria-eval run <skill>/<case>        # run one eval (background)
 *   alexandria-eval run <skill>/all           # run all cases for a skill
 *   alexandria-eval run all                   # run everything
 *   alexandria-eval run all --parallel        # run all in parallel
 *   alexandria-eval results <skill>/<case>    # show results from last run
 *   alexandria-eval running                   # list currently running evals
 *   alexandria-eval compare <skill>/<case>    # compare current vs baseline
 *   alexandria-eval history <skill>/<case>    # show run history
 */

import {
  readdirSync,
  readFileSync,
  existsSync,
  mkdirSync,
  writeFileSync,
  unlinkSync,
  openSync,
  closeSync,
} from "fs";
import { statSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import { execSync } from "child_process";
import { createHash } from "crypto";
import { resolveBunExecutable } from "../lib/bun-runtime.js";
import { resolvePluginRoot } from "../lib/plugin-paths.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const ROOT_DIR = resolvePluginRoot(process.env, __dirname);
const EVAL_CASES_DIR = join(ROOT_DIR, "tests", "eval-cases");
const EVAL_RESULTS_DIR = join(ROOT_DIR, "tests", "evals");
const BUN_EXECUTABLE = resolveBunExecutable(process.execPath);
const EVAL_HARNESS = join(ROOT_DIR, "src", "tools", "eval-harness.ts");
const PID_DIR = join(ROOT_DIR, ".eval-runs");

const VERSION = existsSync(join(ROOT_DIR, "VERSION"))
  ? readFileSync(join(ROOT_DIR, "VERSION"), "utf-8").trim()
  : "unknown";

// ─────────────────────────────────────────────
// Terminal formatting helpers
// ─────────────────────────────────────────────

function bold(s: string): string {
  return `\x1b[1m${s}\x1b[0m`;
}
function green(s: string): string {
  return `\x1b[32m${s}\x1b[0m`;
}
function red(s: string): string {
  return `\x1b[31m${s}\x1b[0m`;
}
function dim(s: string): string {
  return `\x1b[2m${s}\x1b[0m`;
}

// ─────────────────────────────────────────────
// Filesystem helpers
// ─────────────────────────────────────────────

function isDir(p: string): boolean {
  try {
    return statSync(p).isDirectory();
  } catch {
    return false;
  }
}

function isFile(p: string): boolean {
  try {
    return statSync(p).isFile();
  } catch {
    return false;
  }
}

function listDirs(p: string): string[] {
  if (!isDir(p)) return [];
  return readdirSync(p).filter((name) => isDir(join(p, name)));
}

function readJson(p: string): Record<string, unknown> | null {
  try {
    const content = readFileSync(p, "utf-8");
    return JSON.parse(content) as Record<string, unknown>;
  } catch {
    return null;
  }
}

function pad(s: string, width: number): string {
  if (s.length >= width) return s;
  return s + " ".repeat(width - s.length);
}

// Pad accounting for invisible ANSI escape sequences
function padAnsi(s: string, width: number): string {
  // Strip ANSI codes to measure visible length
  const visible = s.replace(/\x1b\[[0-9;]*m/g, "");
  const diff = width - visible.length;
  if (diff <= 0) return s;
  return s + " ".repeat(diff);
}

// ─────────────────────────────────────────────
// list — show available eval cases
// ─────────────────────────────────────────────

function cmdList(): void {
  process.stdout.write("\n");
  process.stdout.write(bold("Available Eval Cases") + "\n");
  process.stdout.write("═══════════════════════════════════════════\n");
  process.stdout.write("\n");

  if (!isDir(EVAL_CASES_DIR)) {
    process.stdout.write("  No eval cases directory found.\n");
    return;
  }

  for (const skillName of listDirs(EVAL_CASES_DIR)) {
    if (skillName === "_smoke-test") continue;

    const skillDir = join(EVAL_CASES_DIR, skillName);
    const hasJudge = isFile(join(skillDir, "judge-criteria.json")) ? "✓" : "—";
    const hasStructural = isFile(join(skillDir, "structural-checks.ts"))
      ? "✓"
      : "—";

    process.stdout.write(
      bold(`  ${skillName}`) +
        `  (judge: ${hasJudge}  structural: ${hasStructural})\n`,
    );

    for (const caseName of listDirs(skillDir)) {
      if (caseName === "calibration" || caseName === "personas") continue;

      const caseDir = join(skillDir, caseName);

      let mode = "single";
      if (isFile(join(caseDir, "persona.md"))) {
        mode = "adaptive";
      } else {
        try {
          const inputs = readFileSync(join(caseDir, "inputs.md"), "utf-8");
          if (inputs.includes("## Turn")) mode = "multi-turn";
        } catch {
          // no inputs.md
        }
      }

      let maxTurns = "";
      if (mode === "adaptive") {
        const cfg = readJson(join(caseDir, "config.json"));
        const turns = cfg?.["max_turns"] ?? "?";
        maxTurns = ` (max ${turns} turns)`;
      }

      process.stdout.write(`    ${caseName}  ${dim(`[${mode}${maxTurns}]`)}\n`);
    }
    process.stdout.write("\n");
  }
}

// ─────────────────────────────────────────────
// status — show last run info + staleness
// ─────────────────────────────────────────────

function parseJudgeScore(d: Record<string, unknown>): {
  display: string;
  isPerfect: boolean;
} {
  if ("pass_count" in d) {
    const p = d["pass_count"];
    const t = d["total"];
    return { display: `${p}/${t}`, isPerfect: p === t };
  }
  if ("weighted_score" in d) {
    const s = d["weighted_score"];
    const m = d["max_score"];
    return { display: `${s}/${m}`, isPerfect: s === m };
  }
  if ("scores" in d || "level_counts" in d) {
    const lc = (d["level_counts"] ?? d["scores"] ?? {}) as Record<
      string,
      number
    >;
    const t = Object.values(lc).reduce((a, b) => a + b, 0);
    const top = (lc["excellent"] ?? 0) + (lc["good"] ?? 0);
    const bad = (lc["weak"] ?? 0) + (lc["poor"] ?? 0);
    return { display: `${top}/${t}`, isPerfect: bad === 0 };
  }
  return { display: "?/?", isPerfect: false };
}

function cmdStatus(): void {
  process.stdout.write("\n");
  process.stdout.write(bold(`Eval Status (v${VERSION})`) + "\n");
  process.stdout.write("═══════════════════════════════════════════\n");
  process.stdout.write("\n");

  process.stdout.write(
    `  ${pad("CASE", 35)} ${pad("STRUCTURAL", 12)} ${pad("JUDGE", 10)} ${pad("STALE?", 8)} LAST RUN\n`,
  );
  process.stdout.write(
    `  ${pad("---", 35)} ${pad("---", 12)} ${pad("---", 10)} ${pad("---", 8)} ---\n`,
  );

  if (!isDir(EVAL_CASES_DIR)) return;

  for (const skillName of listDirs(EVAL_CASES_DIR)) {
    if (skillName === "_smoke-test") continue;
    const skillDir = join(EVAL_CASES_DIR, skillName);

    for (const caseName of listDirs(skillDir)) {
      if (caseName === "calibration" || caseName === "personas") continue;

      const casePath = `${skillName}/${caseName}`;
      const resultDir = join(EVAL_RESULTS_DIR, skillName, caseName);
      const metaFile = join(resultDir, "run-metadata.json");

      if (!isFile(metaFile)) {
        process.stdout.write(
          `  ${pad(casePath, 35)} ${pad("—", 12)} ${pad("—", 10)} ${padAnsi(red("NEVER"), 8)} no baseline\n`,
        );
        continue;
      }

      const meta = readJson(metaFile) ?? {};
      const runDate = ((meta["timestamp"] as string | undefined) ?? "?").slice(
        0,
        10,
      );
      const runVersion = (meta["version"] as string | undefined) ?? "?";
      const skillHashBaseline =
        (meta["skill_hash"] as string | undefined) ?? "?";

      // Check staleness
      const skillFile = join(ROOT_DIR, "skills", skillName, "SKILL.md");
      let currentHash = "unknown";
      if (isFile(skillFile)) {
        try {
          const content = readFileSync(skillFile);
          currentHash = createHash("sha1").update(content).digest("hex");
        } catch {
          // ignore
        }
      }

      let staleFlag: string;
      if (skillHashBaseline === currentHash) {
        staleFlag = green("OK");
      } else if (skillHashBaseline === "none" || currentHash === "unknown") {
        staleFlag = dim("?");
      } else {
        staleFlag = red("STALE");
      }

      // Structural results
      let structural = "—";
      const structFile = join(resultDir, "structural-results.json");
      if (isFile(structFile)) {
        const sd = readJson(structFile) ?? {};
        const sPass = (sd["pass_count"] ?? sd["passed"] ?? "?") as
          | string
          | number;
        const sTotal = (sd["total"] ?? sd["total_count"] ?? "?") as
          | string
          | number;
        const structStr = `${sPass}/${sTotal}`;
        structural = sPass === sTotal ? green(structStr) : red(structStr);
      }

      // Judge results
      let judge = "—";
      const judgeFile = join(resultDir, "judge-results.json");
      if (isFile(judgeFile)) {
        const jd = readJson(judgeFile) ?? {};
        const { display, isPerfect } = parseJudgeScore(jd);
        judge = isPerfect ? green(display) : red(display);
      }

      process.stdout.write(
        `  ${pad(casePath, 35)} ${padAnsi(structural, 12)} ${padAnsi(judge, 10)} ${padAnsi(staleFlag, 8)} ${runDate} (v${runVersion})\n`,
      );
    }
  }
  process.stdout.write("\n");
}

// ─────────────────────────────────────────────
// run — execute eval(s)
// ─────────────────────────────────────────────

// Spawn ourselves as a background coordinator that waits for the eval runner,
// cleans up the PID file, and prints [DONE]/[FAIL]. The coordinator keeps its
// own event loop alive while the eval runner runs, so the parent can exit
// immediately (fire-and-forget), matching the original bash `_run_single &`
// semantics.
function runSingle(casePath: string): void {
  mkdirSync(PID_DIR, { recursive: true });

  const wrapper = Bun.spawn(
    [BUN_EXECUTABLE, "run", __filename, "_run-single", casePath],
    {
      stdout: "inherit",
      stderr: "inherit",
      stdin: "ignore",
    },
  );
  wrapper.unref();
}

// ─────────────────────────────────────────────
// _run-single — internal background coordinator
// Not a public command; spawned by runSingle().
// Runs the eval, waits for it, cleans up the PID file, prints [DONE]/[FAIL].
// ─────────────────────────────────────────────

async function cmdRunSingleInternal(casePath: string): Promise<void> {
  mkdirSync(PID_DIR, { recursive: true });

  const safeName = casePath.replace(/\//g, "_");
  const pidFile = join(PID_DIR, `${safeName}.pid`);
  const logFile = join(PID_DIR, `${safeName}.log`);

  // Open the log file once; share the fd for both stdout and stderr so
  // they interleave into a single file rather than competing via two
  // independent BunFile handles.
  const logFd = openSync(logFile, "w");
  const proc = Bun.spawn([BUN_EXECUTABLE, "run", EVAL_HARNESS, casePath], {
    stdout: logFd,
    stderr: logFd,
  });
  // Parent can close its copy of the fd after spawning.
  closeSync(logFd);

  writeFileSync(pidFile, String(proc.pid));

  // Wait for the eval runner to finish (no unref — the event loop must stay
  // alive so this coordinator can report results and clean up).
  const exitCode = await proc.exited;
  try {
    unlinkSync(pidFile);
  } catch {
    // already gone
  }
  if (exitCode === 0) {
    process.stdout.write(`[DONE] ${casePath} — see ${logFile}\n`);
  } else {
    process.stdout.write(
      `[FAIL] ${casePath} (exit ${exitCode}) — see ${logFile}\n`,
    );
  }
}

function cmdRun(args: string[]): void {
  const target = args[0] ?? "";
  const parallel = args.includes("--parallel");

  if (!target) {
    process.stdout.write(
      "Usage: alexandria-eval run <skill>/<case> | <skill>/all | all [--parallel]\n",
    );
    process.exit(1);
  }

  mkdirSync(PID_DIR, { recursive: true });

  if (target === "all") {
    const cases: string[] = [];
    if (isDir(EVAL_CASES_DIR)) {
      for (const skillName of listDirs(EVAL_CASES_DIR)) {
        if (skillName === "_smoke-test") continue;
        const skillDir = join(EVAL_CASES_DIR, skillName);
        for (const caseName of listDirs(skillDir)) {
          if (caseName === "calibration" || caseName === "personas") continue;
          cases.push(`${skillName}/${caseName}`);
        }
      }
    }

    if (parallel) {
      process.stdout.write(`Launching ${cases.length} evals in parallel...\n`);
      for (const c of cases) {
        runSingle(c);
      }
      process.stdout.write(
        "All launched. Use 'alexandria-eval running' to check status.\n",
      );
    } else {
      for (const c of cases) {
        runSingle(c);
        process.stdout.write(`  Launched: ${c} (background)\n`);
      }
      process.stdout.write("\n");
      process.stdout.write(
        "All launched in background. Use 'alexandria-eval running' to check status.\n",
      );
    }
  } else if (target.endsWith("/all")) {
    const skillName = target.slice(0, -4);
    const skillDir = join(EVAL_CASES_DIR, skillName);
    const cases: string[] = [];
    for (const caseName of listDirs(skillDir)) {
      if (caseName === "calibration" || caseName === "personas") continue;
      cases.push(`${skillName}/${caseName}`);
    }

    for (const c of cases) {
      runSingle(c);
      process.stdout.write(`  Launched: ${c} (background)\n`);
    }
    process.stdout.write("\n");
    process.stdout.write(
      `${cases.length} evals launched. Use 'alexandria-eval running' to check status.\n`,
    );
  } else {
    runSingle(target);
    process.stdout.write(`  Launched: ${target} (background)\n`);
    process.stdout.write("  Use 'alexandria-eval running' to check status.\n");
  }
}

// ─────────────────────────────────────────────
// running — list active eval runs
// ─────────────────────────────────────────────

function cmdRunning(): void {
  process.stdout.write("\n");
  process.stdout.write(bold("Running Evals") + "\n");
  process.stdout.write("═══════════════════════════════════════════\n");

  let found = false;

  if (isDir(PID_DIR)) {
    for (const fname of readdirSync(PID_DIR)) {
      if (!fname.endsWith(".pid")) continue;
      const pidFile = join(PID_DIR, fname);
      if (!isFile(pidFile)) continue;

      const pid = readFileSync(pidFile, "utf-8").trim();
      const caseName = fname.slice(0, -4).replace(/_/g, "/");

      // Check if process is alive
      try {
        process.kill(Number(pid), 0);
        process.stdout.write(`  ${green("●")} ${caseName} (PID ${pid})\n`);
        found = true;
      } catch {
        // Stale PID file
        try {
          unlinkSync(pidFile);
        } catch {
          // ignore
        }
      }
    }
  }

  // Also check for direct eval-harness.ts processes.
  try {
    const psOut = execSync("ps aux", { encoding: "utf-8" });
    const evalProcs = psOut
      .split("\n")
      .filter(
        (line) =>
          line.includes("eval-harness.ts") &&
          !line.includes("grep") &&
          !line.includes("alexandria-eval"),
      );
    if (evalProcs.length > 0) {
      process.stdout.write("\n  Other eval processes:\n");
      for (const line of evalProcs) {
        const parts = line.trim().split(/\s+/);
        const pid = parts[1] ?? "";
        const cmd = parts.slice(10).join(" ");
        process.stdout.write(`    PID ${pid}: ${cmd}\n`);
      }
      found = true;
    }
  } catch {
    // ps failed, ignore
  }

  if (!found) {
    process.stdout.write("  No evals currently running.\n");
  }
  process.stdout.write("\n");
}

// ─────────────────────────────────────────────
// results — show detailed results for a case
// ─────────────────────────────────────────────

function cmdResults(casePath: string): void {
  if (!casePath) {
    process.stdout.write("Usage: alexandria-eval results <skill>/<case>\n");
    process.exit(1);
  }

  const resultDir = join(EVAL_RESULTS_DIR, casePath);
  if (!isDir(resultDir)) {
    process.stdout.write(`No results found for ${casePath}\n`);
    process.exit(1);
  }

  const metaFile = join(resultDir, "run-metadata.json");

  process.stdout.write("\n");
  process.stdout.write(bold(`Eval Results: ${casePath}`) + "\n");
  process.stdout.write("═══════════════════════════════════════════\n");

  // Metadata
  if (isFile(metaFile)) {
    const meta = readJson(metaFile) ?? {};
    process.stdout.write("\n");
    process.stdout.write("  Run metadata:\n");
    const ts = ((meta["timestamp"] as string | undefined) ?? "?").slice(0, 19);
    process.stdout.write(`    Date:     ${ts}\n`);
    process.stdout.write(`    Version:  ${meta["version"] ?? "?"}\n`);
    process.stdout.write(`    Git SHA:  ${meta["git_sha"] ?? "?"}\n`);
    process.stdout.write(`    Mode:     ${meta["eval_mode"] ?? "?"}\n`);
    process.stdout.write(`    Duration: ${meta["duration_seconds"] ?? "?"}s\n`);
    process.stdout.write(
      `    Files:    ${meta["files_written_count"] ?? "?"}\n`,
    );
    process.stdout.write(
      `    Session:  ${meta["session_id"] ?? "not captured"}\n`,
    );
  }

  // Structural results
  const structFile = join(resultDir, "structural-results.json");
  if (isFile(structFile)) {
    const sd = readJson(structFile) ?? {};
    process.stdout.write("\n");
    process.stdout.write("  Structural checks:\n");
    const checks =
      (sd["checks"] as Array<Record<string, unknown>> | undefined) ?? [];
    for (const c of checks) {
      const passed = c["passed"] ?? c["pass"] ?? false;
      const status = passed ? "✓" : "✗";
      const name = (c["name"] ?? c["check"] ?? "?") as string;
      process.stdout.write(`    ${status} ${name}\n`);
    }
    const p = sd["pass_count"] ?? sd["passed"] ?? "?";
    const t = sd["total"] ?? sd["total_count"] ?? "?";
    process.stdout.write(`    ——\n`);
    process.stdout.write(`    ${p}/${t} passed\n`);
  }

  // Judge results
  const judgeFile = join(resultDir, "judge-results.json");
  if (isFile(judgeFile)) {
    const jd = readJson(judgeFile) ?? {};
    process.stdout.write("\n");
    process.stdout.write("  Judge scores:\n");
    const criteria =
      (jd["criteria"] as Array<Record<string, unknown>> | undefined) ?? [];
    const isCategorical =
      criteria.length > 0 &&
      ("level" in (criteria[0] ?? {}) || "score" in (criteria[0] ?? {}));

    for (const c of criteria) {
      const name = (c["name"] ?? "?") as string;
      let reason = (c["reason"] ?? "") as string;
      if (reason.length > 80) reason = reason.slice(0, 77) + "...";

      if (isCategorical) {
        const level = c["level"] ?? c["score"] ?? "?";
        process.stdout.write(`    [${level}] ${name}\n`);
      } else {
        const status = c["pass"] ? "✓" : "✗";
        process.stdout.write(`    ${status} ${name}\n`);
      }
      if (reason) {
        process.stdout.write(`      ${reason}\n`);
      }
    }
    process.stdout.write(`    ——\n`);
    if ("pass_count" in jd) {
      process.stdout.write(`    ${jd["pass_count"]}/${jd["total"]} passed\n`);
    } else if ("weighted_score" in jd) {
      process.stdout.write(
        `    Score: ${jd["weighted_score"]}/${jd["max_score"]}\n`,
      );
      const lc = (jd["level_counts"] ?? {}) as Record<string, number>;
      const parts = Object.entries(lc)
        .filter(([, v]) => v > 0)
        .map(([k, v]) => `${k}: ${v}`);
      if (parts.length > 0) {
        process.stdout.write(`    Levels: ${parts.join(", ")}\n`);
      }
    } else if ("scores" in jd) {
      const lc = (jd["scores"] ?? {}) as Record<string, number>;
      const parts = Object.entries(lc)
        .filter(([, v]) => v > 0)
        .map(([k, v]) => `${k}: ${v}`);
      if (parts.length > 0) {
        process.stdout.write(`    Levels: ${parts.join(", ")}\n`);
      }
    }
    const summary = (jd["summary"] as string | undefined) ?? "";
    if (summary) {
      process.stdout.write(`    Summary: ${summary.slice(0, 120)}\n`);
    }
  }

  process.stdout.write("\n");
}

// ─────────────────────────────────────────────
// compare — diff current results vs baseline
// ─────────────────────────────────────────────

const LEVEL_ORDER = ["poor", "weak", "adequate", "good", "excellent"];

function levelRank(l: string): number {
  const idx = LEVEL_ORDER.indexOf(l);
  return idx >= 0 ? idx : -1;
}

function cmdCompare(casePath: string): void {
  if (!casePath) {
    process.stdout.write("Usage: alexandria-eval compare <skill>/<case>\n");
    process.exit(1);
  }

  process.stdout.write("\n");
  process.stdout.write(bold(`Compare: ${casePath}`) + "\n");
  process.stdout.write("═══════════════════════════════════════════\n");

  const resultDir = join(EVAL_RESULTS_DIR, casePath);
  const judgeFile = join(resultDir, "judge-results.json");

  if (!isFile(judgeFile)) {
    process.stdout.write("  No results to compare.\n");
    process.exit(1);
  }

  // Get baseline from git
  let baselineJudge: Record<string, unknown> | null = null;
  try {
    const gitPath = `tests/evals/${casePath}/judge-results.json`;
    const out = execSync(`git show HEAD:"${gitPath}"`, {
      cwd: ROOT_DIR,
      encoding: "utf-8",
    });
    baselineJudge = JSON.parse(out) as Record<string, unknown>;
  } catch {
    // No baseline
  }

  if (!baselineJudge) {
    process.stdout.write("  No baseline in git to compare against.\n");
    process.stdout.write("  Current results:\n");
    cmdResults(casePath);
    return;
  }

  const current = readJson(judgeFile) ?? {};

  process.stdout.write("\n");
  process.stdout.write(
    `  ${pad("CRITERION", 35)} ${pad("BASELINE", 12)} ${pad("CURRENT", 12)} DELTA\n`,
  );
  process.stdout.write(
    `  ${pad("---", 35)} ${pad("---", 12)} ${pad("---", 12)} ---\n`,
  );

  // Detect schema
  const bCriteria =
    (baselineJudge["criteria"] as Array<Record<string, unknown>> | undefined) ??
    [];
  const cCriteria =
    (current["criteria"] as Array<Record<string, unknown>> | undefined) ?? [];
  const bCat =
    bCriteria.length > 0 &&
    ("level" in (bCriteria[0] ?? {}) || "score" in (bCriteria[0] ?? {}));
  const cCat =
    cCriteria.length > 0 &&
    ("level" in (cCriteria[0] ?? {}) || "score" in (cCriteria[0] ?? {}));

  if (bCat || cCat) {
    // Categorical comparison
    const bMap: Record<string, string> = {};
    for (const c of bCriteria) {
      bMap[c["name"] as string] = (c["level"] ?? c["score"] ?? "?") as string;
    }
    const cMap: Record<string, string> = {};
    for (const c of cCriteria) {
      cMap[c["name"] as string] = (c["level"] ?? c["score"] ?? "?") as string;
    }

    const allNames = [...new Set([...Object.keys(bMap), ...Object.keys(cMap)])];
    for (const name of allNames) {
      const b = bMap[name] ?? "—";
      const c = cMap[name] ?? "—";
      let delta: string;
      if (b === c) {
        delta = "  ";
      } else if (b === "—") {
        delta = "  new";
      } else if (c === "—") {
        delta = "  removed";
      } else if (levelRank(c) > levelRank(b)) {
        delta = "▲ improved";
      } else if (levelRank(c) < levelRank(b)) {
        delta = "▼ regressed";
      } else {
        delta = "  ";
      }
      process.stdout.write(
        `  ${pad(name, 35)} ${pad(b, 12)} ${pad(c, 12)} ${delta}\n`,
      );
    }

    const bScore = baselineJudge["weighted_score"] ?? "?";
    const cScore = current["weighted_score"] ?? "?";
    const bMax = baselineJudge["max_score"] ?? "?";
    const cMax = current["max_score"] ?? "?";
    process.stdout.write("\n");
    process.stdout.write(`  Score: ${bScore}/${bMax} → ${cScore}/${cMax}\n`);
  } else {
    // Pass/fail comparison
    const bMap: Record<string, boolean | null> = {};
    for (const c of bCriteria) {
      bMap[c["name"] as string] = (c["pass"] as boolean | undefined) ?? null;
    }
    const cMap: Record<string, boolean | null> = {};
    for (const c of cCriteria) {
      cMap[c["name"] as string] = (c["pass"] as boolean | undefined) ?? null;
    }

    const allNames = [...new Set([...Object.keys(bMap), ...Object.keys(cMap)])];
    for (const name of allNames) {
      const b = bMap[name] ?? null;
      const c = cMap[name] ?? null;
      const bStr = b === true ? "✓" : b === false ? "✗" : "—";
      const cStr = c === true ? "✓" : c === false ? "✗" : "—";
      let delta: string;
      if (b === c) {
        delta = "  ";
      } else if (c && !b) {
        delta = "▲ improved";
      } else if (b && !c) {
        delta = "▼ regressed";
      } else {
        delta = "  new";
      }
      process.stdout.write(
        `  ${pad(name, 35)} ${pad(bStr, 12)} ${pad(cStr, 12)} ${delta}\n`,
      );
    }

    const bTotal = baselineJudge["pass_count"] ?? "?";
    const cTotal = current["pass_count"] ?? "?";
    const bMax = baselineJudge["total"] ?? "?";
    const cMax = current["total"] ?? "?";
    process.stdout.write("\n");
    process.stdout.write(`  Total: ${bTotal}/${bMax} → ${cTotal}/${cMax}\n`);
  }

  process.stdout.write("\n");
}

// ─────────────────────────────────────────────
// history — show run history for a case
// ─────────────────────────────────────────────

function cmdHistory(casePath: string): void {
  if (!casePath) {
    process.stdout.write("Usage: alexandria-eval history <skill>/<case>\n");
    process.exit(1);
  }

  process.stdout.write("\n");
  process.stdout.write(bold(`Run History: ${casePath}`) + "\n");
  process.stdout.write("═══════════════════════════════════════════\n");

  // Show git log
  const resultSubpath = `tests/evals/${casePath}`;
  try {
    const gitLog = execSync(
      `git log --oneline -- "${resultSubpath}/run-metadata.json" "${resultSubpath}/judge-results.json"`,
      { cwd: ROOT_DIR, encoding: "utf-8" },
    )
      .trim()
      .split("\n")
      .filter(Boolean)
      .slice(0, 20);

    if (gitLog.length > 0) {
      process.stdout.write("  Git history:\n");
      for (const line of gitLog) {
        process.stdout.write(`    ${line}\n`);
      }
    } else {
      process.stdout.write("  No git history found for this case.\n");
    }
  } catch {
    process.stdout.write("  No git history found for this case.\n");
  }

  // Show local runs directory
  const runsDir = join(EVAL_RESULTS_DIR, casePath, "runs");
  if (isDir(runsDir)) {
    process.stdout.write("\n");
    process.stdout.write("  Local runs (not in git):\n");
    for (const runName of listDirs(runsDir)) {
      const runDir = join(runsDir, runName);
      const runMeta = join(runDir, "run-metadata.json");
      if (isFile(runMeta)) {
        const meta = readJson(runMeta) ?? {};
        const ts = ((meta["timestamp"] as string | undefined) ?? "?").slice(
          0,
          19,
        );
        const dur = meta["duration_seconds"] ?? "?";
        process.stdout.write(`    ${runName}  (${ts}, ${dur}s)\n`);
      } else {
        process.stdout.write(`    ${runName}\n`);
      }
    }
  }

  process.stdout.write("\n");
}

// ─────────────────────────────────────────────
// Main dispatch
// ─────────────────────────────────────────────

const argv = process.argv.slice(2);
const cmd = argv[0] ?? "help";
const rest = argv.slice(1);

switch (cmd) {
  case "list":
    cmdList();
    break;
  case "status":
    cmdStatus();
    break;
  case "run":
    cmdRun(rest);
    break;
  case "running":
    cmdRunning();
    break;
  case "results":
    cmdResults(rest[0] ?? "");
    break;
  case "compare":
    cmdCompare(rest[0] ?? "");
    break;
  case "history":
    cmdHistory(rest[0] ?? "");
    break;
  case "_run-single":
    // Internal command — not shown in help. Spawned by runSingle() as a
    // background coordinator; runs the eval, waits for it, then reports.
    await cmdRunSingleInternal(rest[0] ?? "");
    break;
  case "help":
  case "--help":
  case "-h":
    process.stdout.write("\n");
    process.stdout.write("Alexandria — Eval CLI\n");
    process.stdout.write("\n");
    process.stdout.write("Commands:\n");
    process.stdout.write(
      "  list                         List available eval cases\n",
    );
    process.stdout.write(
      "  status                       Show last run info + staleness for all cases\n",
    );
    process.stdout.write(
      "  run <skill>/<case>           Run one eval case (background)\n",
    );
    process.stdout.write(
      "  run <skill>/all              Run all cases for a skill (background)\n",
    );
    process.stdout.write("  run all [--parallel]         Run all eval cases\n");
    process.stdout.write(
      "  running                      List currently running evals\n",
    );
    process.stdout.write(
      "  results <skill>/<case>       Show detailed results for a case\n",
    );
    process.stdout.write(
      "  compare <skill>/<case>       Compare current results vs git baseline\n",
    );
    process.stdout.write(
      "  history <skill>/<case>       Show run history (git log + local runs)\n",
    );
    process.stdout.write("\n");
    break;
  default:
    process.stdout.write(`Unknown command: ${cmd}\n`);
    process.stdout.write("Run 'alexandria-eval help' for usage.\n");
    process.exit(1);
}
