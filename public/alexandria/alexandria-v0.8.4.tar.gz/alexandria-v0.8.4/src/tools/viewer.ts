/**
 * Viewer CLI entry point.
 *
 * Usage:
 *   alexandria-viewer                 # default to serve
 *   alexandria-viewer serve           # start Astro dev server
 *   alexandria-viewer build           # run Astro static build
 *   alexandria-viewer --port 4321     # default serve with custom port
 *   alexandria-viewer serve --host 127.0.0.1 --port 4321
 *   alexandria-viewer build --library docs/alexandria
 */

import { existsSync } from "fs";
import { dirname, join, resolve } from "path";
import { fileURLToPath } from "url";
import { resolvePluginRoot } from "../lib/plugin-paths.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const PRIMARY_LIBRARY_ENV = "ALEXANDRIA_VIEWER_LIBRARY_ROOT";
const LEGACY_LIBRARY_ENV = "CONTEXT_LIBRARY_VIEWER_LIBRARY_ROOT";
const DEFAULT_DEV_HOST = "127.0.0.1";

type ViewerCommand = "serve" | "build";

interface ParsedViewerArgs {
  command: ViewerCommand;
  help: boolean;
  port?: number;
  host?: string | boolean;
  open?: string | boolean;
  libraryRoot?: string;
}

export interface ViewerCliResult {
  exitCode: number;
  stdout?: string;
  stderr?: string;
  keepsProcessAlive?: boolean;
}

interface ViewerCliOptions {
  args?: string[];
  env?: NodeJS.ProcessEnv;
}

function usage(): string {
  return `Usage: alexandria-viewer [serve|build] [options]

Commands:
  serve               Start the Astro dev server (default)
  build               Build the static viewer into packages/viewer/dist/

Options:
  --port <number>     Set the dev server port
  --host [value]      Bind the dev server host (default: ${DEFAULT_DEV_HOST})
  --open [path]       Open a browser when the dev server starts
  --library <path>    Override the Alexandria docs root (default: docs/alexandria)
  --help, -h          Show this help`;
}

function parseOptionalValue(
  args: string[],
  index: number,
): { value: string | boolean; nextIndex: number } {
  const next = args[index + 1];
  if (!next || next.startsWith("-")) {
    return { value: true, nextIndex: index };
  }

  return { value: next, nextIndex: index + 1 };
}

function parseViewerArgs(args: string[]): ParsedViewerArgs {
  if (args.length === 0) {
    return { command: "serve", help: false };
  }

  const firstArg = args[0];
  let command: ViewerCommand = "serve";
  let index = 0;

  if (!firstArg) {
    return { command: "serve", help: false };
  }

  if (firstArg === "serve" || firstArg === "build") {
    command = firstArg;
    index = 1;
  } else if (firstArg === "--help" || firstArg === "-h") {
    return { command: "serve", help: true };
  } else if (!firstArg.startsWith("-")) {
    throw new Error(`Unknown subcommand: ${firstArg}`);
  }

  const parsed: ParsedViewerArgs = { command, help: false };

  while (index < args.length) {
    const arg = args[index];

    switch (arg) {
      case "--help":
      case "-h":
        parsed.help = true;
        index += 1;
        break;
      case "--port": {
        const value = args[index + 1];
        if (!value) {
          throw new Error("--port requires a value");
        }
        const port = Number(value);
        if (!Number.isInteger(port) || port < 0 || port > 65535) {
          throw new Error(`Invalid port: ${value}`);
        }
        parsed.port = port;
        index += 2;
        break;
      }
      case "--host": {
        const { value, nextIndex } = parseOptionalValue(args, index);
        parsed.host = value;
        index = nextIndex + 1;
        break;
      }
      case "--open": {
        const { value, nextIndex } = parseOptionalValue(args, index);
        parsed.open = value;
        index = nextIndex + 1;
        break;
      }
      case "--library": {
        const value = args[index + 1];
        if (!value) {
          throw new Error("--library requires a value");
        }
        parsed.libraryRoot = value;
        index += 2;
        break;
      }
      default:
        throw new Error(`Unknown option: ${arg}`);
    }
  }

  return parsed;
}

function resolveViewerRoot(pluginRoot: string): string {
  return join(pluginRoot, "packages", "viewer");
}

function resolveLibraryRoot(
  pluginRoot: string,
  env: NodeJS.ProcessEnv,
  override?: string,
): string {
  return resolve(
    override ??
      env[PRIMARY_LIBRARY_ENV] ??
      env[LEGACY_LIBRARY_ENV] ??
      join(pluginRoot, "docs", "alexandria"),
  );
}

function applyLibraryEnv(env: NodeJS.ProcessEnv, libraryRoot: string): void {
  env[PRIMARY_LIBRARY_ENV] = libraryRoot;
  env[LEGACY_LIBRARY_ENV] = libraryRoot;
  process.env[PRIMARY_LIBRARY_ENV] = libraryRoot;
  process.env[LEGACY_LIBRARY_ENV] = libraryRoot;
}

function decodeOutput(buffer: Uint8Array): string {
  return new TextDecoder().decode(buffer);
}

function resolveBunExecutable(): string {
  const bunPath = Bun.which("bun");
  if (!bunPath) {
    throw new Error(
      "Bun is required to run alexandria-viewer. Reinstall Bun or rerun ./setup.",
    );
  }

  return bunPath;
}

function buildAstroArgs(
  bunPath: string,
  viewerRoot: string,
  parsed: ParsedViewerArgs,
): string[] {
  const viewerScript = parsed.command === "serve" ? "dev" : "build";
  const args = [bunPath, "run", "--cwd", viewerRoot, viewerScript];

  if (parsed.command === "serve") {
    args.push("--");
    args.push("--host");
    if (typeof parsed.host === "string") {
      args.push(parsed.host);
    } else if (parsed.host === undefined) {
      args.push(DEFAULT_DEV_HOST);
    }
    if (parsed.open !== undefined) {
      args.push("--open");
      if (typeof parsed.open === "string") {
        args.push(parsed.open);
      }
    }
    if (parsed.port !== undefined) {
      args.push("--port", String(parsed.port));
    }
  }

  return args;
}

function registerShutdown(child: Bun.Subprocess): void {
  let shuttingDown = false;

  const shutdown = async () => {
    if (shuttingDown) {
      return;
    }
    shuttingDown = true;
    child.kill("SIGTERM");
    await child.exited;
    process.exit(0);
  };

  process.once("SIGINT", () => {
    void shutdown();
  });
  process.once("SIGTERM", () => {
    void shutdown();
  });
}

export async function runViewerCli(
  options: ViewerCliOptions = {},
): Promise<ViewerCliResult> {
  const env = options.env ?? process.env;
  const args = options.args ?? process.argv.slice(2);

  let parsed: ParsedViewerArgs;
  try {
    parsed = parseViewerArgs(args);
  } catch (error) {
    return {
      exitCode: 1,
      stderr: `${error instanceof Error ? error.message : String(error)}\n\n${usage()}`,
    };
  }

  if (parsed.help) {
    return { exitCode: 0, stdout: usage() };
  }

  const pluginRoot = resolvePluginRoot(env, __dirname);
  const viewerRoot = resolveViewerRoot(pluginRoot);
  if (!existsSync(viewerRoot)) {
    return {
      exitCode: 1,
      stderr: `Viewer workspace not found at ${viewerRoot}. Run bun install or complete FEAT-001 setup first.`,
    };
  }

  const libraryRoot = resolveLibraryRoot(pluginRoot, env, parsed.libraryRoot);
  applyLibraryEnv(env, libraryRoot);
  const bunPath = resolveBunExecutable();
  const command = buildAstroArgs(bunPath, viewerRoot, parsed);

  if (parsed.command === "build") {
    const result = Bun.spawnSync(command, {
      cwd: pluginRoot,
      env,
      stdout: "pipe",
      stderr: "pipe",
    });

    return {
      exitCode: result.exitCode,
      stdout: decodeOutput(result.stdout),
      stderr: decodeOutput(result.stderr),
    };
  }

  const child = Bun.spawn(command, {
    cwd: pluginRoot,
    env,
    stdout: "inherit",
    stderr: "inherit",
    stdin: "inherit",
  });
  registerShutdown(child);
  void child.exited.then((exitCode) => {
    process.exit(exitCode);
  });

  return {
    exitCode: 0,
    keepsProcessAlive: true,
  };
}

async function main(): Promise<void> {
  const result = await runViewerCli();

  if (result.stdout) {
    process.stdout.write(
      result.stdout.endsWith("\n") ? result.stdout : `${result.stdout}\n`,
    );
  }
  if (result.stderr) {
    process.stderr.write(
      result.stderr.endsWith("\n") ? result.stderr : `${result.stderr}\n`,
    );
  }

  if (!result.keepsProcessAlive) {
    process.exit(result.exitCode);
  }
}

if (import.meta.main) {
  main().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`${message}\n`);
    process.exit(1);
  });
}
