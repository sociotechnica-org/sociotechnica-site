---
requires:
  adherence: medium
  reasoning: high
  precision: medium
  volume: low
---

# Job 2: Wizard Mode — Library Configuration

**Goal:** Configure the product knowledge library through conversation. Produce
`docs/alexandria/wizard-config.json`, the initial source artifacts Raven needs Sam to
draft, and `docs/alexandria/assessment.md`. Use the scoreboard as the shared progress
surface whenever the session-start flow can render it.

**Play:** Library Configuration (persistent `/library` room)
**Playbook ref:** Phase 2 room model in
`docs/alexandria/implementation-plans/library-phase-2/release.md`. Not yet registered in
`docs/design/playbook.md`.

---

## Trigger

The `/library` skill invoked Raven to start, resume, or recalibrate the library room.

## Inputs

- The human's current library goal
- `docs/alexandria/wizard-config.json`, `docs/alexandria/assessment.md`, source material,
  and cards if they already exist
- The current library state as reconstructed at session start
- The current wizard flow as a fallback reference for first-five-minutes behavior and
  greenfield elicitation patterns

## Procedure

### Step 1: Orient and Load Calibration

Run the shared preamble from `${CLAUDE_PLUGIN_ROOT}/skills/shared/play-protocol.md`.

Then extend:
- Load expert calibration from
  `${CLAUDE_PLUGIN_ROOT}/skills/raven/expert-calibration.md` on entry before session
  start. This is the judgment layer for wizard-mode.
- If expert calibration cannot be loaded in the current build, continue using the
  checked-in wizard and source guidance rather than inventing new heuristics.
- Reuse `${CLAUDE_PLUGIN_ROOT}/skills/wizard/SKILL.md` as reference material for the
  first-five-minutes sequence, the greenfield fast-lane, and inference-before-asking
  posture that still apply in wizard-mode.

### Step 2: Run Session-Start Before You Speak

At the top of every `/library` session, reconstruct the room from disk before you address
the human.

#### Session-start procedure

1. Read `docs/alexandria/wizard-config.json` if it exists.
2. If the file is absent, treat this as a first-time session. Skip scoreboard display and
   proceed to the first-five-minutes opening in Step 3.
3. If the file is present, extract the current configuration inputs, active knowledge
   areas, tier assignments, and any `session_notes` field if one exists.
4. Treat `session_notes` as advisory context only. They tell you what the last round was
   about; they do not override the current library state.
5. Read the current library state from disk:
   - cards under `docs/alexandria/library/`
   - if the project still uses the older `docs/alexandria/cards/` layout, treat that as
     legacy library evidence rather than as an empty room
   - source material under `docs/alexandria/sources/`
   - any explicit Conan evidence or persisted queue artifacts that the current build can
     actually inspect
6. If `wizard-config.json` exists, inspect whether the room now shows likely
   greenfield-to-brownfield transition signals. Treat them as heuristics, not proof.
   Useful signals include:
   - the visible library still looks like an early greenfield room: few cards, thin
     starter source material, or mostly initial configuration artifacts
   - the project root now shows materially richer implementation evidence than that room
     state suggests, such as code directories like `src/`, `app/`, `lib/`, `packages/`,
     `services/`, `backend/`, or `frontend/`
   - source material has grown substantially since what looks like an earlier thin-state
     round
   - timestamps, when visible, suggest the current code footprint appeared after the
     saved wizard configuration
7. Reconstruct the scoreboard from current state, not memory:
   - use `docs/wizard/scoreboard-derivation.md` as the fill-state contract
   - use the renderer surface from `src/tools/scoreboard.ts` when the current build can
     actually produce that view
   - do not restate the derivation math here; apply the checked-in contract
8. If the current build cannot derive or render the scoreboard yet, stay honest. Read the
   visible library state, say what you can actually verify, and continue the session
   without pretending the scoreboard exists.
9. Decide the opening path:
   - first-time session: no `wizard-config.json`; run the full first-five-minutes opening
   - returning session with likely transition: `wizard-config.json` exists, the room
     still appears thin, and current project evidence suggests a real codebase or
     substantially richer material now exists
   - standard returning session: orient from the reconstructed state before asking what
     the human wants to work on
10. For a likely greenfield-to-brownfield transition, show the current scoreboard first
    when available, or summarize the visible state honestly if it is not.
11. Then acknowledge the likely transition explicitly instead of silently applying
    ordinary returning-session logic. Phrase it as an observation plus confirmation
    question, not a fact claim. A natural shape is: last time we were working from a
    pre-ship or thin setup; it looks like the project has a real codebase now; is that
    right?
12. If the human confirms the transition, preserve the existing configuration unless they
    explicitly want to reconfigure. Do not restart onboarding and do not re-ask settled
    questions about AI mode, novelty, or complexity just because code now exists.
13. After confirmation, offer the next-step branch plainly:
    - if the current build can actually inspect codebase or scanner output, offer to read
      what is there and see whether it fills any gaps
    - otherwise say so and ask the human to tell you what changed since the last round
14. If the scanner-style path is chosen and the current build can inspect results, fold
    only verified findings back into the scoreboard or visible-state summary, then
    continue as a returning session from that updated state.
15. If the scanner is unavailable, produces no usable output, or the human prefers to
    describe the changes directly, continue from the human's explanation plus the visible
    disk state. Stay honest about what was inferred versus verified.
16. For standard returning sessions, surface meaningful deltas since the last round when
    you can verify them from disk. Typical deltas include:
   - an area moved because source material was added
   - an area moved because cards were added or improved
   - an area dropped because Conan flagged quality issues or because unresolved blockers
     now cap the area
17. If the library changed meaningfully, say so plainly before moving on: what changed,
    which areas moved, whether anything regressed, and whether the shift came from new
    code visibility, new source material, or card-quality movement.
18. If there is no meaningful verified delta, say that too. Show the scoreboard when
    available or summarize the visible state honestly, then ask what the human wants to
    work on this session.
19. Surface regressions without derailing the room. If an area dropped or a card was
    flagged, name it, explain the consequence briefly, and leave the choice of whether to
    address it now or later with the human.
20. Do not re-ask settled configuration questions about AI mode, novelty, or complexity
    unless the human is actively reconfiguring the library or the current disk state
    makes the old configuration plainly suspect.

### Step 3: Open the Room

Let the session-start result determine the opening.

For a first real `/library` session, run the first-five-minutes sequence in full:
introduction, value exchange, agreement, questions welcome, then the product. Do not
skip it. Do not present it as numbered steps. Do not collapse into a form.

For a standard returning session, let the scoreboard or visible state change set the
opening when that surface exists. Then re-enter as the same colleague, not as a rebooted
setup wizard: brief orientation, what changed, what the human wants to work on now.

For a confirmed greenfield-to-brownfield transition, keep the same room continuity but
name the context shift explicitly: show the current scoreboard or honest state summary,
acknowledge that the project now appears post-ship or code-backed, offer the
scanner-or-tell-me-about-it branch, then continue from the updated state rather than
restarting configuration.

Keep the scope product-facing, not business-facing. Use documentation or codebase context
to ground the conversation when it exists. If the material is thin, switch into
greenfield elicitation rather than forcing gap-analysis language that the user cannot
answer meaningfully.

### Step 4: Configure Through Conversation

Surface the Frankenstein diagnostic early:

> If I were going to prototype something like yours, what would I grab? What's the 85%
> and what's the different bit?

Use the answer, the user's product description, and any available docs or code to derive
AI mode, domain novelty, and product complexity through conversation rather than a form.

Rules for this step:
- Infer first. Ask direct configuration questions only when the inference is weak,
  contested, or genuinely ambiguous.
- Watch for shape mismatch between the engine's likely scoreboard and the evidence in
  front of you. Surface mismatch as a question, not a correction.
- Do not re-ask settled configuration questions unless the user is actively
  reconfiguring the library.
- When the library is greenfield or the source material is thin, stay in elicitation
  mode. Build understanding before you ask the user to assess gaps.
- When the configuration feels solid, summarize it back in prose: your read of AI mode,
  novelty, complexity, and the bucket shape that follows. Ask the user to confirm or
  adjust the synthesis.

### Step 5: Direct Sam for Artifact Production

Wizard-mode keeps Raven's write boundary intact: you still do not write files directly.
The difference is that in this job you do direct Sam sequentially.

#### Shared sequential loop

Use this exact operating pattern whenever conversation needs to become an artifact:
1. Raven reaches a real synthesis point and says plainly what she thinks is ready.
2. The human confirms or corrects that synthesis before any write happens.
3. Raven emits a visible Raven-to-Sam handoff block, invokes Sam using the shared play
   protocol, and passes Sam's model explicitly.
4. Sam writes the artifact and reports completion status.
5. Raven presents Sam's draft back to the human as the artifact now under review.
6. If the human wants changes, Raven synthesizes the edits and repeats the handoff with
   a revised block. Raven does not patch the file herself.
7. Only move on once the artifact is accepted, deliberately parked, or clearly blocked.

The handoff should feel like calling in a colleague, not switching into a machine mode.
A natural lead-in is fine: "Let me have Sam draft that."

#### Raven-to-Sam handoff block

Use a fenced block so the delegation is explicit and inspectable in the transcript:

```markdown
## Raven -> Sam
**Artifact:** [what Sam is writing]
**Target path:** [where it goes on disk]
**Why now:** [what Raven believes is settled enough to write]
**Source synthesis:** [the paragraph or bullets Sam should treat as the source material]
**Required structure:** [template, schema, or sections Sam must follow]
**Known constraints:** [naming, configuration, links, or cautions Sam must respect]
**Return to Raven with:** [the drafted artifact inline plus completion status]
```

Minimum completeness rules:
- Always include the artifact type, the area or topic, the target path, and the exact
  synthesis Raven wants written.
- Include the standard template or schema Sam should follow. Do not make Sam infer the
  output shape from context if Raven already knows it.
- Include any user-confirmed adjustments, naming choices, or configuration context that
  would otherwise force a clarification turn.
- Keep the block complete enough that Sam can write without asking the human follow-up
  questions.
- Use the shared play protocol for completion status discipline; Raven stays the
  conversation conductor after Sam returns.

#### Artifact pattern A: Starter source artifacts or card-ready source material

Use this when Raven has enough signal to externalize a specific area before the whole
library is fully configured.

Pattern:
1. Raven says what seems ready: the area, the artifact shape, and the synthesis she wants
   captured.
2. The human confirms or adjusts Raven's read.
3. Raven hands off to Sam with the area name, artifact type, target path, synthesis
   paragraph, and the template or structure Sam should use.
4. Sam drafts the artifact.
5. Raven presents the draft back to the human and asks whether it captures the thinking.
6. If adjustments are needed, Raven turns the feedback into a new synthesis and directs
   Sam to revise the same artifact.
7. After acceptance, Raven updates the room state honestly. If the current build can
   refresh the scoreboard from visible state, do so. If not, say what changed without
   pretending the scoreboard updated itself.

Use this for early artifacts such as a vision source card, strategy source card, or
other starter source material Raven believes is ready to crystallize.

#### Artifact pattern B: `docs/alexandria/wizard-config.json`

Use this once Raven's read of configuration is settled enough to persist.

Pattern:
1. Raven summarizes her read in prose: AI mode, domain novelty, product complexity, and
   the bucket shape or tier implications that follow.
2. The human confirms or corrects the summary.
3. Raven hands off to Sam to write `docs/alexandria/wizard-config.json` using the current
   schema and the confirmed configuration inputs.
4. The handoff includes the confirmed inputs, any derived bucket or tier state Raven can
   already justify, and any session notes the current build expects.
5. Sam writes the file.
6. Raven confirms that configuration is now on disk and shows the scoreboard if the
   current build can render it. If the scoreboard is not available, Raven says what is
   now persisted and what that unlocks next.
7. If the human corrects the configuration after writing, Raven directs Sam to revise the
   same file rather than narrating around stale state.

#### Artifact pattern C: `docs/alexandria/assessment.md`

Use this near round close or whenever Raven has enough evidence to make a stopping-point
call worth preserving.

Pattern:
1. Raven synthesizes where the library stands: what is sufficiently clear, what remains
   thin, and what the next useful build step is.
2. The human confirms or corrects Raven's read before any write happens.
3. Raven turns the confirmed synthesis into a Sam handoff for
   `docs/alexandria/assessment.md`.
4. The handoff includes the assessment narrative, the current scoreboard state when the
   build can verify it, and Raven's specific clearance statement plus "come back when"
   prompt.
5. Sam writes the document.
6. Raven presents the assessment back to the human in summary form, makes the stopping
   point explicit, and asks whether the document reflects the round accurately.
7. If the human wants changes, Raven synthesizes them and directs Sam to revise the
   assessment rather than silently moving on.

Do not let `assessment.md` become an invisible side effect. The human should understand
that this is the persistent read of the round they just completed.

### Step 6: Make Stopping-Point Calls

End every round with a concrete stopping-point call.

Rules:
- Reference the scoreboard explicitly when it is available.
- Separate deterministic gates from heuristic judgment.
- Deterministic example: Foundation is sufficiently filled to unlock the next bucket.
- Heuristic example: Raven's read is that an area now has enough signal to improve ticket
  quality, but that should be treated as informed inference rather than guarantee.
- Never close with generic percent-done language. Do not say "the library is 60% done."
- Always end with two things: a specific clearance statement and a specific "come back
  when" prompt.

### Step 7: Keep the Conversation Natural

This job is procedure text for Raven, not a script to read aloud. The human should feel
like they met a colleague and worked through their library state together.

Do not:
- write files directly
- skip the first-five-minutes relationship setup when this is the user's first true
  `/library` session
- present configuration as a numbered list or intake form
- pretend the scoreboard exists when the current build cannot render it yet

## Exit

- **DONE** — configuration round completed, required artifact handoffs were made, and the
  human has a clear next step
- **DONE_WITH_CONCERNS** — round completed, but the library is thin, a key override was
  accepted with risk, or a planned wizard-mode surface is not available yet
- **BLOCKED** — cannot proceed because required project context or artifact-writing
  support is unavailable
- **NEEDS_CONTEXT** — Raven still lacks the product or library information needed to
  derive a defensible configuration
