import { existsSync } from "fs";
import { homedir } from "os";
import { join, resolve } from "path";

function envValue(value: string | undefined): string | null {
  return value && value.length > 0 ? value : null;
}

export function envValueOrDefault(
  value: string | undefined,
  fallback: string,
): string {
  return envValue(value) ?? fallback;
}

export function resolveHomeDir(env: NodeJS.ProcessEnv): string {
  return envValue(env.HOME) ?? envValue(env.USERPROFILE) ?? homedir();
}

export function resolvePluginRoot(
  env: NodeJS.ProcessEnv,
  fallbackDir: string,
): string {
  const configuredRoot =
    envValue(env.ALEXANDRIA_PLUGIN_ROOT) ??
    envValue(env.CONTEXT_LIBRARY_PLUGIN_ROOT) ??
    envValue(env.CLAUDE_PLUGIN_ROOT);
  return configuredRoot
    ? resolve(configuredRoot)
    : resolve(fallbackDir, "../..");
}

export function resolveStateDir(env: NodeJS.ProcessEnv): string {
  const configuredStateDir =
    envValue(env.CLAUDE_PLUGIN_DATA) ??
    envValue(env.ALEXANDRIA_STATE_DIR) ??
    envValue(env.CONTEXT_LIBRARY_STATE_DIR);
  if (configuredStateDir) {
    return resolve(configuredStateDir);
  }

  const homeDir = resolveHomeDir(env);
  const alexandriaStateDir = join(homeDir, ".alexandria");
  const legacyStateDir = join(homeDir, ".context-library");

  if (existsSync(alexandriaStateDir) || !existsSync(legacyStateDir)) {
    return alexandriaStateDir;
  }

  return legacyStateDir;
}
