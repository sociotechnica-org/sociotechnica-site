export type MarkdownSemanticIssueKind =
  | "bare_glob_wildcard"
  | "glob_wildcard_replaced_with_underscore"
  | "inline_code_space_stripped"
  | "nested_blockquote_continuation"
  | "collapsed_numbered_list";

export interface MarkdownSemanticIssue {
  kind: MarkdownSemanticIssueKind;
  line: number;
  message: string;
  excerpt: string;
}

function stripInlineCode(line: string): string {
  return line.replace(/`[^`]*`/g, "").replace(/<code>.*?<\/code>/g, "");
}

function makeIssue(
  kind: MarkdownSemanticIssueKind,
  line: number,
  message: string,
  excerpt: string,
): MarkdownSemanticIssue {
  return { kind, line, message, excerpt };
}

export function findMarkdownSemanticIssues(
  markdown: string,
): MarkdownSemanticIssue[] {
  const issues: MarkdownSemanticIssue[] = [];
  const lines = markdown.split("\n");
  let inFence = false;
  let fenceMarker = "";

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!;
    const trimmed = line.trimStart();
    const fenceMatch = trimmed.match(/^(```+|~~~+)/);

    if (fenceMatch != null) {
      const marker = fenceMatch[1]![0]!;
      if (!inFence) {
        inFence = true;
        fenceMarker = marker;
      } else if (marker === fenceMarker) {
        inFence = false;
        fenceMarker = "";
      }
      continue;
    }

    if (inFence) {
      continue;
    }

    const proseOnly = stripInlineCode(line);

    if (/(^|[^`\\])((?:[A-Za-z0-9._/-]+)?\*\.[A-Za-z0-9]+)\b/.test(proseOnly)) {
      issues.push(
        makeIssue(
          "bare_glob_wildcard",
          i + 1,
          "Bare glob wildcard in prose can render incorrectly in Markdown; escape it or wrap it in code.",
          line,
        ),
      );
    }

    if (/(?:^|[^`\\])[A-Za-z0-9._/-]+-_\.[A-Za-z0-9]+\b/.test(proseOnly)) {
      issues.push(
        makeIssue(
          "glob_wildcard_replaced_with_underscore",
          i + 1,
          "Suspicious '-_.ext' pattern looks like a wildcard that was rewritten or typed incorrectly.",
          line,
        ),
      );
    }

    if (
      /`-` \(space, hyphen, space\)|`—` \(space, em dash, space\)|\(`-`\)|\(`—`\)/.test(
        line,
      )
    ) {
      issues.push(
        makeIssue(
          "inline_code_space_stripped",
          i + 1,
          "Inline code span appears to have lost significant surrounding spaces.",
          line,
        ),
      );
    }

    if (line === ">" && lines[i + 1]?.startsWith("> > ")) {
      issues.push(
        makeIssue(
          "nested_blockquote_continuation",
          i + 1,
          "Blank blockquote line followed by '> >' suggests Prettier nested a continuation blockquote.",
          `${line}\n${lines[i + 1] ?? ""}`,
        ),
      );
    }

    if (/^\*\*[^*]+\*\*\s+\d+\.\s+/.test(line)) {
      issues.push(
        makeIssue(
          "collapsed_numbered_list",
          i + 1,
          "Numbered list items appear collapsed onto one line.",
          line,
        ),
      );
    }
  }

  return issues;
}
