/**
 * Alexandria graph parser and traversal library.
 *
 * TypeScript implementation of the graph parser and traversal behavior.
 * Parses card markdown files into structured objects, builds a directed link
 * graph from [[wikilinks]], and exposes traversal primitives.
 */

import { readFileSync, readdirSync, statSync } from "fs";
import { resolve, relative, basename, join, sep } from "path";

// ── Constants ──────────────────────────────────────────────────────────

export const CARD_NAME_RE = /^(.+?) - (.+)$/;
export const WIKILINK_RE = /\[\[([^\]]+)\]\]/g;
export const SECTION_RE = /^## (.+)/gm;
export const H1_RE = /^# (.+)/m;

export const KNOWN_SECTIONS = new Set(["WHAT", "WHERE", "WHY", "WHEN", "HOW"]);

export const SECTION_ALIASES: Record<string, string> = {
  WHAT: "WHAT",
  WHERE: "WHERE",
  WHY: "WHY",
  WHEN: "WHEN",
  HOW: "HOW",
};

export const LAYER_FOLDERS: Record<string, string> = {
  rationale: "rationale",
  product: "product",
  experience: "experience",
  temporal: "temporal",
  releases: "releases",
  sources: "sources",
};

export const KNOWN_TYPES = new Set([
  "Product Thesis",
  "Principle",
  "Standard",
  "Domain",
  "Section",
  "Governance",
  "Template",
  "Component",
  "Artifact",
  "Capability",
  "Primitive",
  "System",
  "Agent",
  "Prompt",
  "Loop",
  "Journey",
  "Experience Goal",
  "Force",
  "Decision",
  "Initiative",
  "Future",
]);

export const SKIP_FILES = new Set([
  "README.md",
  "CONVENTIONS.md",
  "feedback-queue.jsonl",
  "signal-queue.jsonl",
  "wizard-output.md",
  "wizard-config.json",
]);

// ── Data types ─────────────────────────────────────────────────────────

export interface WikiLink {
  target: string;
  targetType: string | null;
  targetName: string | null;
  context: string;
  sourceSection: string;
  /** The full card name as it would appear in a filename. */
  readonly targetCardName: string;
}

export interface Section {
  canonical: string;
  header: string;
  content: string;
  wordCount: number;
  links: WikiLink[];
}

export interface CardDict {
  type: string | null;
  label: string | null;
  layer: string | null;
  sections: string[];
  missingSections: string[];
  linkCount: number;
  wordCount: number;
  parseErrors: string[];
}

export interface LibraryDict {
  root: string | null;
  cardCount: number;
  edgeCount: number;
  brokenLinkCount: number;
  orphanCount: number;
  typeDistribution: Record<string, number>;
  layerDistribution: Record<string, number>;
  linkDensity: number;
  cards: Record<string, CardDict>;
  scanErrors: string[];
}

export class Card {
  path: string;
  filename: string;
  cardName: string;
  cardType: string | null;
  cardLabel: string | null;
  layer: string | null;
  title: string | null = null;
  sections: Map<string, Section> = new Map();
  allLinks: WikiLink[] = [];
  rawContent: string = "";
  parseErrors: string[] = [];

  constructor(
    path: string,
    filename: string,
    cardName: string,
    cardType: string | null,
    cardLabel: string | null,
    layer: string | null,
  ) {
    this.path = path;
    this.filename = filename;
    this.cardName = cardName;
    this.cardType = cardType;
    this.cardLabel = cardLabel;
    this.layer = layer;
  }

  get totalWordCount(): number {
    let total = 0;
    for (const section of this.sections.values()) {
      total += section.wordCount;
    }
    return total;
  }

  get linkCount(): number {
    return this.allLinks.length;
  }

  get hasAllSections(): boolean {
    for (const s of KNOWN_SECTIONS) {
      if (!this.sections.has(s)) return false;
    }
    return true;
  }

  get missingSections(): Set<string> {
    const missing = new Set<string>();
    for (const s of KNOWN_SECTIONS) {
      if (!this.sections.has(s)) missing.add(s);
    }
    return missing;
  }
}

export interface Edge {
  source: string;
  target: string;
  sourceSection: string;
  context: string;
  resolved: boolean;
}

export interface BidirectionalGap {
  fromCard: string;
  toCard: string;
  section: string;
  context: string;
}

// ── Parsing helpers ────────────────────────────────────────────────────

export function extractTypeName(
  cardName: string,
): [string | null, string | null] {
  const m = CARD_NAME_RE.exec(cardName);
  if (m) {
    return [m[1]!.trim(), m[2]!.trim()];
  }
  return [null, null];
}

function detectLayer(filePath: string, libraryRoot: string): string | null {
  let rel: string;
  try {
    rel = relative(libraryRoot, filePath);
  } catch {
    return null;
  }
  const parts = rel.split(sep);
  for (const part of parts) {
    const lower = part.toLowerCase();
    if (Object.prototype.hasOwnProperty.call(LAYER_FOLDERS, lower)) {
      return LAYER_FOLDERS[lower] ?? null;
    }
  }
  return null;
}

function normalizeSectionName(header: string): string | null {
  if (!header) return null;
  const firstWord = header.split(":")[0]?.split(/\s+/)[0]?.trim().toUpperCase();
  if (
    firstWord &&
    Object.prototype.hasOwnProperty.call(SECTION_ALIASES, firstWord)
  ) {
    return SECTION_ALIASES[firstWord] ?? null;
  }
  return null;
}

function extractContext(line: string, linkText: string): string {
  const fullLink = `[[${linkText}]]`;
  const idx = line.indexOf(fullLink);
  if (idx < 0) return "";
  const afterRaw = line.slice(idx + fullLink.length).trim();
  const after = afterRaw.replace(/^[\s\u2014\-\u2013:]+/, "").trim();
  const beforeRaw = line.slice(0, idx).trim();
  const before = beforeRaw.replace(/[\s\u2014\-\u2013:]+$/, "").trim();
  return after || before;
}

function countWords(text: string): number {
  // Remove wikilinks but keep their text
  let cleaned = text.replace(/\[\[([^\]]+)\]\]/g, "$1");
  // Remove markdown formatting
  cleaned = cleaned.replace(/[#*_`[\]()>|]/g, " ");
  // Remove URLs
  cleaned = cleaned.replace(/https?:\/\/\S+/g, "");
  return cleaned.split(/\s+/).filter((w) => w.length > 0).length;
}

// ── Card parser ────────────────────────────────────────────────────────

export function parseCard(filePath: string, libraryRoot?: string): Card {
  const filename = basename(filePath);
  const cardName = filename.endsWith(".md") ? filename.slice(0, -3) : filename;
  const [cardType, cardLabel] = extractTypeName(cardName);
  const layer = libraryRoot != null ? detectLayer(filePath, libraryRoot) : null;

  const card = new Card(
    filePath,
    filename,
    cardName,
    cardType,
    cardLabel,
    layer,
  );

  let content: string;
  try {
    content = readFileSync(filePath, "utf8");
  } catch (e) {
    card.parseErrors.push(`Could not read file: ${e}`);
    return card;
  }

  card.rawContent = content;

  // Extract H1 title
  const h1Match = H1_RE.exec(content);
  if (h1Match) {
    card.title = h1Match[1]!.trim();
  }

  // Split into sections by ## headers
  const sectionMatches = [...content.matchAll(/^## (.+)/gm)];

  for (let i = 0; i < sectionMatches.length; i++) {
    const match = sectionMatches[i]!;
    const header = match[1]!.trim();
    const canonical = normalizeSectionName(header);
    if (canonical === null) continue;

    // Get content between this header and the next
    const start = (match.index ?? 0) + match[0]!.length;
    const nextMatch = sectionMatches[i + 1];
    const end =
      nextMatch != null ? (nextMatch.index ?? content.length) : content.length;
    const sectionContent = content.slice(start, end).trim();

    // Extract wikilinks from this section
    const links: WikiLink[] = [];
    for (const line of sectionContent.split("\n")) {
      for (const wlMatch of line.matchAll(/\[\[([^\]]+)\]\]/g)) {
        const linkText = wlMatch[1]!;
        const [lt, ln] = extractTypeName(linkText);
        const ctx = extractContext(line, linkText);
        const wikiLink: WikiLink = {
          target: linkText,
          targetType: lt,
          targetName: ln,
          context: ctx,
          sourceSection: canonical,
          get targetCardName() {
            return this.target;
          },
        };
        links.push(wikiLink);
      }
    }

    const section: Section = {
      canonical,
      header,
      content: sectionContent,
      wordCount: countWords(sectionContent),
      links,
    };

    if (card.sections.has(canonical)) {
      card.parseErrors.push(`Duplicate section: ${canonical}`);
    }
    card.sections.set(canonical, section);
    card.allLinks.push(...links);
  }

  return card;
}

// ── Recursive directory scanner ────────────────────────────────────────

function scanMdFiles(dir: string): string[] {
  const results: string[] = [];
  let entries: string[];
  try {
    entries = readdirSync(dir);
  } catch {
    return results;
  }
  for (const entry of entries) {
    const fullPath = join(dir, entry);
    let stat;
    try {
      stat = statSync(fullPath);
    } catch {
      continue;
    }
    if (stat.isDirectory()) {
      results.push(...scanMdFiles(fullPath));
    } else if (entry.endsWith(".md")) {
      results.push(fullPath);
    }
  }
  return results.sort();
}

// ── Library ────────────────────────────────────────────────────────────

export class Library {
  cards: Map<string, Card> = new Map();
  edges: Edge[] = [];
  private _outgoing: Map<string, Edge[]> = new Map();
  private _incoming: Map<string, Edge[]> = new Map();
  root: string | null = null;
  scanErrors: string[] = [];

  static fromDirectory(path: string): Library {
    const lib = new Library();
    const root = resolve(path);
    lib.root = root;

    let stat;
    try {
      stat = statSync(root);
    } catch {
      lib.scanErrors.push(`Not a directory: ${root}`);
      return lib;
    }
    if (!stat.isDirectory()) {
      lib.scanErrors.push(`Not a directory: ${root}`);
      return lib;
    }

    const mdFiles = scanMdFiles(root);

    for (const mdPath of mdFiles) {
      const filename = basename(mdPath);

      if (SKIP_FILES.has(filename)) continue;
      if (filename.startsWith(".")) continue;

      // Skip files that don't look like cards
      const cardName = filename.endsWith(".md")
        ? filename.slice(0, -3)
        : filename;
      if (!CARD_NAME_RE.test(cardName)) continue;

      const card = parseCard(mdPath, root);
      if (lib.cards.has(card.cardName)) {
        lib.scanErrors.push(
          `Duplicate card name: ${card.cardName} ` +
            `(at ${card.path} and ${lib.cards.get(card.cardName)!.path})`,
        );
      }
      lib.cards.set(card.cardName, card);
    }

    lib._buildEdges();
    return lib;
  }

  private _buildEdges(): void {
    this.edges = [];
    this._outgoing = new Map();
    this._incoming = new Map();

    for (const [cardName, card] of this.cards) {
      for (const link of card.allLinks) {
        const resolved = this.cards.has(link.target);
        const edge: Edge = {
          source: cardName,
          target: link.target,
          sourceSection: link.sourceSection,
          context: link.context,
          resolved,
        };
        this.edges.push(edge);

        if (!this._outgoing.has(cardName)) this._outgoing.set(cardName, []);
        this._outgoing.get(cardName)!.push(edge);

        if (!this._incoming.has(link.target))
          this._incoming.set(link.target, []);
        this._incoming.get(link.target)!.push(edge);
      }
    }
  }

  // ── Traversal primitives ──────────────────────────────────────────

  neighbors(
    cardName: string,
    hops: number = 1,
    direction: "outgoing" | "incoming" | "both" = "outgoing",
  ): Map<string, number> {
    if (!this.cards.has(cardName)) return new Map();

    const visited = new Map<string, number>();
    const queue: Array<[string, number]> = [[cardName, 0]];

    while (queue.length > 0) {
      const [current, dist] = queue.shift()!;
      if (dist > hops) continue;
      if (visited.has(current)) continue;
      visited.set(current, dist);

      if (dist < hops) {
        const nextEdges: Edge[] = [];
        if (direction === "outgoing" || direction === "both") {
          nextEdges.push(...(this._outgoing.get(current) ?? []));
        }
        if (direction === "incoming" || direction === "both") {
          nextEdges.push(...(this._incoming.get(current) ?? []));
        }

        for (const edge of nextEdges) {
          const neighbor = edge.source === current ? edge.target : edge.source;
          if (!visited.has(neighbor) && this.cards.has(neighbor)) {
            queue.push([neighbor, dist + 1]);
          }
        }
      }
    }

    visited.delete(cardName);
    return visited;
  }

  orphans(): string[] {
    const result: string[] = [];
    for (const cardName of this.cards.keys()) {
      const hasOutgoing = (this._outgoing.get(cardName) ?? []).some(
        (e) => e.resolved,
      );
      const hasIncoming = (this._incoming.get(cardName) ?? []).some(
        (e) => e.resolved,
      );
      if (!hasOutgoing && !hasIncoming) {
        result.push(cardName);
      }
    }
    return result.sort();
  }

  brokenLinks(): Edge[] {
    return this.edges.filter((e) => !e.resolved);
  }

  bidirectionalGaps(): BidirectionalGap[] {
    const linkPairs = new Set<string>();
    for (const edge of this.edges) {
      if (edge.resolved) {
        linkPairs.add(`${edge.source}\x00${edge.target}`);
      }
    }

    const gaps: BidirectionalGap[] = [];
    for (const edge of this.edges) {
      if (edge.resolved && !linkPairs.has(`${edge.target}\x00${edge.source}`)) {
        gaps.push({
          fromCard: edge.source,
          toCard: edge.target,
          section: edge.sourceSection,
          context: edge.context,
        });
      }
    }

    // Deduplicate by (fromCard, toCard) pair
    const seen = new Set<string>();
    const unique: BidirectionalGap[] = [];
    for (const gap of gaps) {
      const key = `${gap.fromCard}\x00${gap.toCard}`;
      if (!seen.has(key)) {
        seen.add(key);
        unique.push(gap);
      }
    }
    return unique;
  }

  components(): Set<string>[] {
    const visited = new Set<string>();
    const result: Set<string>[] = [];

    for (const cardName of this.cards.keys()) {
      if (visited.has(cardName)) continue;

      const component = new Set<string>();
      const queue: string[] = [cardName];

      while (queue.length > 0) {
        const current = queue.shift()!;
        if (visited.has(current)) continue;
        visited.add(current);
        component.add(current);

        for (const edge of this._outgoing.get(current) ?? []) {
          if (edge.resolved && !visited.has(edge.target)) {
            queue.push(edge.target);
          }
        }
        for (const edge of this._incoming.get(current) ?? []) {
          if (edge.resolved && !visited.has(edge.source)) {
            queue.push(edge.source);
          }
        }
      }

      if (component.size > 0) {
        result.push(component);
      }
    }

    return result;
  }

  cardsByType(cardType: string): Card[] {
    return [...this.cards.values()]
      .filter((c) => c.cardType === cardType)
      .sort((a, b) => a.cardName.localeCompare(b.cardName));
  }

  cardsByLayer(layer: string): Card[] {
    return [...this.cards.values()]
      .filter((c) => c.layer === layer)
      .sort((a, b) => a.cardName.localeCompare(b.cardName));
  }

  cardNames(): string[] {
    return [...this.cards.keys()].sort();
  }

  linkDensity(): number {
    if (this.cards.size === 0) return 0;
    let total = 0;
    for (const card of this.cards.values()) {
      total += card.linkCount;
    }
    return total / this.cards.size;
  }

  typeDistribution(): Record<string, number> {
    const dist: Record<string, number> = {};
    for (const card of this.cards.values()) {
      const t = card.cardType ?? "Unknown";
      dist[t] = (dist[t] ?? 0) + 1;
    }
    return Object.fromEntries(Object.entries(dist).sort());
  }

  layerDistribution(): Record<string, number> {
    const dist: Record<string, number> = {};
    for (const card of this.cards.values()) {
      const layer = card.layer ?? "unknown";
      dist[layer] = (dist[layer] ?? 0) + 1;
    }
    return Object.fromEntries(Object.entries(dist).sort());
  }

  toDict(): LibraryDict {
    const cards: Record<string, CardDict> = {};
    for (const [name, card] of [...this.cards.entries()].sort(([a], [b]) =>
      a.localeCompare(b),
    )) {
      cards[name] = {
        type: card.cardType,
        label: card.cardLabel,
        layer: card.layer,
        sections: [...card.sections.keys()],
        missingSections: [...card.missingSections].sort(),
        linkCount: card.linkCount,
        wordCount: card.totalWordCount,
        parseErrors: card.parseErrors,
      };
    }
    return {
      root: this.root,
      cardCount: this.cards.size,
      edgeCount: this.edges.length,
      brokenLinkCount: this.brokenLinks().length,
      orphanCount: this.orphans().length,
      typeDistribution: this.typeDistribution(),
      layerDistribution: this.layerDistribution(),
      linkDensity: Math.round(this.linkDensity() * 100) / 100,
      cards,
      scanErrors: this.scanErrors,
    };
  }
}
