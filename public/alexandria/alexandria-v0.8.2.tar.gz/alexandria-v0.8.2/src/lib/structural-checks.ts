import { existsSync, readdirSync, readFileSync, statSync } from "fs";
import { basename, dirname, extname, join } from "path";

export interface StructuralResult {
  name: string;
  pass: boolean;
}

export interface StructuralReport {
  checks: StructuralResult[];
  pass_count: number;
  fail_count: number;
  total: number;
  skipped?: boolean;
}

export function pass(name: string): StructuralResult {
  return { name, pass: true };
}

export function fail(name: string): StructuralResult {
  return { name, pass: false };
}

export function buildReport(
  checks: StructuralResult[],
  skipped = false,
): StructuralReport {
  const passCount = checks.filter((check) => check.pass).length;
  const failCount = checks.length - passCount;
  return {
    checks,
    pass_count: passCount,
    fail_count: failCount,
    total: checks.length,
    ...(skipped ? { skipped: true } : {}),
  };
}

export function isFile(path: string): boolean {
  try {
    return statSync(path).isFile();
  } catch {
    return false;
  }
}

export function isDirectory(path: string): boolean {
  try {
    return statSync(path).isDirectory();
  } catch {
    return false;
  }
}

export function readText(path: string): string {
  return readFileSync(path, "utf8");
}

export function readJson<T>(path: string): T | null {
  try {
    return JSON.parse(readText(path)) as T;
  } catch {
    return null;
  }
}

export function wordCount(text: string): number {
  const words = text.trim().match(/\S+/g);
  return words ? words.length : 0;
}

export function walkFiles(dir: string): string[] {
  if (!isDirectory(dir)) {
    return [];
  }

  const files: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const fullPath = join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...walkFiles(fullPath));
      continue;
    }
    if (entry.isFile()) {
      files.push(fullPath);
    }
  }

  return files.sort();
}

export function findFiles(
  dir: string,
  predicate: (path: string) => boolean,
): string[] {
  return walkFiles(dir).filter(predicate);
}

export function findFirstFile(
  dir: string,
  predicate: (path: string) => boolean,
): string | null {
  return findFiles(dir, predicate)[0] ?? null;
}

export function siblingTranscript(outputDir: string): string | null {
  const transcript = join(dirname(outputDir), "transcript.md");
  return isFile(transcript) ? transcript : null;
}

export function caseNameFromOutputDir(outputDir: string): string {
  return basename(dirname(outputDir));
}

export function basenameWithoutExtension(path: string): string {
  return basename(path, extname(path));
}

export function normalizeFiles(
  files: Array<string | null | undefined>,
): string[] {
  const existing = files.filter(
    (file): file is string =>
      file !== null && file !== undefined && isFile(file),
  );
  return Array.from(new Set(existing));
}

function nonGlobalRegex(pattern: RegExp): RegExp {
  const flags = pattern.flags.replaceAll("g", "");
  return new RegExp(pattern.source, flags);
}

export function lineCount(text: string, pattern: RegExp): number {
  const regex = nonGlobalRegex(pattern);
  return text.split(/\r?\n/).filter((line) => {
    regex.lastIndex = 0;
    return regex.test(line);
  }).length;
}

export function lineMatch(text: string, pattern: RegExp): boolean {
  return lineCount(text, pattern) > 0;
}

export function countMatchesInFiles(files: string[], pattern: RegExp): number {
  return files.reduce(
    (total, file) => total + lineCount(readText(file), pattern),
    0,
  );
}

export function anyMatchInFiles(files: string[], pattern: RegExp): boolean {
  return files.some((file) => lineMatch(readText(file), pattern));
}

export function collectMatches(text: string, pattern: RegExp): string[] {
  const flags = pattern.flags.includes("g")
    ? pattern.flags
    : `${pattern.flags}g`;
  const regex = new RegExp(pattern.source, flags);
  const matches: string[] = [];
  for (const match of text.matchAll(regex)) {
    matches.push(match[0]);
  }
  return matches;
}

export function uniqueMatches(text: string, pattern: RegExp): string[] {
  return Array.from(new Set(collectMatches(text, pattern)));
}

export function uniqueMatchesInFiles(
  files: string[],
  pattern: RegExp,
): string[] {
  return Array.from(
    new Set(files.flatMap((file) => uniqueMatches(readText(file), pattern))),
  );
}

export function sectionText(path: string, heading: string): string {
  if (!isFile(path)) {
    return "";
  }

  const lines = readText(path).split(/\r?\n/);
  const headingPattern = new RegExp(`^## ${heading}(\\b|:)`);
  const start = lines.findIndex((line) => headingPattern.test(line));
  if (start === -1) {
    return "";
  }

  const collected: string[] = [];
  for (let index = start; index < lines.length; index += 1) {
    const line = lines[index] ?? "";
    if (index > start && /^## /.test(line)) {
      break;
    }
    collected.push(line);
  }

  return collected.join("\n");
}

export function hasYamlFrontmatter(path: string): boolean {
  if (!isFile(path)) {
    return false;
  }

  const firstLine = readText(path).split(/\r?\n/, 1)[0] ?? "";
  return firstLine === "---";
}

export function cardReferencePattern(): RegExp {
  return /(Capability|Component|Section|System|Domain|Primitive|Decision|Loop|Journey|Experience Goal|Force|Governance|Template|Standard|Principle|Product Vision|Product Thesis) - /;
}

export function fileExists(path: string): boolean {
  return existsSync(path);
}
