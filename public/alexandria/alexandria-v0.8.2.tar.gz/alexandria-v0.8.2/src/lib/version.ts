import { existsSync, readFileSync } from "fs";

export function readContextLibraryVersion(versionFile: string): string | null {
  if (!existsSync(versionFile)) {
    return null;
  }

  const version = readFileSync(versionFile, "utf-8").trim();
  return version.length > 0 ? version : null;
}
