export function resolveBunExecutable(execPath: string): string {
  const normalized = execPath.toLowerCase();
  return normalized.endsWith("bun") || normalized.endsWith("bun.exe")
    ? execPath
    : "bun";
}
