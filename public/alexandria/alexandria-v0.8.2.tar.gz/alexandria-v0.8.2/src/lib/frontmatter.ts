/**
 * YAML frontmatter parsing via gray-matter.
 *
 * Handles ticket, outcome, skill, and card frontmatter including the
 * `requires:` capability schema used by skill files.
 */

import matter from "gray-matter";

// ── Types ──────────────────────────────────────────────────────────────

export interface CapabilityRequirements {
  adherence?: "low" | "medium" | "high";
  reasoning?: "low" | "medium" | "high";
  precision?: "low" | "medium" | "high";
  volume?: "low" | "medium" | "high";
}

export interface SkillFrontmatter {
  name?: string;
  description?: string;
  requires?: CapabilityRequirements;
  [key: string]: unknown;
}

export interface TicketFrontmatter {
  id?: string;
  title?: string;
  outcome?: string;
  tier?: "must" | "should" | "could";
  enabler?: boolean;
  "blocked-by"?: string[];
  blocks?: string[];
  cards?: string[];
  [key: string]: unknown;
}

export interface OutcomeFrontmatter {
  id?: string;
  title?: string;
  description?: string;
  [key: string]: unknown;
}

export interface CardFrontmatter {
  type?: string;
  layer?: string;
  status?: string;
  [key: string]: unknown;
}

export interface ParsedFrontmatter<T = Record<string, unknown>> {
  data: T;
  content: string;
  /** The original markdown including frontmatter */
  orig: string;
}

// ── Parser ─────────────────────────────────────────────────────────────

/**
 * Parse frontmatter from a markdown string.
 * Returns the parsed data and the body content (without frontmatter).
 * Never throws — returns empty data on parse errors.
 */
export function parseFrontmatter<T = Record<string, unknown>>(
  markdown: string,
): ParsedFrontmatter<T> {
  try {
    const result = matter(markdown);
    return {
      data: result.data as T,
      content: result.content,
      orig: markdown,
    };
  } catch {
    return {
      data: {} as T,
      content: markdown,
      orig: markdown,
    };
  }
}

/** Parse skill frontmatter (includes `requires:` capability schema). */
export function parseSkillFrontmatter(
  markdown: string,
): ParsedFrontmatter<SkillFrontmatter> {
  return parseFrontmatter<SkillFrontmatter>(markdown);
}

/** Parse ticket frontmatter. */
export function parseTicketFrontmatter(
  markdown: string,
): ParsedFrontmatter<TicketFrontmatter> {
  return parseFrontmatter<TicketFrontmatter>(markdown);
}

/** Parse outcome frontmatter. */
export function parseOutcomeFrontmatter(
  markdown: string,
): ParsedFrontmatter<OutcomeFrontmatter> {
  return parseFrontmatter<OutcomeFrontmatter>(markdown);
}

/** Parse card frontmatter. */
export function parseCardFrontmatter(
  markdown: string,
): ParsedFrontmatter<CardFrontmatter> {
  return parseFrontmatter<CardFrontmatter>(markdown);
}

/** Check if a markdown string has any frontmatter. */
export function hasFrontmatter(markdown: string): boolean {
  return markdown.startsWith("---");
}
