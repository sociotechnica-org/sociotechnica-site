/**
 * Markdown file utilities.
 *
 * File reading, directory listing, and section extraction helpers.
 */

import { readFileSync, readdirSync, statSync } from "fs";
import { join, resolve, basename } from "path";
import { parseFrontmatter } from "./frontmatter.js";

// ── Types ──────────────────────────────────────────────────────────────

export interface MarkdownFile {
  path: string;
  filename: string;
  content: string;
  frontmatter: Record<string, unknown>;
  body: string;
}

export interface MarkdownSection {
  heading: string;
  level: number;
  content: string;
}

// ── File reading ───────────────────────────────────────────────────────

/**
 * Read a markdown file and parse its frontmatter.
 * Returns null if the file cannot be read.
 */
export function readMarkdownFile(filePath: string): MarkdownFile | null {
  try {
    const content = readFileSync(filePath, "utf8");
    const parsed = parseFrontmatter(content);
    return {
      path: resolve(filePath),
      filename: basename(filePath),
      content,
      frontmatter: parsed.data,
      body: parsed.content,
    };
  } catch {
    return null;
  }
}

// ── Directory listing ──────────────────────────────────────────────────

/**
 * List all markdown files in a directory (non-recursive).
 */
export function listMarkdownFiles(dir: string): string[] {
  try {
    return readdirSync(dir)
      .filter((f) => f.endsWith(".md"))
      .map((f) => join(dir, f))
      .sort();
  } catch {
    return [];
  }
}

/**
 * List all markdown files in a directory recursively.
 */
export function listMarkdownFilesRecursive(dir: string): string[] {
  const results: string[] = [];

  function scan(d: string): void {
    let entries: string[];
    try {
      entries = readdirSync(d);
    } catch {
      return;
    }
    for (const entry of entries) {
      const fullPath = join(d, entry);
      let stat;
      try {
        stat = statSync(fullPath);
      } catch {
        continue;
      }
      if (stat.isDirectory()) {
        scan(fullPath);
      } else if (entry.endsWith(".md")) {
        results.push(fullPath);
      }
    }
  }

  scan(dir);
  return results.sort();
}

// ── Section extraction ─────────────────────────────────────────────────

/**
 * Extract all heading sections from markdown content.
 * Each section includes the heading text, level (1-6), and content that follows.
 */
export function extractSections(markdown: string): MarkdownSection[] {
  const headingRe = /^(#{1,6}) (.+)/gm;
  const matches = [...markdown.matchAll(headingRe)];
  const sections: MarkdownSection[] = [];

  for (let i = 0; i < matches.length; i++) {
    const match = matches[i]!;
    const level = match[1]!.length;
    const heading = match[2]!.trim();
    const start = (match.index ?? 0) + match[0]!.length;
    const nextMatch = matches[i + 1];
    const end =
      nextMatch != null
        ? (nextMatch.index ?? markdown.length)
        : markdown.length;
    const content = markdown.slice(start, end).trim();
    sections.push({ heading, level, content });
  }

  return sections;
}

/**
 * Extract the content of a specific section by heading text (case-insensitive prefix match).
 * Returns null if not found.
 */
export function extractSection(
  markdown: string,
  headingPrefix: string,
): string | null {
  const sections = extractSections(markdown);
  const prefix = headingPrefix.toUpperCase();
  const found = sections.find((s) =>
    s.heading.toUpperCase().startsWith(prefix),
  );
  return found?.content ?? null;
}
