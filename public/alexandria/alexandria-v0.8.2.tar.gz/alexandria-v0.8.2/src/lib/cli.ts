/**
 * CLI output helpers.
 *
 * Colored terminal output, argument parsing, and table formatting.
 */

// ── ANSI colors ────────────────────────────────────────────────────────

const RESET = "\x1b[0m";
const GREEN = "\x1b[32m";
const RED = "\x1b[31m";
const YELLOW = "\x1b[33m";
const CYAN = "\x1b[36m";
const BOLD = "\x1b[1m";
const DIM = "\x1b[2m";

function isColorEnabled(): boolean {
  if (process.env["NO_COLOR"] != null) return false;
  if (process.env["FORCE_COLOR"] != null) return true;
  return process.stdout.isTTY === true;
}

function colorize(text: string, code: string): string {
  if (!isColorEnabled()) return text;
  return `${code}${text}${RESET}`;
}

export const color = {
  green: (s: string) => colorize(s, GREEN),
  red: (s: string) => colorize(s, RED),
  yellow: (s: string) => colorize(s, YELLOW),
  cyan: (s: string) => colorize(s, CYAN),
  bold: (s: string) => colorize(s, BOLD),
  dim: (s: string) => colorize(s, DIM),
};

// ── Log helpers ────────────────────────────────────────────────────────

export function pass(msg: string): void {
  console.log(`  ${color.green("PASS")}  ${msg}`);
}

export function fail(msg: string): void {
  console.error(`  ${color.red("FAIL")}  ${msg}`);
}

export function warn(msg: string): void {
  console.error(`  ${color.yellow("WARN")}  ${msg}`);
}

export function info(msg: string): void {
  console.log(`  ${color.cyan("INFO")}  ${msg}`);
}

export function header(msg: string): void {
  console.log(`\n${color.bold(msg)}`);
}

// ── Argument parsing ───────────────────────────────────────────────────

export interface ParsedArgs {
  /** Positional arguments */
  positional: string[];
  /** Named flags (e.g., --verbose → { verbose: true }) */
  flags: Record<string, string | boolean>;
}

/**
 * Minimal argument parser for CLI scripts.
 * Supports:
 *   --flag          → { flag: true }
 *   --key value     → { key: "value" }
 *   --key=value     → { key: "value" }
 *   positional args → positional[]
 */
export function parseArgs(args: string[]): ParsedArgs {
  const positional: string[] = [];
  const flags: Record<string, string | boolean> = {};

  let i = 0;
  while (i < args.length) {
    const arg = args[i]!;
    if (arg.startsWith("--")) {
      const eqIdx = arg.indexOf("=");
      if (eqIdx >= 0) {
        const key = arg.slice(2, eqIdx);
        const val = arg.slice(eqIdx + 1);
        flags[key] = val;
      } else {
        const key = arg.slice(2);
        const next = args[i + 1];
        if (next != null && !next.startsWith("-")) {
          flags[key] = next;
          i++;
        } else {
          flags[key] = true;
        }
      }
    } else if (arg.startsWith("-") && arg.length === 2) {
      const key = arg.slice(1);
      const next = args[i + 1];
      if (next != null && !next.startsWith("-")) {
        flags[key] = next;
        i++;
      } else {
        flags[key] = true;
      }
    } else {
      positional.push(arg);
    }
    i++;
  }

  return { positional, flags };
}

// ── Table formatting ───────────────────────────────────────────────────

export interface TableRow {
  [key: string]: string | number | boolean | null | undefined;
}

/**
 * Format an array of objects as an ASCII table.
 * Columns are derived from the keys of the first row.
 */
export function formatTable(rows: TableRow[], columns?: string[]): string {
  if (rows.length === 0) return "(empty)";

  const cols = columns ?? Object.keys(rows[0]!);
  const widths = cols.map((col) =>
    Math.max(col.length, ...rows.map((row) => String(row[col] ?? "").length)),
  );

  const separator = widths.map((w) => "-".repeat(w)).join("-+-");
  const header = cols.map((col, i) => col.padEnd(widths[i]!)).join(" | ");

  const bodyRows = rows.map((row) =>
    cols.map((col, i) => String(row[col] ?? "").padEnd(widths[i]!)).join(" | "),
  );

  return [header, separator, ...bodyRows].join("\n");
}

/**
 * Print a table to stdout.
 */
export function printTable(rows: TableRow[], columns?: string[]): void {
  console.log(formatTable(rows, columns));
}
