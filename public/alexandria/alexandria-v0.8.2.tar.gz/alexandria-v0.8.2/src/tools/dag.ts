/**
 * Alexandria DAG Tool
 *
 * Reads ticket and outcome markdown files from a plan directory, parses YAML
 * frontmatter, validates the dependency graph, computes execution phases and
 * critical path.
 *
 * Usage:
 *   alexandria-dag <plan-dir>                    # text output (default)
 *   alexandria-dag <plan-dir> --format text      # human-readable phases
 *   alexandria-dag <plan-dir> --format json      # machine-readable
 *   alexandria-dag <plan-dir> --format mermaid   # mermaid diagram
 *   alexandria-dag <plan-dir> --validate         # exit 0 if valid, 1 if not
 *   alexandria-dag <plan-dir> --strict           # orphans are errors too
 */

import { existsSync, readdirSync, statSync } from "fs";
import { join } from "path";
import {
  parseTicketFrontmatter,
  parseOutcomeFrontmatter,
} from "../lib/frontmatter.js";
import { listMarkdownFiles, readMarkdownFile } from "../lib/markdown.js";
import { parseArgs } from "../lib/cli.js";

// ── Types ──────────────────────────────────────────────────────────────

interface Ticket {
  id: string;
  title?: string;
  outcome?: string | null;
  enabler?: string | boolean | null;
  "blocked-by"?: string[];
  blocks?: string[];
  [key: string]: unknown;
}

interface Outcome {
  id: string;
  title?: string;
  [key: string]: unknown;
}

// ── Helpers ────────────────────────────────────────────────────────────

function toStringArray(val: unknown): string[] {
  if (!val) return [];
  if (Array.isArray(val))
    return val.filter((v): v is string => typeof v === "string");
  if (typeof val === "string") return val.length > 0 ? [val] : [];
  return [];
}

// ── Load plan ──────────────────────────────────────────────────────────

function loadPlan(planDir: string): {
  tickets: Map<string, Ticket>;
  outcomes: Map<string, Outcome>;
  errors: string[];
} {
  const tickets = new Map<string, Ticket>();
  const outcomes = new Map<string, Outcome>();
  const errors: string[] = [];

  const ticketsDir = join(planDir, "tickets");
  if (existsSync(ticketsDir) && statSync(ticketsDir).isDirectory()) {
    for (const fpath of listMarkdownFiles(ticketsDir)) {
      const file = readMarkdownFile(fpath);
      if (!file) {
        errors.push(`Could not parse frontmatter in ${fpath}`);
        continue;
      }
      const { data } = parseTicketFrontmatter(file.content);
      if (data.id) {
        tickets.set(data.id, data as unknown as Ticket);
      } else {
        errors.push(`Ticket file ${file.filename} missing 'id' in frontmatter`);
      }
    }
  }

  const outcomesDir = join(planDir, "outcomes");
  if (existsSync(outcomesDir) && statSync(outcomesDir).isDirectory()) {
    for (const fpath of listMarkdownFiles(outcomesDir)) {
      const file = readMarkdownFile(fpath);
      if (!file) {
        errors.push(`Could not parse frontmatter in ${fpath}`);
        continue;
      }
      const { data } = parseOutcomeFrontmatter(file.content);
      if (data.id) {
        outcomes.set(data.id, data as unknown as Outcome);
      } else {
        errors.push(
          `Outcome file ${file.filename} missing 'id' in frontmatter`,
        );
      }
    }
  }

  // Flat fallback: if no tickets/ subdir exists, scan plan dir root
  if (tickets.size === 0 && !existsSync(ticketsDir)) {
    const entries = readdirSync(planDir).sort();
    for (const fname of entries) {
      if (!fname.endsWith(".md") || fname === "release.md") continue;
      const fpath = join(planDir, fname);
      if (!statSync(fpath).isFile()) continue;
      const file = readMarkdownFile(fpath);
      if (!file) continue;
      const { data } = parseTicketFrontmatter(file.content);
      if (!data.id) continue;
      if (data.tier || data.outcome) {
        tickets.set(data.id, data as unknown as Ticket);
      } else if ("cards" in data) {
        const { data: od } = parseOutcomeFrontmatter(file.content);
        if (od.id) outcomes.set(od.id, od as unknown as Outcome);
      }
    }
  }

  return { tickets, outcomes, errors };
}

// ── Validate edges ─────────────────────────────────────────────────────

function validateEdges(tickets: Map<string, Ticket>): string[] {
  const warnings: string[] = [];

  for (const [tid, ticket] of tickets) {
    const blockedBy = toStringArray(ticket["blocked-by"]);
    const blocks = toStringArray(ticket.blocks);

    for (const depId of blockedBy) {
      if (!tickets.has(depId)) {
        warnings.push(`${tid} blocked-by ${depId}, but ${depId} doesn't exist`);
        continue;
      }
      const depBlocks = toStringArray(tickets.get(depId)!.blocks);
      if (!depBlocks.includes(tid)) {
        warnings.push(
          `${tid} blocked-by ${depId}, but ${depId} doesn't list ${tid} in blocks`,
        );
      }
    }

    for (const depId of blocks) {
      if (!tickets.has(depId)) {
        warnings.push(`${tid} blocks ${depId}, but ${depId} doesn't exist`);
        continue;
      }
      const depBlockedBy = toStringArray(tickets.get(depId)!["blocked-by"]);
      if (!depBlockedBy.includes(tid)) {
        warnings.push(
          `${tid} blocks ${depId}, but ${depId} doesn't list ${tid} in blocked-by`,
        );
      }
    }
  }

  return warnings;
}

// ── Detect orphans ─────────────────────────────────────────────────────

function detectOrphans(
  tickets: Map<string, Ticket>,
  outcomes: Map<string, Outcome>,
): { orphanTickets: string[]; orphanOutcomes: string[] } {
  const orphanTickets: string[] = [];
  const orphanOutcomes: string[] = [];

  if (outcomes.size === 0) return { orphanTickets, orphanOutcomes };

  const outcomeIds = new Set(outcomes.keys());
  const referencedOutcomes = new Set<string>();

  for (const [tid, ticket] of tickets) {
    const outcome = ticket.outcome;
    if (!outcome || outcome === "false") {
      orphanTickets.push(tid);
    } else if (!outcomeIds.has(outcome)) {
      orphanTickets.push(
        `${tid} (references non-existent outcome: ${outcome})`,
      );
    } else {
      referencedOutcomes.add(outcome);
    }
  }

  for (const oid of outcomeIds) {
    if (!referencedOutcomes.has(oid)) {
      orphanOutcomes.push(oid);
    }
  }

  return { orphanTickets, orphanOutcomes };
}

// ── Cycle detection + topological sort ────────────────────────────────

function findCycle(
  graph: Map<string, Set<string>>,
  nodes: Set<string>,
): string[] {
  const visited = new Set<string>();
  const path: string[] = [];

  function dfs(node: string): string[] | null {
    if (visited.has(node)) {
      const cycleStart = path.indexOf(node);
      return [...path.slice(cycleStart), node];
    }
    visited.add(node);
    path.push(node);
    for (const dep of graph.get(node) ?? []) {
      if (nodes.has(dep)) {
        const result = dfs(dep);
        if (result) return result;
      }
    }
    path.pop();
    return null;
  }

  for (const node of [...nodes].sort()) {
    visited.clear();
    path.length = 0;
    const result = dfs(node);
    if (result) return result;
  }

  return [...nodes]; // Fallback
}

function detectCyclesAndSort(tickets: Map<string, Ticket>): {
  sortedIds: string[];
  cycle: string[] | null;
} {
  const graph = new Map<string, Set<string>>();
  const reverseGraph = new Map<string, Set<string>>();

  for (const tid of tickets.keys()) {
    if (!graph.has(tid)) graph.set(tid, new Set());
    if (!reverseGraph.has(tid)) reverseGraph.set(tid, new Set());
  }

  for (const [tid, ticket] of tickets) {
    for (const dep of toStringArray(ticket["blocked-by"])) {
      if (tickets.has(dep)) {
        graph.get(tid)!.add(dep);
        if (!reverseGraph.has(dep)) reverseGraph.set(dep, new Set());
        reverseGraph.get(dep)!.add(tid);
      }
    }
  }

  const inDegree = new Map<string, number>();
  for (const [tid] of tickets) {
    inDegree.set(tid, graph.get(tid)?.size ?? 0);
  }

  const queue = [...tickets.keys()]
    .filter((tid) => inDegree.get(tid) === 0)
    .sort();
  const sortedIds: string[] = [];

  while (queue.length > 0) {
    queue.sort();
    const node = queue.shift()!;
    sortedIds.push(node);
    for (const dependent of [...(reverseGraph.get(node) ?? [])].sort()) {
      const deg = (inDegree.get(dependent) ?? 0) - 1;
      inDegree.set(dependent, deg);
      if (deg === 0) queue.push(dependent);
    }
  }

  if (sortedIds.length !== tickets.size) {
    const remaining = new Set(
      [...tickets.keys()].filter((tid) => !sortedIds.includes(tid)),
    );
    return { sortedIds, cycle: findCycle(graph, remaining) };
  }

  return { sortedIds, cycle: null };
}

// ── Compute phases ─────────────────────────────────────────────────────

function computePhases(tickets: Map<string, Ticket>): string[][] {
  const phases: string[][] = [];
  const remaining = new Map(tickets);
  const completed = new Set<string>();

  while (remaining.size > 0) {
    const ready: string[] = [];
    for (const [tid, ticket] of remaining) {
      const deps = toStringArray(ticket["blocked-by"]).filter((d) =>
        tickets.has(d),
      );
      if (deps.every((d) => completed.has(d))) ready.push(tid);
    }
    if (ready.length === 0) break;
    ready.sort();
    phases.push(ready);
    for (const tid of ready) {
      completed.add(tid);
      remaining.delete(tid);
    }
  }

  return phases;
}

// ── Compute critical path ──────────────────────────────────────────────

function computeCriticalPath(tickets: Map<string, Ticket>): string[] {
  const memo = new Map<string, string[]>();
  const visiting = new Set<string>();

  function longestFrom(tid: string): string[] {
    if (memo.has(tid)) return memo.get(tid)!;
    if (visiting.has(tid)) {
      memo.set(tid, [tid]);
      return [tid];
    }
    visiting.add(tid);

    const validBlocks = toStringArray(tickets.get(tid)?.blocks).filter((b) =>
      tickets.has(b),
    );

    if (validBlocks.length === 0) {
      memo.set(tid, [tid]);
      visiting.delete(tid);
      return [tid];
    }

    let best: string[] = [];
    for (const dep of validBlocks) {
      const path = longestFrom(dep);
      if (path.length > best.length) best = path;
    }

    const result = [tid, ...best];
    memo.set(tid, result);
    visiting.delete(tid);
    return result;
  }

  let bestPath: string[] = [];
  for (const tid of tickets.keys()) {
    const path = longestFrom(tid);
    if (path.length > bestPath.length) bestPath = path;
  }

  return bestPath;
}

// ── Output formatters ──────────────────────────────────────────────────

function formatText(
  tickets: Map<string, Ticket>,
  phases: string[][],
  criticalPath: string[],
  warnings: string[],
  orphanTickets: string[],
  orphanOutcomes: string[],
): string {
  const lines: string[] = [];

  for (let i = 0; i < phases.length; i++) {
    const phaseNum = i + 1;
    const desc =
      phaseNum === 1 ? "can start immediately" : `after Phase ${phaseNum - 1}`;
    lines.push(`Phase ${phaseNum} (${desc}):`);
    for (const tid of phases[i]!) {
      const title = tickets.get(tid)?.title ?? tid;
      lines.push(`  - ${tid}: ${title}`);
    }
    lines.push("");
  }

  lines.push(
    `Critical path: ${criticalPath.join(" → ")} (${criticalPath.length} tickets)`,
  );
  lines.push("");

  if (warnings.length > 0) {
    lines.push("Edge warnings:");
    for (const w of warnings) lines.push(`  ⚠ ${w}`);
    lines.push("");
  }

  if (orphanTickets.length > 0) {
    lines.push("Orphan tickets (no outcome):");
    for (const t of orphanTickets) lines.push(`  ⚠ ${t}`);
    lines.push("");
  }

  if (orphanOutcomes.length > 0) {
    lines.push("Orphan outcomes (no tickets):");
    for (const o of orphanOutcomes) lines.push(`  ⚠ ${o}`);
    lines.push("");
  }

  return lines.join("\n");
}

function formatJson(
  tickets: Map<string, Ticket>,
  outcomes: Map<string, Outcome>,
  phases: string[][],
  criticalPath: string[],
  warnings: string[],
  orphanTickets: string[],
  orphanOutcomes: string[],
  errors: string[],
): string {
  return JSON.stringify(
    {
      phases: phases.map((p) => [...p]),
      critical_path: criticalPath,
      critical_path_length: criticalPath.length,
      ticket_count: tickets.size,
      outcome_count: outcomes.size,
      validation: {
        edge_warnings: warnings,
        orphan_tickets: orphanTickets,
        orphan_outcomes: orphanOutcomes,
        parse_errors: errors,
        is_valid: warnings.length === 0 && errors.length === 0,
      },
    },
    null,
    2,
  );
}

function formatMermaid(tickets: Map<string, Ticket>): string {
  const lines: string[] = ["graph LR"];

  for (const [tid, ticket] of [...tickets.entries()].sort(([a], [b]) =>
    a.localeCompare(b),
  )) {
    let title = ticket.title ?? tid;
    if (title.length > 40) title = title.slice(0, 37) + "...";
    title = title.replace(/"/g, "'");
    const enabler = ticket.enabler;
    if (enabler && enabler !== "false") {
      lines.push(`    ${tid}(["${tid}: ${title}"])`);
    } else {
      lines.push(`    ${tid}["${tid}: ${title}"]`);
    }
  }

  lines.push("");

  for (const [tid, ticket] of [...tickets.entries()].sort(([a], [b]) =>
    a.localeCompare(b),
  )) {
    for (const dep of toStringArray(ticket.blocks).sort()) {
      if (tickets.has(dep)) lines.push(`    ${tid} --> ${dep}`);
    }
  }

  return lines.join("\n");
}

// ── Main ───────────────────────────────────────────────────────────────

const args = parseArgs(process.argv.slice(2));
const planDir = args.positional[0];

if (!planDir || args.flags["h"] === true || args.flags["help"] === true) {
  console.log(
    `Usage:
  alexandria-dag <plan-dir>                    # text output (default)
  alexandria-dag <plan-dir> --format text      # human-readable phases
  alexandria-dag <plan-dir> --format json      # machine-readable
  alexandria-dag <plan-dir> --format mermaid   # mermaid diagram
  alexandria-dag <plan-dir> --validate         # exit 0 if valid, 1 if not
  alexandria-dag <plan-dir> --strict           # orphans are errors too`,
  );
  process.exit(0);
}

if (!existsSync(planDir) || !statSync(planDir).isDirectory()) {
  console.error(`Error: ${planDir} is not a directory`);
  process.exit(1);
}

const fmt = (args.flags["format"] as string) ?? "text";
const validateOnly = args.flags["validate"] === true;
const strict = args.flags["strict"] === true;

const { tickets, outcomes, errors } = loadPlan(planDir);

if (tickets.size === 0) {
  if (validateOnly) {
    console.log("No tickets found");
    process.exit(1);
  }
  console.log(`No tickets found in ${planDir}`);
  process.exit(0);
}

const warnings = validateEdges(tickets);
const { orphanTickets, orphanOutcomes } = detectOrphans(tickets, outcomes);
const { cycle } = detectCyclesAndSort(tickets);

if (cycle) {
  const cycleStr = cycle.join(" → ");
  if (validateOnly || fmt === "json") {
    console.log(
      JSON.stringify(
        {
          error: "cycle_detected",
          cycle,
          cycle_path: cycleStr,
          validation: { edge_warnings: warnings, is_valid: false },
        },
        null,
        2,
      ),
    );
  } else {
    console.error(`Error: cycle detected: ${cycleStr}`);
  }
  process.exit(1);
}

const phases = computePhases(tickets);
const criticalPath = computeCriticalPath(tickets);

if (validateOnly) {
  let hasErrors = warnings.length > 0 || errors.length > 0;
  if (strict)
    hasErrors =
      hasErrors || orphanTickets.length > 0 || orphanOutcomes.length > 0;

  if (hasErrors) {
    for (const w of warnings) console.error(`Warning: ${w}`);
    for (const e of errors) console.error(`Error: ${e}`);
    if (strict) {
      for (const t of orphanTickets) console.error(`Orphan ticket: ${t}`);
      for (const o of orphanOutcomes) console.error(`Orphan outcome: ${o}`);
    }
    process.exit(1);
  } else {
    console.log("Valid");
    process.exit(0);
  }
}

if (fmt === "text") {
  console.log(
    formatText(
      tickets,
      phases,
      criticalPath,
      warnings,
      orphanTickets,
      orphanOutcomes,
    ),
  );
} else if (fmt === "json") {
  console.log(
    formatJson(
      tickets,
      outcomes,
      phases,
      criticalPath,
      warnings,
      orphanTickets,
      orphanOutcomes,
      errors,
    ),
  );
} else if (fmt === "mermaid") {
  console.log(formatMermaid(tickets));
}
