/**
 * Alexandria card linter.
 *
 * Runs deterministic sweeps 1-5 against a context library directory.
 * Replaces the mechanical checks that Nit currently performs via LLM.
 *
 * Usage:
 *   alexandria-lint --library docs/alexandria/
 *   alexandria-lint --library docs/alexandria/ --sweep 1,2
 *   alexandria-lint --library docs/alexandria/ --sweep all --format json
 *   alexandria-lint --library docs/alexandria/ --sweep 3 --format text
 */

import { readFileSync, existsSync, statSync } from "fs";
import { relative } from "path";
import { CARD_NAME_RE, KNOWN_TYPES, Library } from "../lib/graph.js";
import { parseArgs } from "../lib/cli.js";

// ── Finding ────────────────────────────────────────────────────────────

interface Finding {
  severity: "error" | "warning" | "info";
  file: string;
  line: number;
  sweep: number;
  rule: string;
  message: string;
  fix?: string;
}

function toDict(f: Finding): Record<string, unknown> {
  const d: Record<string, unknown> = {
    severity: f.severity,
    file: f.file,
    line: f.line,
    sweep: f.sweep,
    rule: f.rule,
    message: f.message,
  };
  if (f.fix) d.fix = f.fix;
  return d;
}

// ── Helpers ────────────────────────────────────────────────────────────

const TYPE_TO_LAYER: Record<string, string> = {
  "Product Thesis": "rationale",
  Principle: "rationale",
  Standard: "rationale",
  Domain: "product",
  Section: "product",
  Governance: "product",
  Template: "product",
  Component: "product",
  Artifact: "product",
  Capability: "product",
  Primitive: "product",
  System: "product",
  Agent: "product",
  Prompt: "product",
  Loop: "experience",
  Journey: "experience",
  "Experience Goal": "experience",
  Force: "experience",
  Decision: "temporal",
  Initiative: "temporal",
  Future: "temporal",
};

function expectedLayer(cardType: string): string | null {
  return TYPE_TO_LAYER[cardType] ?? null;
}

function relPath(filePath: string, root: string | null): string {
  if (root) {
    try {
      return relative(root, filePath);
    } catch {
      // fall through
    }
  }
  return filePath;
}

// ── Sweep 1: Line-level checks ─────────────────────────────────────────

function sweep1(library: Library): Finding[] {
  const findings: Finding[] = [];

  for (const [, card] of [...library.cards.entries()].sort(([a], [b]) =>
    a.localeCompare(b),
  )) {
    const rp = relPath(card.path, library.root);
    const lines = card.rawContent.split("\n");

    let prevHeadingLevel = 0;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]!;
      const lineNum = i + 1;

      // Heading hierarchy: check for skipped levels
      const headingMatch = line.match(/^(#{1,6})\s/);
      if (headingMatch) {
        const level = headingMatch[1]!.length;
        if (prevHeadingLevel > 0 && level > prevHeadingLevel + 1) {
          findings.push({
            severity: "warning",
            file: rp,
            line: lineNum,
            sweep: 1,
            rule: "sweep1.heading_skip",
            message: `Heading level skipped: h${prevHeadingLevel} to h${level}`,
            fix: `Use h${prevHeadingLevel + 1} instead of h${level}`,
          });
        }
        prevHeadingLevel = level;
      }

      // Wikilink syntax: check for links missing type prefix
      for (const wlMatch of line.matchAll(/\[\[([^\]]+)\]\]/g)) {
        const linkText = wlMatch[1]!;
        if (!CARD_NAME_RE.test(linkText)) {
          findings.push({
            severity: "warning",
            file: rp,
            line: lineNum,
            sweep: 1,
            rule: "sweep1.wikilink_syntax",
            message: `Wikilink may be missing type prefix: [[${linkText}]]`,
            fix: `Use [[Type - ${linkText}]] format`,
          });
        }
      }

      // Naked URLs (not inside markdown links or wikilinks)
      for (const urlMatch of line.matchAll(/https?:\/\/\S+/g)) {
        const start = urlMatch.index!;
        const before = line.slice(0, start);
        if (before.endsWith("(") || before.endsWith("[[")) {
          continue;
        }
        const url = urlMatch[0]!;
        findings.push({
          severity: "info",
          file: rp,
          line: lineNum,
          sweep: 1,
          rule: "sweep1.naked_url",
          message: `Naked URL found: ${url.slice(0, 60)}`,
          fix: "Wrap in markdown link syntax: [description](url)",
        });
      }

      // Trailing whitespace on non-empty lines
      if (line.length > 0 && line !== line.trimEnd()) {
        findings.push({
          severity: "info",
          file: rp,
          line: lineNum,
          sweep: 1,
          rule: "sweep1.trailing_whitespace",
          message: "Trailing whitespace",
          fix: "Remove trailing whitespace",
        });
      }
    }
  }

  return findings;
}

// ── Sweep 2: Card-level checks ─────────────────────────────────────────

function sweep2(library: Library): Finding[] {
  const findings: Finding[] = [];

  for (const [, card] of [...library.cards.entries()].sort(([a], [b]) =>
    a.localeCompare(b),
  )) {
    const rp = relPath(card.path, library.root);

    // Missing sections
    for (const section of [...card.missingSections].sort()) {
      findings.push({
        severity: "error",
        file: rp,
        line: 0,
        sweep: 2,
        rule: "sweep2.missing_section",
        message: `Missing required section: ## ${section}`,
        fix: `Add a ## ${section}: section to the card`,
      });
    }

    // Filename convention: must match Type - Name.md
    if (!CARD_NAME_RE.test(card.cardName)) {
      findings.push({
        severity: "error",
        file: rp,
        line: 0,
        sweep: 2,
        rule: "sweep2.naming_convention",
        message: 'Filename does not match "Type - Name.md" convention',
        fix: 'Rename to "Type - Name.md" format',
      });
    }

    // Type validation
    if (card.cardType && !KNOWN_TYPES.has(card.cardType)) {
      findings.push({
        severity: "warning",
        file: rp,
        line: 0,
        sweep: 2,
        rule: "sweep2.unknown_type",
        message: `Unknown card type: ${card.cardType}`,
        fix: `Use a known type from the taxonomy: ${[...KNOWN_TYPES].sort().join(", ")}`,
      });
    }

    // Folder placement
    if (card.cardType && card.layer) {
      const expLayer = expectedLayer(card.cardType);
      if (expLayer && card.layer !== expLayer) {
        findings.push({
          severity: "warning",
          file: rp,
          line: 0,
          sweep: 2,
          rule: "sweep2.folder_placement",
          message: `Card type ${card.cardType} is in ${card.layer}/ but expected in ${expLayer}/`,
          fix: `Move to ${expLayer}/ folder`,
        });
      }
    }

    // Stub sections
    for (const [secName, section] of card.sections.entries()) {
      const stripped = section.content.trim();
      if (
        !stripped ||
        ["TBD", "TODO", "N/A", "TBD.", "TODO."].includes(stripped)
      ) {
        if (secName === "WHEN" && stripped === "N/A") continue;
        findings.push({
          severity: "warning",
          file: rp,
          line: 0,
          sweep: 2,
          rule: "sweep2.stub_section",
          message: `Section ${secName} appears to be a stub: "${stripped.slice(0, 40)}"`,
          fix: `Add substantive content to the ${secName} section`,
        });
      }
    }

    // Word count: flag if total > 700
    if (card.totalWordCount > 700) {
      findings.push({
        severity: "warning",
        file: rp,
        line: 0,
        sweep: 2,
        rule: "sweep2.word_count",
        message: `Card has ${card.totalWordCount} words (>700) — may need decomposition`,
        fix: "Consider splitting into multiple atomic cards",
      });
    }

    // Link count: fewer than 3 wikilinks
    if (card.linkCount < 3) {
      findings.push({
        severity: "warning",
        file: rp,
        line: 0,
        sweep: 2,
        rule: "sweep2.sparse_links",
        message: `Card has only ${card.linkCount} wikilinks (minimum 3 recommended)`,
        fix: "Add contextual wikilinks to related cards in the WHERE section",
      });
    }
  }

  return findings;
}

// ── Sweep 3: Graph-level checks ────────────────────────────────────────

function sweep3(library: Library): Finding[] {
  const findings: Finding[] = [];

  // Broken wikilinks
  for (const edge of library.brokenLinks()) {
    const sourceCard = library.cards.get(edge.source);
    const rp = sourceCard
      ? relPath(sourceCard.path, library.root)
      : edge.source;
    findings.push({
      severity: "error",
      file: rp,
      line: 0,
      sweep: 3,
      rule: "sweep3.broken_link",
      message: `Broken wikilink: [[${edge.target}]] does not resolve to any card`,
      fix: `Create ${edge.target}.md or fix the link target`,
    });
  }

  // Orphan cards
  for (const orphan of library.orphans()) {
    const card = library.cards.get(orphan)!;
    const rp = relPath(card.path, library.root);
    findings.push({
      severity: "warning",
      file: rp,
      line: 0,
      sweep: 3,
      rule: "sweep3.orphan",
      message:
        "Card has no incoming or outgoing resolved links — it is isolated",
      fix: "Add wikilinks connecting this card to the rest of the library",
    });
  }

  // Bidirectional gaps
  for (const gap of library.bidirectionalGaps()) {
    const sourceCard = library.cards.get(gap.fromCard);
    const rp = sourceCard
      ? relPath(sourceCard.path, library.root)
      : gap.fromCard;
    findings.push({
      severity: "info",
      file: rp,
      line: 0,
      sweep: 3,
      rule: "sweep3.bidirectional_gap",
      message: `Links to [[${gap.toCard}]] but ${gap.toCard} does not link back`,
      fix: `Add a wikilink to [[${gap.fromCard}]] in ${gap.toCard}.md`,
    });
  }

  // Duplicate card names surfaced from scan errors
  for (const error of library.scanErrors) {
    if (error.includes("Duplicate card name")) {
      findings.push({
        severity: "error",
        file: "",
        line: 0,
        sweep: 3,
        rule: "sweep3.duplicate",
        message: error,
        fix: "Rename one of the duplicate cards",
      });
    }
  }

  return findings;
}

// ── Sweep 4: Layer-level checks ────────────────────────────────────────

const CONTAINMENT_REQUIREMENTS: Record<string, string[]> = {
  Section: ["Domain"],
  Template: ["Section"],
  Component: ["Template", "Section", "Governance"],
  Artifact: ["Section"],
  Capability: ["Section"],
  Governance: ["Domain"],
  Prompt: ["Agent"],
  Loop: ["Section", "Capability"],
  Journey: ["Loop", "Agent"],
  "Experience Goal": ["Section", "Loop", "Component"],
  Force: ["System"],
};

const LAYER_MINIMUMS: Record<string, number> = {
  rationale: 2,
  product: 3,
  experience: 1,
};

function sweep4(library: Library): Finding[] {
  const findings: Finding[] = [];

  // Minimum population per layer
  const layerDist = library.layerDistribution();
  for (const [layer, minimum] of Object.entries(LAYER_MINIMUMS)) {
    const count = layerDist[layer] ?? 0;
    if (count < minimum) {
      findings.push({
        severity: "warning",
        file: "",
        line: 0,
        sweep: 4,
        rule: "sweep4.underpopulated_layer",
        message: `Layer ${layer}/ has ${count} cards (minimum ${minimum} expected)`,
        fix: `Add more cards to the ${layer}/ layer`,
      });
    }
  }

  // Cross-layer links: product-layer cards should link to rationale
  const rationaleCards = new Set(
    library.cardsByLayer("rationale").map((c) => c.cardName),
  );
  for (const card of library.cardsByLayer("product")) {
    const rp = relPath(card.path, library.root);
    const hasRationaleLink = card.allLinks.some((link) =>
      rationaleCards.has(link.target),
    );
    if (!hasRationaleLink) {
      findings.push({
        severity: "warning",
        file: rp,
        line: 0,
        sweep: 4,
        rule: "sweep4.missing_why_chain",
        message:
          "Product-layer card has no links to rationale-layer cards (missing WHY chain)",
        fix: "Add a link to a Product Thesis or Principle in the WHY section",
      });
    }
  }

  // Containment obligations
  for (const [, card] of [...library.cards.entries()].sort(([a], [b]) =>
    a.localeCompare(b),
  )) {
    if (!card.cardType || !(card.cardType in CONTAINMENT_REQUIREMENTS))
      continue;
    const requiredParentTypes = CONTAINMENT_REQUIREMENTS[card.cardType]!;
    const hasContainment = card.allLinks.some(
      (link) =>
        link.targetType && requiredParentTypes.includes(link.targetType),
    );
    if (!hasContainment) {
      const rp = relPath(card.path, library.root);
      const parentTypesStr = requiredParentTypes.join(" or ");
      findings.push({
        severity: "warning",
        file: rp,
        line: 0,
        sweep: 4,
        rule: "sweep4.missing_containment",
        message: `${card.cardType} card must link to a ${parentTypesStr} (containment)`,
        fix: `Add a containment link to a ${parentTypesStr} in the WHERE section`,
      });
    }
  }

  return findings;
}

// ── Sweep 5: Library-wide metrics ─────────────────────────────────────

function validateJsonl(filePath: string, filename: string): Finding[] {
  const findings: Finding[] = [];
  let content: string;
  try {
    content = readFileSync(filePath, "utf8");
  } catch (e) {
    findings.push({
      severity: "error",
      file: filename,
      line: 0,
      sweep: 5,
      rule: "sweep5.read_error",
      message: `Could not read ${filename}: ${e}`,
    });
    return findings;
  }

  const lines = content.split("\n");
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!.trim();
    if (!line) continue;
    try {
      JSON.parse(line);
    } catch (e) {
      findings.push({
        severity: "error",
        file: filename,
        line: i + 1,
        sweep: 5,
        rule: "sweep5.invalid_jsonl",
        message: `Invalid JSON on line ${i + 1}: ${e}`,
        fix: "Fix the JSON syntax",
      });
    }
  }

  return findings;
}

function sweep5(library: Library): [Finding[], Record<string, unknown>] {
  const findings: Finding[] = [];
  const metrics: Record<string, unknown> = {};

  const typeDist = library.typeDistribution();
  const layerDist = library.layerDistribution();
  const total = library.cards.size;

  metrics.total_cards = total;
  metrics.by_type = typeDist;
  metrics.by_layer = layerDist;
  metrics.avg_links_per_card = Math.round(library.linkDensity() * 100) / 100;
  metrics.orphan_count = library.orphans().length;
  metrics.broken_link_count = library.brokenLinks().length;
  metrics.component_count = library.components().length;

  // Flag missing core types
  const coreTypes = [
    "Product Thesis",
    "Principle",
    "Domain",
    "System",
    "Component",
  ];
  for (const t of coreTypes) {
    if ((typeDist[t] ?? 0) === 0) {
      findings.push({
        severity: "info",
        file: "",
        line: 0,
        sweep: 5,
        rule: "sweep5.missing_type",
        message: `No cards of type ${t} found in the library`,
        fix: `Consider adding ${t} cards if applicable to this product`,
      });
    }
  }

  // Low link density
  const density = library.linkDensity();
  if (total > 0 && density < 2.0) {
    findings.push({
      severity: "warning",
      file: "",
      line: 0,
      sweep: 5,
      rule: "sweep5.low_link_density",
      message: `Average link density is ${density.toFixed(1)} (below 2.0 threshold)`,
      fix: "Add more cross-references between cards",
    });
  }

  // JSONL validation
  if (library.root) {
    const fqPath = `${library.root}/feedback-queue.jsonl`;
    if (existsSync(fqPath)) {
      findings.push(...validateJsonl(fqPath, "feedback-queue.jsonl"));
    }
    const sqPath = `${library.root}/signal-queue.jsonl`;
    if (existsSync(sqPath)) {
      findings.push(...validateJsonl(sqPath, "signal-queue.jsonl"));
    }
  }

  return [findings, metrics];
}

// ── Output formatting ──────────────────────────────────────────────────

function formatJson(
  findings: Finding[],
  sweepsRun: number[],
  metrics?: Record<string, unknown>,
): string {
  const errorCount = findings.filter((f) => f.severity === "error").length;
  const warningCount = findings.filter((f) => f.severity === "warning").length;
  const infoCount = findings.filter((f) => f.severity === "info").length;

  const result: Record<string, unknown> = {
    sweeps: sweepsRun,
    findings: findings.map(toDict),
    summary: {
      errors: errorCount,
      warnings: warningCount,
      info: infoCount,
      total: findings.length,
    },
  };
  if (metrics) result.metrics = metrics;

  return JSON.stringify(result, null, 2);
}

function formatText(
  findings: Finding[],
  sweepsRun: number[],
  metrics?: Record<string, unknown>,
): string {
  const lines: string[] = [];
  const errorCount = findings.filter((f) => f.severity === "error").length;
  const warningCount = findings.filter((f) => f.severity === "warning").length;
  const infoCount = findings.filter((f) => f.severity === "info").length;

  // Group by file
  const byFile = new Map<string, Finding[]>();
  for (const f of findings) {
    const key = f.file || "(library-wide)";
    if (!byFile.has(key)) byFile.set(key, []);
    byFile.get(key)!.push(f);
  }

  for (const filePath of [...byFile.keys()].sort()) {
    lines.push(`\n${filePath}:`);
    for (const f of byFile.get(filePath)!) {
      const marker =
        f.severity === "error" ? "E" : f.severity === "warning" ? "W" : "I";
      const lineRef = f.line ? `:${f.line}` : "";
      lines.push(`  [${marker}] ${f.rule}${lineRef}: ${f.message}`);
      if (f.fix) lines.push(`      fix: ${f.fix}`);
    }
  }

  lines.push("");
  lines.push(`Sweeps: ${sweepsRun.join(",")}`);
  lines.push(
    `Results: ${errorCount} errors, ${warningCount} warnings, ${infoCount} info`,
  );

  if (metrics) {
    lines.push("");
    lines.push("Metrics:");
    lines.push(`  Total cards: ${metrics.total_cards ?? 0}`);
    lines.push(`  Link density: ${metrics.avg_links_per_card ?? 0}`);
    lines.push(`  Orphans: ${metrics.orphan_count ?? 0}`);
    lines.push(`  Broken links: ${metrics.broken_link_count ?? 0}`);
    if (metrics.by_type) {
      lines.push(`  Types: ${JSON.stringify(metrics.by_type)}`);
    }
  }

  return lines.join("\n");
}

// ── Main ───────────────────────────────────────────────────────────────

function main(): void {
  const { flags } = parseArgs(process.argv.slice(2));

  const libraryArg = flags.library;
  const sweepArg = (flags.sweep as string) || "all";
  const fmt = (flags.format as string) || "text";

  if (!libraryArg || typeof libraryArg !== "string") {
    process.stderr.write("Error: --library is required\n");
    process.exit(1);
  }

  // Validate format
  if (fmt !== "json" && fmt !== "text") {
    process.stderr.write(
      `Error: --format must be 'json' or 'text', got '${fmt}'\n`,
    );
    process.exit(1);
  }

  // Parse sweep list
  let sweeps: number[];
  if (sweepArg === "all") {
    sweeps = [1, 2, 3, 4, 5];
  } else {
    try {
      const parsed = sweepArg.split(",").map((s) => {
        const n = parseInt(s.trim(), 10);
        if (isNaN(n)) throw new Error(`not a number: ${s.trim()}`);
        return n;
      });
      for (const s of parsed) {
        if (s < 1 || s > 5) {
          process.stderr.write(`Error: sweep must be 1-5, got ${s}\n`);
          process.exit(1);
        }
      }
      sweeps = [...new Set(parsed)].sort((a, b) => a - b);
    } catch {
      process.stderr.write(`Error: invalid sweep value: ${sweepArg}\n`);
      process.exit(1);
    }
  }

  // Validate library path
  try {
    const stat = statSync(libraryArg);
    if (!stat.isDirectory()) {
      process.stderr.write(`Error: not a directory: ${libraryArg}\n`);
      process.exit(1);
    }
  } catch {
    process.stderr.write(`Error: not a directory: ${libraryArg}\n`);
    process.exit(1);
  }

  // Load library
  const library = Library.fromDirectory(libraryArg);

  // Run sweeps
  const allFindings: Finding[] = [];
  let metrics: Record<string, unknown> | undefined;

  if (sweeps.includes(1)) allFindings.push(...sweep1(library));
  if (sweeps.includes(2)) allFindings.push(...sweep2(library));
  if (sweeps.includes(3)) allFindings.push(...sweep3(library));
  if (sweeps.includes(4)) allFindings.push(...sweep4(library));
  if (sweeps.includes(5)) {
    const [findings5, metrics5] = sweep5(library);
    allFindings.push(...findings5);
    metrics = metrics5;
  }

  // Output
  if (fmt === "json") {
    process.stdout.write(formatJson(allFindings, sweeps, metrics) + "\n");
  } else {
    process.stdout.write(formatText(allFindings, sweeps, metrics) + "\n");
  }

  // Exit code: 1 if any errors
  const hasErrors = allFindings.some((f) => f.severity === "error");
  process.exit(hasErrors ? 1 : 0);
}

main();
