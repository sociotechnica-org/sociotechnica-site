/**
 * Alexandria grade computation CLI.
 *
 * Takes per-card, per-dimension assessments as JSON and computes all grade roll-ups:
 * card grades, zone grades, system grade, rage level.
 *
 * Usage:
 *   echo '{"cards": [...], "inventory": [...]}' | alexandria-grade
 *   alexandria-grade --input grades.json
 *   alexandria-grade --input grades.json --format text
 */

import { readFileSync } from "fs";
import { parseArgs } from "../lib/cli.js";

// ── Grade scale ────────────────────────────────────────────────────────

const LETTER_TO_PTS: Record<string, number> = {
  "A+": 4.3,
  A: 4.0,
  "A-": 3.7,
  "B+": 3.3,
  B: 3.0,
  "B-": 2.7,
  "C+": 2.3,
  C: 2.0,
  "C-": 1.7,
  "D+": 1.3,
  D: 1.0,
  "D-": 0.7,
  F: 0.0,
};

// Score → letter grade ranges (descending thresholds)
const SCORE_RANGES: Array<[number, string]> = [
  [4.15, "A+"],
  [3.85, "A"],
  [3.5, "A-"],
  [3.15, "B+"],
  [2.85, "B"],
  [2.5, "B-"],
  [2.15, "C+"],
  [1.85, "C"],
  [1.5, "C-"],
  [1.15, "D+"],
  [0.85, "D"],
  [0.5, "D-"],
  [0.0, "F"],
];

// Dimension weights — all equal
const WEIGHTS: Record<string, number> = {
  what: 0.2,
  why: 0.2,
  where: 0.2,
  how: 0.2,
  when: 0.2,
};

// Completeness caps: [threshold, cap | null]
const COMPLETENESS_CAPS: Array<[number, number | null]> = [
  [0.75, null], // 75%+ → no cap
  [0.5, 3.0], // 50-74% → B (3.0)
  [0.25, 2.0], // 25-49% → C (2.0)
  [0.0, 1.0], // <25% → D (1.0)
];

// Rage meter
const RAGE_LEVELS: Array<[number, string]> = [
  [3.85, "Silent Smolder"],
  [2.5, "Low Simmer"],
  [1.85, "Visible Frustration"],
  [1.15, "Active Anger"],
  [0.85, "Fury"],
  [0.0, "Apoplectic"],
];

const PENALTY_STUB = -0.3;
const PENALTY_MISSING_IN_INVENTORY = -0.15;
const PENALTY_MISSING_NOT_IN_INVENTORY = -0.3;

// ── Types ──────────────────────────────────────────────────────────────

interface CardInput {
  name: string;
  zone: string;
  dimensions: Record<string, string>;
  link_targets?: Record<string, string>;
}

interface GradeInput {
  cards: CardInput[];
  inventory: string[] | Record<string, string[]>;
}

interface CardResult {
  name: string;
  grade: string;
  numeric: number;
  zone: string;
  penalties: string[];
}

interface ZoneResult {
  name: string;
  grade: string;
  numeric: number;
  cards_built: number;
  cards_expected: number;
  completeness: number;
  cap_applied: boolean;
}

interface GradeOutput {
  cards: CardResult[];
  zones: ZoneResult[];
  system: {
    grade: string;
    numeric: number;
    rage_level: string;
  };
}

// ── Grade helpers ──────────────────────────────────────────────────────

function scoreToLetter(score: number): string {
  for (const [threshold, letter] of SCORE_RANGES) {
    if (score >= threshold) return letter;
  }
  return "F";
}

function letterToScore(letter: string): number {
  return LETTER_TO_PTS[letter.trim()] ?? 0.0;
}

function scoreToRage(score: number): string {
  for (const [threshold, level] of RAGE_LEVELS) {
    if (score >= threshold) return level;
  }
  return "Apoplectic";
}

function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

// Format a number for text output, matching Python's float repr (always includes decimal point)
function fmtNum(value: number): string {
  const s = String(value);
  return s.includes(".") ? s : s + ".0";
}

// ── Card grade computation ─────────────────────────────────────────────

function computeCardGrade(
  dimensions: Record<string, string>,
  linkTargets: Record<string, string>,
  inventory: Set<string>,
): { score: number; letter: string; penalties: string[] } {
  let total = 0.0;

  for (const [dim, weight] of Object.entries(WEIGHTS)) {
    const letter = dimensions[dim] ?? "F";
    if (dim === "when") {
      const upper = letter.toUpperCase();
      if (upper === "PASS") {
        total += weight * 4.0;
        continue;
      } else if (upper === "FAIL") {
        total += weight * 0.0;
        continue;
      }
    }
    total += weight * letterToScore(letter);
  }

  const penalties: string[] = [];
  for (const [target, status] of Object.entries(linkTargets ?? {})) {
    if (status === "complete") continue;
    if (status === "stub") {
      total += PENALTY_STUB;
      penalties.push(`stub: ${target} (${PENALTY_STUB})`);
    } else if (status === "missing") {
      if (inventory.has(target)) {
        total += PENALTY_MISSING_IN_INVENTORY;
        penalties.push(`awaiting: ${target} (${PENALTY_MISSING_IN_INVENTORY})`);
      } else {
        total += PENALTY_MISSING_NOT_IN_INVENTORY;
        penalties.push(
          `missing: ${target} (${PENALTY_MISSING_NOT_IN_INVENTORY})`,
        );
      }
    }
  }

  total = Math.max(0.0, Math.min(4.3, total));
  return { score: total, letter: scoreToLetter(total), penalties };
}

// ── Zone grade computation ─────────────────────────────────────────────

function computeZoneGrade(
  cardScores: number[],
  expectedCount: number,
): { avg: number; letter: string; completeness: number; capApplied: boolean } {
  if (expectedCount <= 0) {
    return { avg: 0.0, letter: "F", completeness: 0.0, capApplied: false };
  }

  const allScores = [
    ...cardScores,
    ...Array(expectedCount - cardScores.length).fill(0.0),
  ];
  let avg = allScores.reduce((a, b) => a + b, 0) / expectedCount;

  const completeness = cardScores.length / expectedCount;
  let capApplied = false;

  for (const [threshold, cap] of COMPLETENESS_CAPS) {
    if (completeness >= threshold) {
      if (cap !== null && avg > cap) {
        avg = cap;
        capApplied = true;
      }
      break;
    }
  }

  return { avg, letter: scoreToLetter(avg), completeness, capApplied };
}

// ── Main processing ────────────────────────────────────────────────────

function computeGrades(data: GradeInput): GradeOutput {
  const cardsInput = data.cards ?? [];
  const rawInventory = data.inventory ?? [];

  // Normalize inventory to zone-aware format
  const inventoryByZone: Record<string, string[]> = {};
  const inventorySet = new Set<string>();

  if (!Array.isArray(rawInventory)) {
    // Zone-aware dict
    for (const [zone, names] of Object.entries(rawInventory)) {
      inventoryByZone[zone] = [...names];
      for (const n of names) inventorySet.add(n);
    }
  } else {
    // Simple list — assign zones from card inputs
    const cardZones: Record<string, string> = {};
    for (const card of cardsInput) {
      cardZones[card.name ?? ""] = card.zone ?? "unknown";
    }
    for (const name of rawInventory) {
      const zone = cardZones[name] ?? "unknown";
      if (!inventoryByZone[zone]) inventoryByZone[zone] = [];
      inventoryByZone[zone].push(name);
      inventorySet.add(name);
    }
  }

  // Zone expected counts from inventory
  const zoneExpected: Record<string, number> = {};
  for (const [zone, names] of Object.entries(inventoryByZone)) {
    zoneExpected[zone] = names.length;
  }

  // Make sure zones with cards but no inventory items still get counted
  for (const card of cardsInput) {
    const zone = card.zone ?? "unknown";
    if (!(zone in zoneExpected)) zoneExpected[zone] = 0;
  }

  // Compute per-card grades
  const cardResults: CardResult[] = [];
  const zoneCards: Record<string, number[]> = {};

  for (const cardData of cardsInput) {
    const name = cardData.name ?? "Unknown";
    const zone = cardData.zone ?? "unknown";
    const dimensions = cardData.dimensions ?? {};
    const linkTargets = cardData.link_targets ?? {};

    const { score, letter, penalties } = computeCardGrade(
      dimensions,
      linkTargets,
      inventorySet,
    );
    cardResults.push({
      name,
      grade: letter,
      numeric: round2(score),
      zone,
      penalties,
    });

    if (!zoneCards[zone]) zoneCards[zone] = [];
    zoneCards[zone].push(score);
  }

  // Compute zone grades (sorted by zone name)
  const zoneResults: ZoneResult[] = [];
  const zoneScores: number[] = [];

  for (const zone of Object.keys(zoneExpected).sort()) {
    const scores = zoneCards[zone] ?? [];
    const expected = Math.max(zoneExpected[zone] ?? 0, scores.length);
    const { avg, letter, completeness, capApplied } = computeZoneGrade(
      scores,
      expected,
    );
    zoneResults.push({
      name: zone,
      grade: letter,
      numeric: round2(avg),
      cards_built: scores.length,
      cards_expected: expected,
      completeness: round2(completeness),
      cap_applied: capApplied,
    });
    zoneScores.push(avg);
  }

  // Compute system grade
  const systemScore =
    zoneScores.length > 0
      ? zoneScores.reduce((a, b) => a + b, 0) / zoneScores.length
      : 0.0;

  return {
    cards: cardResults,
    zones: zoneResults,
    system: {
      grade: scoreToLetter(systemScore),
      numeric: round2(systemScore),
      rage_level: scoreToRage(systemScore),
    },
  };
}

// ── Text formatter ─────────────────────────────────────────────────────

function formatText(result: GradeOutput): string {
  const lines: string[] = [];

  lines.push("=== Card Grades ===");
  for (const card of result.cards) {
    const penStr =
      card.penalties.length > 0 ? ` [${card.penalties.join(", ")}]` : "";
    lines.push(
      `  ${card.name}: ${card.grade} (${fmtNum(card.numeric)})${penStr}`,
    );
  }

  lines.push("");
  lines.push("=== Zone Grades ===");
  for (const zone of result.zones) {
    const capStr = zone.cap_applied ? " (capped)" : "";
    const pct = Math.round(zone.completeness * 100) + "%";
    lines.push(
      `  ${zone.name}: ${zone.grade} (${fmtNum(zone.numeric)}) ` +
        `[${zone.cards_built}/${zone.cards_expected} cards, ${pct} complete]${capStr}`,
    );
  }

  lines.push("");
  const sys = result.system;
  lines.push(
    `=== System Grade: ${sys.grade} (${fmtNum(sys.numeric)}) — ${sys.rage_level} ===`,
  );

  return lines.join("\n");
}

// ── Main ───────────────────────────────────────────────────────────────

const args = parseArgs(process.argv.slice(2));

if (args.flags["h"] === true || args.flags["help"] === true) {
  console.log(
    `Usage:
  alexandria-grade [--input FILE] [--format json|text]

  Reads per-card dimension assessments as JSON and computes grade roll-ups.
  Reads from stdin if --input is not provided.`,
  );
  process.exit(0);
}

const inputFile = args.flags["input"] as string | undefined;
const fmt = (args.flags["format"] as string) ?? "json";

let rawInput: string;
if (inputFile) {
  try {
    rawInput = readFileSync(inputFile, "utf-8");
  } catch (e) {
    console.error(`Error reading input: ${e instanceof Error ? e.message : e}`);
    process.exit(1);
  }
} else {
  const chunks: Buffer[] = [];
  try {
    for await (const chunk of process.stdin) {
      chunks.push(chunk as Buffer);
    }
    rawInput = Buffer.concat(chunks).toString("utf-8");
  } catch (e) {
    console.error(`Error reading stdin: ${e instanceof Error ? e.message : e}`);
    process.exit(1);
  }
}

let data: GradeInput;
try {
  data = JSON.parse(rawInput) as GradeInput;
} catch (e) {
  console.error(
    `Error parsing JSON from stdin: ${e instanceof Error ? e.message : e}`,
  );
  process.exit(1);
}

const result = computeGrades(data);

if (fmt === "json") {
  // Ensure numeric fields are serialized as floats (e.g. 3.0 not 3)
  // to match Python's json.dumps float behavior.
  const json = JSON.stringify(result, null, 2).replace(
    /"(numeric|completeness)": (\d+)(,?)$/gm,
    '"$1": $2.0$3',
  );
  console.log(json);
} else {
  console.log(formatText(result));
}
