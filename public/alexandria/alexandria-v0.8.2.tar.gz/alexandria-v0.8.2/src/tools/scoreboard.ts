/**
 * Scoreboard ASCII renderer.
 *
 * Renders pre-derived Foundation/Core/Amplifier scoreboard data into the
 * terminal-friendly box layout described in the Phase 2 library plans.
 *
 * Usage:
 *   echo '{"buckets":[...]}' | bun run src/tools/scoreboard.ts
 */

import { readFileSync } from "fs";

const BAR_WIDTH = 20;
const FILL_LABEL_WIDTH = 4;
const MIN_LABEL_WIDTH = 12;
const MAX_LABEL_WIDTH = 24;

const SCOREBOARD_FILL_LEVELS = [0, 25, 50, 75, 100] as const;
const SCOREBOARD_TIERS = ["foundation", "core", "amplifier"] as const;

export type ScoreboardFill = (typeof SCOREBOARD_FILL_LEVELS)[number];
export type ScoreboardTier = (typeof SCOREBOARD_TIERS)[number];

export interface ScoreboardArea {
  id: string;
  name: string;
  fill: ScoreboardFill;
}

export interface ScoreboardBucket {
  tier: ScoreboardTier;
  message: string;
  areas: ScoreboardArea[];
}

export interface ScoreboardInput {
  buckets: ScoreboardBucket[];
}

function isScoreboardFill(value: unknown): value is ScoreboardFill {
  return (
    typeof value === "number" &&
    (SCOREBOARD_FILL_LEVELS as readonly number[]).includes(value)
  );
}

function isScoreboardTier(value: unknown): value is ScoreboardTier {
  return (
    typeof value === "string" &&
    (SCOREBOARD_TIERS as readonly string[]).includes(value)
  );
}

function truncateLabel(name: string): string {
  if (name.length <= MAX_LABEL_WIDTH) {
    return name;
  }

  return `${name.slice(0, MAX_LABEL_WIDTH - 3)}...`;
}

function barForFill(fill: ScoreboardFill): string {
  const filledCells = fill / 5;
  return "█".repeat(filledCells) + "░".repeat(BAR_WIDTH - filledCells);
}

function fillLabel(fill: ScoreboardFill): string {
  return fill === 100 ? "FULL" : `${fill}%`;
}

function bucketTitle(tier: ScoreboardTier): string {
  return tier.toUpperCase();
}

function renderBucket(bucket: ScoreboardBucket): string {
  const labelWidth = Math.max(
    MIN_LABEL_WIDTH,
    ...bucket.areas.map((area) => truncateLabel(area.name).length),
  );
  const contentWidth = labelWidth + 1 + BAR_WIDTH + 1 + FILL_LABEL_WIDTH;
  const title = bucketTitle(bucket.tier);
  const titleRule = "─".repeat(Math.max(1, contentWidth - title.length - 1));

  const lines = [
    `┌─ ${title} ${titleRule}┐`,
    ...bucket.areas.map((area) => {
      const label = truncateLabel(area.name).padEnd(labelWidth);
      const bar = barForFill(area.fill);
      const status = fillLabel(area.fill).padStart(FILL_LABEL_WIDTH);
      return `│ ${label} ${bar} ${status} │`;
    }),
    `└${"─".repeat(contentWidth + 2)}┘`,
    `  → ${bucket.message}`,
  ];

  return lines.join("\n");
}

export function renderScoreboard(input: ScoreboardInput): string {
  const visibleBuckets = input.buckets.filter(
    (bucket) => bucket.areas.length > 0,
  );
  return visibleBuckets.map((bucket) => renderBucket(bucket)).join("\n\n");
}

function parseScoreboardInput(raw: string): ScoreboardInput {
  const parsed = JSON.parse(raw) as { buckets?: unknown };

  if (!Array.isArray(parsed.buckets)) {
    throw new Error("Input must include a buckets array");
  }

  const buckets = parsed.buckets.map((bucket, index) => {
    if (bucket == null || typeof bucket !== "object") {
      throw new Error(`Bucket ${index + 1} must be an object`);
    }

    const candidate = bucket as {
      tier?: unknown;
      message?: unknown;
      areas?: unknown;
    };

    if (!isScoreboardTier(candidate.tier)) {
      throw new Error(`Bucket ${index + 1} has an invalid tier`);
    }

    if (
      typeof candidate.message !== "string" ||
      candidate.message.length === 0
    ) {
      throw new Error(`Bucket ${index + 1} must include a non-empty message`);
    }

    if (!Array.isArray(candidate.areas)) {
      throw new Error(`Bucket ${index + 1} must include an areas array`);
    }

    const areas = candidate.areas.map((area, areaIndex) => {
      if (area == null || typeof area !== "object") {
        throw new Error(
          `Bucket ${index + 1} area ${areaIndex + 1} must be an object`,
        );
      }

      const candidateArea = area as {
        id?: unknown;
        name?: unknown;
        fill?: unknown;
      };

      if (
        typeof candidateArea.id !== "string" ||
        candidateArea.id.length === 0
      ) {
        throw new Error(
          `Bucket ${index + 1} area ${areaIndex + 1} must include a non-empty id`,
        );
      }

      if (
        typeof candidateArea.name !== "string" ||
        candidateArea.name.length === 0
      ) {
        throw new Error(
          `Bucket ${index + 1} area ${areaIndex + 1} must include a non-empty name`,
        );
      }

      if (!isScoreboardFill(candidateArea.fill)) {
        throw new Error(
          `Bucket ${index + 1} area ${areaIndex + 1} has an invalid fill`,
        );
      }

      return {
        id: candidateArea.id,
        name: candidateArea.name,
        fill: candidateArea.fill,
      };
    });

    return {
      tier: candidate.tier,
      message: candidate.message,
      areas,
    };
  });

  return { buckets };
}

if (import.meta.main) {
  try {
    const rawInput = readFileSync(0, "utf8").trim();
    if (rawInput.length === 0) {
      throw new Error("Expected scoreboard JSON on stdin");
    }

    const scoreboard = parseScoreboardInput(rawInput);
    console.log(renderScoreboard(scoreboard));
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}
