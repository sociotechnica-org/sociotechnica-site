/**
 * Print the current Alexandria version from the repository VERSION file.
 */

import { dirname, join } from "path";
import { fileURLToPath } from "url";
import { resolvePluginRoot } from "../lib/plugin-paths.js";
import { readContextLibraryVersion } from "../lib/version.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export interface VersionCliResult {
  stdout: string;
  exitCode: number;
}

interface VersionCliOptions {
  env?: NodeJS.ProcessEnv;
}

function resolveVersionFile(env: NodeJS.ProcessEnv = process.env): string {
  const repoRoot = resolvePluginRoot(env, __dirname);
  return join(repoRoot, "VERSION");
}

export function runVersionCli(
  options: VersionCliOptions = {},
): VersionCliResult {
  const version = readContextLibraryVersion(resolveVersionFile(options.env));
  if (!version) {
    return {
      stdout: "unknown",
      exitCode: 1,
    };
  }

  return {
    stdout: version,
    exitCode: 0,
  };
}

function main(): void {
  const result = runVersionCli();
  console.log(result.stdout);
  process.exit(result.exitCode);
}

if (import.meta.main) {
  main();
}
