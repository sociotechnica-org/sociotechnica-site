/**
 * Alexandria — Eval Runner
 *
 * TypeScript implementation of the eval harness. Legacy shell wrappers may
 * delegate here, but orchestration, transcripts, structural checks, judging,
 * and comparison logic live in Bun/TypeScript.
 */

import {
  closeSync,
  copyFileSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  openSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from "fs";
import { basename, dirname, join, relative } from "path";
import { tmpdir } from "os";
import { fileURLToPath, pathToFileURL } from "url";
import { createHash } from "crypto";
import { parseArgs } from "../lib/cli.js";
import {
  buildReport,
  type StructuralResult,
} from "../lib/structural-checks.js";

type EvalMode = "single-prompt" | "multi-turn" | "adaptive";

interface EvalConfig {
  skill?: string;
  model?: string;
  route_file?: string;
  timeout?: number;
  allowed_tools?: string;
  max_turns?: number;
  expected_files?: string[];
  eval_mode?: string;
}

interface ComparisonResult {
  regressions: number;
}

interface CommandResult {
  exitCode: number;
  stdout: string;
  stderr: string;
  combined: string;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const ROOT_DIR = join(__dirname, "..", "..");
const TESTS_DIR = join(ROOT_DIR, "tests");
const VERSION = existsSync(join(ROOT_DIR, "VERSION"))
  ? readFileSync(join(ROOT_DIR, "VERSION"), "utf-8").trim()
  : "unknown";

const SCRIPT_NAME = "bun run src/tools/eval-harness.ts";
const EVAL_CASES_DIR =
  process.env["EVAL_CASES_DIR"] ?? join(TESTS_DIR, "eval-cases");
const EVALS_DIR = process.env["EVALS_DIR"] ?? join(TESTS_DIR, "evals");

function info(message: string): void {
  process.stdout.write(`  → ${message}\n`);
}

function success(message: string): void {
  process.stdout.write(`  ✓ ${message}\n`);
}

function warn(message: string): void {
  process.stdout.write(`  ⚠ ${message}\n`);
}

function error(message: string): void {
  process.stderr.write(`  ✗ ${message}\n`);
}

function nowIso(): string {
  return new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
}

function runTimestamp(): string {
  const date = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return (
    `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-` +
    `${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`
  );
}

function sha1(data: string | Uint8Array): string {
  return createHash("sha1").update(data).digest("hex");
}

function fileHash(filePath: string): string {
  return existsSync(filePath) ? sha1(readFileSync(filePath)) : "none";
}

function fixtureHash(fixtureDir: string): string {
  if (!existsSync(fixtureDir)) return "none";
  const entries = listRelativeFiles(fixtureDir)
    .map(
      (relPath) =>
        `${sha1(readFileSync(join(fixtureDir, relPath)))}  ${relPath}`,
    )
    .join("\n");
  return entries.length > 0 ? sha1(entries) : "none";
}

async function gitSha(): Promise<string> {
  const result = await runCommand(
    ["git", "-C", ROOT_DIR, "rev-parse", "--short", "HEAD"],
    {
      cwd: ROOT_DIR,
    },
  );
  return result.exitCode === 0 ? result.stdout.trim() || "unknown" : "unknown";
}

function listRelativeFiles(rootDir: string): string[] {
  if (!existsSync(rootDir)) return [];
  const out: string[] = [];

  function walk(dir: string): void {
    for (const entry of readdirSync(dir).sort()) {
      const fullPath = join(dir, entry);
      const stats = statSync(fullPath);
      if (stats.isDirectory()) {
        if (entry === ".git") continue;
        walk(fullPath);
      } else if (stats.isFile()) {
        out.push(relative(rootDir, fullPath).split("\\").join("/"));
      }
    }
  }

  walk(rootDir);
  return out.sort();
}

function snapshotFiles(rootDir: string): Map<string, string> {
  const snapshot = new Map<string, string>();
  for (const relPath of listRelativeFiles(rootDir)) {
    snapshot.set(relPath, sha1(readFileSync(join(rootDir, relPath))));
  }
  return snapshot;
}

function ensureDir(dirPath: string): void {
  mkdirSync(dirPath, { recursive: true });
}

function copyDirContents(srcDir: string, destDir: string): void {
  ensureDir(destDir);
  for (const entry of readdirSync(srcDir)) {
    const srcPath = join(srcDir, entry);
    const destPath = join(destDir, entry);
    const stats = statSync(srcPath);
    if (stats.isDirectory()) {
      copyDirContents(srcPath, destPath);
    } else if (stats.isFile()) {
      ensureDir(dirname(destPath));
      copyFileSync(srcPath, destPath);
    }
  }
}

function removeEverythingExceptRuns(dirPath: string): void {
  if (!existsSync(dirPath)) return;
  for (const entry of readdirSync(dirPath)) {
    if (entry === "runs") continue;
    rmSync(join(dirPath, entry), { recursive: true, force: true });
  }
}

function copyWorkdirOutput(workDir: string, destDir: string): void {
  ensureDir(destDir);
  for (const relPath of listRelativeFiles(workDir)) {
    const srcPath = join(workDir, relPath);
    const destPath = join(destDir, relPath);
    ensureDir(dirname(destPath));
    copyFileSync(srcPath, destPath);
  }
}

function isMultiTurn(inputsPath: string): boolean {
  return /^## Turn \d+/m.test(readFileSync(inputsPath, "utf-8"));
}

function parseMultiTurnInputs(inputsPath: string): string[] {
  const turns: string[] = [];
  const lines = readFileSync(inputsPath, "utf-8").split("\n");
  let current: string[] = [];

  for (const line of lines) {
    if (/^## Turn \d+/.test(line)) {
      if (current.length > 0) {
        turns.push(trimLeadingBlankLines(current).join("\n"));
      }
      current = [];
      continue;
    }
    current.push(line);
  }

  if (current.length > 0) {
    turns.push(trimLeadingBlankLines(current).join("\n"));
  }

  return turns.filter((turn) => turn.trim().length > 0);
}

function trimLeadingBlankLines(lines: string[]): string[] {
  const copy = [...lines];
  while (copy.length > 0 && copy[0]!.trim().length === 0) copy.shift();
  return copy;
}

function resolveCases(target: string): string[] {
  const allCases = listRelativeFiles(EVAL_CASES_DIR)
    .filter((relPath) => basename(relPath) === "config.json")
    .map((relPath) => dirname(relPath).split("\\").join("/"))
    .sort();

  if (target === "all") return allCases;
  if (target.endsWith("/all")) {
    const skill = target.slice(0, -"/all".length);
    return allCases.filter((casePath) => casePath.startsWith(`${skill}/`));
  }
  return [target];
}

function usage(): void {
  process.stdout.write(`Alexandria — Eval Runner v${VERSION}\n\n`);
  process.stdout.write("Usage:\n");
  process.stdout.write(
    `  ${SCRIPT_NAME} <skill>/<case>            Run one eval case\n`,
  );
  process.stdout.write(
    `  ${SCRIPT_NAME} <skill>/all               Run all cases for a skill\n`,
  );
  process.stdout.write(
    `  ${SCRIPT_NAME} all                       Run all eval cases\n`,
  );
  process.stdout.write(
    `  ${SCRIPT_NAME} <skill>/<case> --compare  Compare against baseline\n\n`,
  );
  process.stdout.write("Available eval cases:\n");
  const cases = resolveCases("all");
  if (cases.length === 0) {
    process.stdout.write("  (none found)\n");
  } else {
    for (const casePath of cases) {
      process.stdout.write(`  ${casePath}\n`);
    }
  }
}

async function runCommand(
  args: string[],
  options: { cwd: string; input?: string; env?: NodeJS.ProcessEnv },
): Promise<CommandResult> {
  const captureDir = mkdtempSync(join(tmpdir(), "alexandria-capture-"));
  const stdoutPath = join(captureDir, "stdout.txt");
  const stderrPath = join(captureDir, "stderr.txt");
  let stdoutFd: number | null = null;
  let stderrFd: number | null = null;

  try {
    stdoutFd = openSync(stdoutPath, "w");
    stderrFd = openSync(stderrPath, "w");

    const proc = Bun.spawn(args, {
      cwd: options.cwd,
      env: options.env ?? process.env,
      stdin: options.input != null ? "pipe" : "ignore",
      stdout: stdoutFd,
      stderr: stderrFd,
    });

    if (options.input != null) {
      proc.stdin?.write(options.input);
      proc.stdin?.end();
    }

    const exitCode = await proc.exited;
    if (stdoutFd !== null) {
      closeSync(stdoutFd);
      stdoutFd = null;
    }
    if (stderrFd !== null) {
      closeSync(stderrFd);
      stderrFd = null;
    }
    const stdout = existsSync(stdoutPath)
      ? readFileSync(stdoutPath, "utf-8")
      : "";
    const stderr = existsSync(stderrPath)
      ? readFileSync(stderrPath, "utf-8")
      : "";

    return {
      exitCode,
      stdout,
      stderr,
      combined: `${stdout}${stderr}`,
    };
  } finally {
    if (stdoutFd !== null) {
      closeSync(stdoutFd);
    }
    if (stderrFd !== null) {
      closeSync(stderrFd);
    }
    if (existsSync(stdoutPath)) {
      unlinkSync(stdoutPath);
    }
    if (existsSync(stderrPath)) {
      unlinkSync(stderrPath);
    }
    rmSync(captureDir, { recursive: true, force: true });
  }
}

function parseJsonObject(text: string): Record<string, unknown> | null {
  const trimmed = text.trim();
  if (trimmed.length === 0) return null;
  try {
    return JSON.parse(trimmed) as Record<string, unknown>;
  } catch {
    return null;
  }
}

async function resolveModel(config: EvalConfig): Promise<string> {
  const routeFile =
    typeof config.route_file === "string" ? config.route_file : "";
  let model = typeof config.model === "string" ? config.model : "";
  if (routeFile.length === 0 || (model.length > 0 && model !== "route")) {
    return model;
  }

  const router = join(ROOT_DIR, "bin", "alexandria-route");
  if (!existsSync(router)) {
    warn(`Router not found at ${router} — falling back to default model`);
    return "";
  }

  const result = await runCommand([router, join(ROOT_DIR, routeFile)], {
    cwd: ROOT_DIR,
  });
  const routed = result.stdout.trim();
  if (result.exitCode === 0 && routed.length > 0) {
    info(`Routed model: ${routed} (from ${routeFile})`);
    model = routed;
  } else {
    warn(
      `Router returned empty for ${routeFile} — falling back to default model`,
    );
    model = "";
  }
  return model;
}

function detectMode(caseDir: string, config: EvalConfig): EvalMode {
  const inputsPath = join(caseDir, "inputs.md");
  if (
    config.eval_mode === "adaptive" ||
    existsSync(join(caseDir, "persona.md"))
  ) {
    return "adaptive";
  }
  if (isMultiTurn(inputsPath)) return "multi-turn";
  return "single-prompt";
}

function readConfig(caseDir: string): EvalConfig {
  const raw = readFileSync(join(caseDir, "config.json"), "utf-8");
  return JSON.parse(raw) as EvalConfig;
}

function listExpectedFiles(config: EvalConfig): string[] {
  return Array.isArray(config.expected_files)
    ? config.expected_files.filter(
        (value): value is string => typeof value === "string",
      )
    : [];
}

function renderList(items: string[]): string {
  return items.length > 0
    ? items.map((item) => `- ${item}`).join("\n")
    : "_(none)_";
}

async function runJudge(
  evalDir: string,
  criteriaFile: string,
): Promise<boolean> {
  const transcript = join(evalDir, "transcript.md");
  const resultsFile = join(evalDir, "judge-results.json");

  if (!existsSync(transcript)) {
    writeFileSync(
      resultsFile,
      JSON.stringify(
        {
          error: "transcript not found",
          criteria: [],
          overall: "error",
          summary: "No transcript to judge",
          pass_count: 0,
          fail_count: 0,
          total: 0,
        },
        null,
        2,
      ) + "\n",
    );
    warn("Judge: no transcript found");
    return false;
  }

  if (!existsSync(criteriaFile)) {
    writeFileSync(
      resultsFile,
      JSON.stringify(
        {
          error: "criteria file not found",
          criteria: [],
          overall: "error",
          summary: "No criteria file",
          pass_count: 0,
          fail_count: 0,
          total: 0,
        },
        null,
        2,
      ) + "\n",
    );
    warn("Judge: no criteria file found");
    return false;
  }

  const transcriptText = readFileSync(transcript, "utf-8");
  const createdFiles = [...transcriptText.matchAll(/^-\s+(.+)$/gm)]
    .map((match) => match[1]!.trim())
    .filter((line) => !line.startsWith("## "));
  const outputDir = join(evalDir, "output");
  const outputBlobs: string[] = [];
  if (existsSync(outputDir) && createdFiles.length > 0) {
    const sections = splitTranscriptFileSections(transcriptText);
    const skillFiles = [
      ...new Set([...sections.created, ...sections.modified]),
    ];
    for (const relPath of skillFiles) {
      const fullPath = join(outputDir, relPath);
      if (!existsSync(fullPath) || !statSync(fullPath).isFile()) continue;
      outputBlobs.push(
        `--- ${relPath} ---\n${readFileSync(fullPath, "utf-8").split("\n").slice(0, 200).join("\n")}\n`,
      );
    }
  } else if (existsSync(outputDir)) {
    outputBlobs.push("(no files created or modified by skill)");
  }

  const criteriaJson = readFileSync(criteriaFile, "utf-8");
  const criteriaData = JSON.parse(criteriaJson) as Record<string, unknown>;
  const scoringType =
    typeof criteriaData["scoring"] === "string"
      ? criteriaData["scoring"]
      : "pass_fail";

  const evalInstructions =
    scoringType === "categorical"
      ? `Evaluate each criterion below by assigning a level. The criteria file defines
the available levels and what each means, including level_values (the numeric weight
for each level). Assess based on what ACTUALLY happened in the transcript and output
files, not what should have happened. Be strict — only assign "excellent" when clearly
demonstrated with strong evidence. Use the level_values from the criteria to compute
weighted_score (sum of level values for assigned levels) and max_score (sum if all
criteria scored the highest level).`
      : `Evaluate each criterion below. For each one, assess based on what ACTUALLY happened
in the transcript and output files, not what should have happened. Be strict — "pass"
means clearly demonstrated, not merely hinted at.`;

  const responseFormat =
    scoringType === "categorical"
      ? `{
  "criteria": [
    {
      "id": <number>,
      "name": "<criterion name>",
      "level": "<one of the defined levels>",
      "reason": "<one line of specific evidence>"
    }
  ],
  "overall": "pass"/"fail",
  "summary": "<one sentence overall assessment>",
  "level_counts": {"excellent": <n>, "good": <n>, "adequate": <n>, "weak": <n>, "poor": <n>},
  "weighted_score": <sum of level values for each criterion>,
  "max_score": <max possible score>,
  "total": <number of criteria>
}`
      : `{
  "criteria": [
    {
      "id": <number>,
      "name": "<criterion name>",
      "pass": true/false,
      "reason": "<one line of specific evidence>"
    }
  ],
  "overall": "pass"/"fail",
  "summary": "<one sentence overall assessment>",
  "pass_count": <number>,
  "fail_count": <number>,
  "total": <number>
}`;

  const prompt = `You are a QA judge evaluating the output of a Alexandria skill.

Here is the full eval transcript:

---BEGIN TRANSCRIPT---
${transcriptText}
---END TRANSCRIPT---

Here are the files the skill CREATED or MODIFIED (first 200 lines each).
IMPORTANT: The transcript separates "Files Created by Skill", "Fixture Files Modified
by Skill", and "Pre-existing Fixture Files (unmodified)". Only files in the first two
categories were touched by the skill. Pre-existing fixture files were already present
before the skill ran and should NOT be counted as skill output.

---BEGIN SKILL OUTPUT FILES---
${outputBlobs.join("\n")}
---END SKILL OUTPUT FILES---

${evalInstructions}

When evaluating division of labor or file ownership criteria, use the transcript's file
sections to determine what the skill actually wrote vs what was pre-existing.

Criteria to evaluate:
${criteriaJson}

Respond with ONLY a JSON object, no other text:

${responseFormat}`;

  const result = await runCommand(
    ["claude", "-p", prompt, "--allowedTools", ""],
    {
      cwd: ROOT_DIR,
    },
  );
  const raw = result.combined.trim();
  let parsedText = raw;
  const fenced = raw.match(/```json\s*([\s\S]*?)```/);
  if (fenced?.[1]) parsedText = fenced[1].trim();
  const parsed = parseJsonObject(parsedText);

  if (parsed) {
    writeFileSync(resultsFile, `${JSON.stringify(parsed, null, 2)}\n`);
    const overall = String(parsed["overall"] ?? "unknown");
    if (scoringType === "categorical") {
      success(
        `Judge: ${parsed["weighted_score"] ?? "?"}/${parsed["max_score"] ?? "?"} score, ${parsed["total"] ?? "?"} criteria (overall: ${overall})`,
      );
    } else {
      success(
        `Judge: ${parsed["pass_count"] ?? "?"}/${parsed["total"] ?? "?"} passed (overall: ${overall})`,
      );
    }
    return result.exitCode === 0;
  }

  writeFileSync(
    resultsFile,
    JSON.stringify(
      {
        error: "judge_parse_error",
        raw_output_preview: raw.slice(0, 500),
        criteria: [],
        overall: "error",
        summary: "Could not parse judge response",
        pass_count: 0,
        fail_count: 0,
        total: 0,
      },
      null,
      2,
    ) + "\n",
  );
  warn("Judge: could not parse response (saved raw output)");
  return false;
}

function splitTranscriptFileSections(transcript: string): {
  created: string[];
  modified: string[];
} {
  const lines = transcript.split("\n");
  const created: string[] = [];
  const modified: string[] = [];
  let mode: "created" | "modified" | null = null;

  for (const line of lines) {
    if (line.startsWith("## Files Created by Skill")) {
      mode = "created";
      continue;
    }
    if (line.startsWith("## Fixture Files Modified by Skill")) {
      mode = "modified";
      continue;
    }
    if (line.startsWith("## ") && !line.startsWith("## Files")) {
      mode = null;
    }
    if (!line.startsWith("- ")) continue;
    if (mode === "created") created.push(line.slice(2).trim());
    if (mode === "modified") modified.push(line.slice(2).trim());
  }

  return { created, modified };
}

async function runStructuralChecks(
  casePath: string,
  evalDir: string,
): Promise<boolean> {
  const resultsFile = join(evalDir, "structural-results.json");
  const skill = casePath.split("/")[0]!;
  const modulePath = join(EVAL_CASES_DIR, skill, "structural-checks.ts");
  const outputDir = join(evalDir, "output");

  if (!existsSync(modulePath)) {
    warn("No structural checks found (skipping)");
    writeFileSync(
      resultsFile,
      `${JSON.stringify(buildReport([], true), null, 2)}\n`,
    );
    return true;
  }

  process.stdout.write("  --- Structural checks ---\n");

  const mod = (await import(pathToFileURL(modulePath).href)) as {
    structuralChecks?: (
      outputDir: string,
    ) => Promise<StructuralResult[]> | StructuralResult[];
  };

  if (typeof mod.structuralChecks !== "function") {
    const report = buildReport([
      {
        name: `Structural checks module missing export: ${skill}`,
        pass: false,
      },
    ]);
    writeFileSync(resultsFile, `${JSON.stringify(report, null, 2)}\n`);
    error(`Structural checks module missing export: ${modulePath}`);
    process.stdout.write(
      `\n  Structural: ${report.pass_count}/${report.total} passed\n`,
    );
    return false;
  }

  const checks = await mod.structuralChecks(outputDir);
  const report = buildReport(checks);

  for (const check of checks) {
    if (check.pass) {
      success(check.name);
    } else {
      error(check.name);
    }
  }

  writeFileSync(resultsFile, `${JSON.stringify(report, null, 2)}\n`);
  process.stdout.write(
    `\n  Structural: ${report.pass_count}/${report.total} passed\n`,
  );
  return report.fail_count === 0;
}

function parseCriteriaStatus(filePath: string): Map<string, string | boolean> {
  if (!existsSync(filePath)) return new Map();
  const data = JSON.parse(readFileSync(filePath, "utf-8")) as Record<
    string,
    unknown
  >;
  const criteria = Array.isArray(data["criteria"]) ? data["criteria"] : [];
  const isCategorical = criteria.some(
    (criterion) =>
      criterion != null &&
      typeof criterion === "object" &&
      ("level" in (criterion as Record<string, unknown>) ||
        "score" in (criterion as Record<string, unknown>)),
  );

  const map = new Map<string, string | boolean>();
  for (const criterion of criteria) {
    if (!criterion || typeof criterion !== "object") continue;
    const rec = criterion as Record<string, unknown>;
    const name = typeof rec["name"] === "string" ? rec["name"] : null;
    if (!name) continue;
    if (isCategorical) {
      map.set(name, String(rec["level"] ?? rec["score"] ?? ""));
    } else {
      map.set(name, Boolean(rec["pass"]));
    }
  }
  return map;
}

function judgeLevelIndex(level: string | boolean): number {
  if (typeof level === "boolean") return level ? 1 : 0;
  const order = ["poor", "weak", "adequate", "good", "excellent"];
  return order.indexOf(level);
}

async function runComparison(
  casePath: string,
  currentDir: string,
  baselineDir: string,
): Promise<ComparisonResult> {
  process.stdout.write("\n  --- Comparison against baseline ---\n");

  if (
    !existsSync(baselineDir) ||
    !existsSync(join(baselineDir, "run-metadata.json"))
  ) {
    info(`No baseline found for ${casePath} (first run)`);
    return { regressions: 0 };
  }

  let regressions = 0;
  const baselineMeta = JSON.parse(
    readFileSync(join(baselineDir, "run-metadata.json"), "utf-8"),
  ) as Record<string, unknown>;
  const currentMeta = JSON.parse(
    readFileSync(join(currentDir, "run-metadata.json"), "utf-8"),
  ) as Record<string, unknown>;

  process.stdout.write(
    `  Git: ${String(baselineMeta["git_sha"] ?? "?")} → ${String(currentMeta["git_sha"] ?? "?")}\n`,
  );
  const baselineSkill = String(baselineMeta["skill_hash"] ?? "?").slice(0, 8);
  const currentSkill = String(currentMeta["skill_hash"] ?? "?").slice(0, 8);
  if (baselineSkill === currentSkill) {
    process.stdout.write(`  Skill: unchanged (${baselineSkill})\n`);
  } else {
    process.stdout.write(
      `  Skill: CHANGED (${baselineSkill} → ${currentSkill})\n`,
    );
  }

  const baselineStructural = join(baselineDir, "structural-results.json");
  const currentStructural = join(currentDir, "structural-results.json");
  if (existsSync(baselineStructural) && existsSync(currentStructural)) {
    process.stdout.write("\n  Structural checks:\n");
    const oldChecks = JSON.parse(
      readFileSync(baselineStructural, "utf-8"),
    ) as Record<string, unknown>;
    const newChecks = JSON.parse(
      readFileSync(currentStructural, "utf-8"),
    ) as Record<string, unknown>;
    const oldMap = new Map<string, boolean>();
    const newMap = new Map<string, boolean>();

    for (const check of (Array.isArray(oldChecks["checks"])
      ? oldChecks["checks"]
      : []) as Record<string, unknown>[]) {
      if (typeof check["name"] === "string")
        oldMap.set(check["name"], Boolean(check["pass"]));
    }
    for (const check of (Array.isArray(newChecks["checks"])
      ? newChecks["checks"]
      : []) as Record<string, unknown>[]) {
      if (typeof check["name"] === "string")
        newMap.set(check["name"], Boolean(check["pass"]));
    }

    for (const [name, status] of newMap.entries()) {
      const oldStatus = oldMap.get(name);
      if (oldStatus === true && status === false) {
        warn(`REGRESSION: ${name} (was pass, now fail)`);
        regressions += 1;
      } else if (oldStatus === false && status === true) {
        success(`IMPROVEMENT: ${name} (was fail, now pass)`);
      }
    }
    if (regressions === 0) {
      success(
        `No structural regressions (${String(newChecks["total"] ?? "?")} checks)`,
      );
    }
  } else {
    info(
      `Structural results: ${existsSync(baselineStructural) ? "baseline only" : "not available"}`,
    );
  }

  const baselineJudge = join(baselineDir, "judge-results.json");
  const currentJudge = join(currentDir, "judge-results.json");
  if (existsSync(baselineJudge) && existsSync(currentJudge)) {
    process.stdout.write("\n  Judge criteria:\n");
    const oldMap = parseCriteriaStatus(baselineJudge);
    const newMap = parseCriteriaStatus(currentJudge);
    for (const [name, status] of newMap.entries()) {
      if (!oldMap.has(name)) continue;
      const oldStatus = oldMap.get(name)!;
      if (judgeLevelIndex(status) < judgeLevelIndex(oldStatus)) {
        warn(`REGRESSION: ${name}`);
        regressions += 1;
      } else if (judgeLevelIndex(status) > judgeLevelIndex(oldStatus)) {
        success(`IMPROVEMENT: ${name}`);
      }
    }
    if (regressions === 0) {
      const judgeData = JSON.parse(
        readFileSync(currentJudge, "utf-8"),
      ) as Record<string, unknown>;
      success(
        `No judge regressions (${String(judgeData["total"] ?? "?")} criteria)`,
      );
    }
  } else {
    info(
      `Judge results: ${existsSync(baselineJudge) ? "baseline only" : "not available"}`,
    );
  }

  process.stdout.write("\n");
  const baselineCount = Number(baselineMeta["files_written_count"] ?? NaN);
  const currentCount = Number(currentMeta["files_written_count"] ?? NaN);
  if (baselineCount === currentCount) {
    success(`File count unchanged: ${currentCount}`);
  } else {
    warn(
      `File count changed: ${String(baselineMeta["files_written_count"] ?? "?")} → ${String(currentMeta["files_written_count"] ?? "?")}`,
    );
  }

  process.stdout.write("\n");
  if (regressions > 0) {
    error(`Comparison: ${regressions} regression(s) detected`);
  } else {
    success("Comparison: no regressions");
  }
  return { regressions };
}

async function runEvalCase(
  casePath: string,
  compare: boolean,
): Promise<number> {
  const caseDir = join(EVAL_CASES_DIR, casePath);
  const outputDir = join(EVALS_DIR, casePath);

  process.stdout.write("\n═══════════════════════════════════════════\n");
  process.stdout.write(`Eval: ${casePath}\n`);
  process.stdout.write("═══════════════════════════════════════════\n");

  if (!existsSync(caseDir) || !statSync(caseDir).isDirectory()) {
    error(`Eval case not found: ${caseDir}`);
    return 1;
  }
  if (!existsSync(join(caseDir, "inputs.md"))) {
    error(`Missing inputs.md in ${caseDir}`);
    return 1;
  }
  if (!existsSync(join(caseDir, "config.json"))) {
    error(`Missing config.json in ${caseDir}`);
    return 1;
  }

  const config = readConfig(caseDir);
  const skillName = typeof config.skill === "string" ? config.skill : "";
  const timeout = typeof config.timeout === "number" ? config.timeout : 300;
  const allowedTools =
    typeof config.allowed_tools === "string"
      ? config.allowed_tools
      : "Write,Read,Glob,Grep";
  const maxTurns = typeof config.max_turns === "number" ? config.max_turns : 20;
  const expectedFiles = listExpectedFiles(config);
  const model = await resolveModel(config);
  const evalMode = detectMode(caseDir, config);

  info(`Skill: ${skillName || "(not specified)"}`);
  info(`Model: ${model || "(default)"}`);
  info(`Mode: ${evalMode}`);
  info(`Timeout: ${timeout}s`);

  const workDir = mkdtempSync(join(tmpdir(), "alexandria-eval-"));
  await runCommand(["git", "init", "-q"], { cwd: workDir });

  const fixtureDir = join(caseDir, "fixture");
  let fixHash = "none";
  if (existsSync(fixtureDir) && statSync(fixtureDir).isDirectory()) {
    copyDirContents(fixtureDir, workDir);
    fixHash = fixtureHash(fixtureDir);
    info(`Fixture copied (hash: ${fixHash.slice(0, 8)})`);
  }

  const baselineManifest = snapshotFiles(workDir);
  const baselineFiles = [...baselineManifest.keys()].sort();
  const skillFile = join(
    ROOT_DIR,
    "skills",
    casePath.split("/")[0]!,
    "SKILL.md",
  );
  const skillHash = fileHash(skillFile);
  const inputsHash = fileHash(join(caseDir, "inputs.md"));
  const configHash = fileHash(join(caseDir, "config.json"));
  const harnessHash = fileHash(__filename);
  const personaHash = fileHash(join(caseDir, "persona.md"));
  const gSha = await gitSha();

  info(`Git SHA: ${gSha}`);
  info(`Skill hash: ${skillHash.slice(0, 8)}`);

  const start = Date.now();
  let fullTranscript = "";
  let rawOutput = "";
  let exitCode = 0;
  let sessionId = "";

  const baseClaudeArgs = [
    "claude",
    "-p",
    "--plugin-dir",
    ROOT_DIR,
    "--allowedTools",
    allowedTools,
  ];

  if (evalMode === "adaptive") {
    info("Running adaptive (LLM-as-user) conversation...");
    info(`Max turns: ${maxTurns}`);

    const personaPath = join(caseDir, "persona.md");
    const personaContent = existsSync(personaPath)
      ? readFileSync(personaPath, "utf-8")
      : "";
    if (personaContent.length > 0) {
      info(
        `Persona loaded: ${readFileSync(personaPath, "utf-8").split("\n")[0]!.replace(/^# /, "")}`,
      );
    } else {
      warn(
        "No persona.md found — adaptive mode will use generic user behavior",
      );
    }

    const initialInput = readFileSync(join(caseDir, "inputs.md"), "utf-8");
    let turnNum = 0;
    let conversationDone = false;
    let history = "";
    const initialFileCount = listRelativeFiles(workDir).length;

    while (turnNum < maxTurns && !conversationDone) {
      turnNum += 1;
      let turnText = "";
      let turnLabel = "";

      if (turnNum === 1) {
        turnText = `@${skillName} ${initialInput}`;
        turnLabel = "User (scripted)";
      } else {
        turnLabel = "User (adaptive)";
        let userPrompt = `You are role-playing as a user in a conversation with an AI planning skill.

${personaContent}

Here is the conversation so far:

${history}

Respond naturally as this persona to whatever the skill just said. Stay in character.
Be direct and concise. If the skill asks you a question, answer it based on your
persona's preferences and context.`;
        if (allowedTools.includes("Write")) {
          userPrompt += `

If the skill asks for confirmation to proceed with writing output files, say yes
immediately.

IMPORTANT: If the skill says the plan is "done" or "finalized" but has NOT written
any files to disk (no release.md, no ticket files mentioned as written), push back:
ask the skill to write the actual plan files before ending. A conversation without
written deliverables is incomplete.`;
        }
        userPrompt += `

Respond with ONLY your in-character reply — no meta-commentary, no quotation marks,
no prefix like "User:". Just your natural response.`;

        const userResult = await runCommand(
          [
            "claude",
            "-p",
            "--allowedTools",
            "",
            "--model",
            "claude-sonnet-4-6",
          ],
          { cwd: workDir, input: userPrompt },
        );
        turnText = userResult.combined.trim() || "Please continue.";
      }

      info(`Turn ${turnNum}/${maxTurns} (${turnLabel})...`);

      const args = [...baseClaudeArgs, "--output-format", "json"];
      if (model) args.push("--model", model);
      if (sessionId) args.push("--resume", sessionId);
      const result = await runCommand(args, {
        cwd: workDir,
        input: turnText,
      });

      const payload =
        parseJsonObject(result.stdout.trim()) ??
        parseJsonObject(result.combined.trim());
      if (!sessionId && typeof payload?.["session_id"] === "string") {
        sessionId = String(payload["session_id"]);
        info(`Session: ${sessionId}`);
      }
      let turnResult =
        typeof payload?.["result"] === "string"
          ? String(payload["result"])
          : result.combined.trim();
      if (result.exitCode !== 0) {
        exitCode = result.exitCode;
        if (turnResult.length === 0) {
          turnResult = `[Turn ${turnNum} failed with exit code ${result.exitCode}]\n${result.combined}`;
        }
      }

      history += `\n--- Turn ${turnNum} ---\n${turnLabel}: ${turnText}\n\nSkill: ${turnResult}\n`;
      fullTranscript += `\n## Turn ${turnNum}: ${turnLabel}\n\n${turnText}\n\n---\n\n## Turn ${turnNum}: Skill Response\n\n${turnResult}\n\n---\n`;
      rawOutput += `${turnResult}\n`;

      if (expectedFiles.length > 0) {
        const currentFiles = listRelativeFiles(workDir);
        const foundAll = expectedFiles.every((fileName) =>
          currentFiles.some((relPath) => basename(relPath) === fileName),
        );
        if (foundAll) {
          info("All expected files found — conversation complete");
          conversationDone = true;
        }
      } else if (listRelativeFiles(workDir).length > initialFileCount) {
        info(
          `Output files detected (${listRelativeFiles(workDir).length} files, was ${initialFileCount}) — conversation complete`,
        );
        conversationDone = true;
      }

      if (result.exitCode !== 0) {
        warn(
          `Skill exited with code ${result.exitCode} — stopping conversation`,
        );
        conversationDone = true;
      }
    }

    if (!conversationDone && maxTurns > 0) {
      warn(`Reached max turn limit (${maxTurns}) without completion`);
    }
    info(`Adaptive conversation: ${turnNum} turns`);
  } else if (evalMode === "multi-turn") {
    info("Running multi-turn conversation...");
    const turns = parseMultiTurnInputs(join(caseDir, "inputs.md"));
    info(`Parsed ${turns.length} turns`);

    for (let i = 0; i < turns.length; i += 1) {
      const turnText = turns[i]!;
      info(`Turn ${i + 1}/${turns.length}...`);
      const args = [...baseClaudeArgs, "--output-format", "json"];
      if (model) args.push("--model", model);
      if (sessionId) args.push("--resume", sessionId);
      const result = await runCommand(args, { cwd: workDir, input: turnText });
      const payload =
        parseJsonObject(result.stdout.trim()) ??
        parseJsonObject(result.combined.trim());
      if (!sessionId && typeof payload?.["session_id"] === "string") {
        sessionId = String(payload["session_id"]);
        info(`Session: ${sessionId}`);
      }
      let turnResult =
        typeof payload?.["result"] === "string"
          ? String(payload["result"])
          : result.combined.trim();
      if (result.exitCode !== 0) {
        exitCode = result.exitCode;
        if (turnResult.length === 0) {
          turnResult = `[Turn ${i + 1} failed with exit code ${result.exitCode}]\n${result.combined}`;
        }
      }
      fullTranscript += `\n## Turn ${i + 1}: User\n\n${turnText}\n\n---\n\n## Turn ${i + 1}: Skill Response\n\n${turnResult}\n\n---\n`;
      rawOutput += `${turnResult}\n`;
    }
  } else {
    info("Running single-prompt...");
    const inputs = readFileSync(join(caseDir, "inputs.md"), "utf-8");
    const prompt = `@${skillName} ${inputs}

Write all output files as specified. Do not ask for confirmation at any step.`;
    const args = [...baseClaudeArgs];
    if (model) args.push("--model", model);
    const result = await runCommand(args, { cwd: workDir, input: prompt });
    rawOutput = result.combined;
    exitCode = result.exitCode;
    fullTranscript = `## Prompt (scripted)\n\n${inputs}\n\n---\n\n## Skill Output\n\n${rawOutput}\n`;
  }

  const duration = Math.floor((Date.now() - start) / 1000);
  info(`Completed in ${duration}s (exit code: ${exitCode})`);

  let savedBaselineDir: string | null = null;
  if (
    compare &&
    existsSync(outputDir) &&
    existsSync(join(outputDir, "run-metadata.json"))
  ) {
    savedBaselineDir = mkdtempSync(join(tmpdir(), "alexandria-eval-baseline-"));
    copyDirContents(outputDir, savedBaselineDir);
  }

  if (
    existsSync(outputDir) &&
    existsSync(join(outputDir, "run-metadata.json"))
  ) {
    const historyDir = join(outputDir, "runs", runTimestamp());
    ensureDir(historyDir);
    for (const name of [
      "run-metadata.json",
      "structural-results.json",
      "judge-results.json",
    ]) {
      const source = join(outputDir, name);
      if (existsSync(source)) {
        copyFileSync(source, join(historyDir, name));
      }
    }
  }

  removeEverythingExceptRuns(outputDir);
  ensureDir(join(outputDir, "output"));
  copyWorkdirOutput(workDir, join(outputDir, "output"));

  const currentManifest = snapshotFiles(workDir);
  const allFiles = [...currentManifest.keys()].sort();
  const newFiles = allFiles.filter(
    (filePath) => !baselineManifest.has(filePath),
  );
  const modifiedFiles = baselineFiles.filter(
    (filePath) =>
      currentManifest.has(filePath) &&
      currentManifest.get(filePath) !== baselineManifest.get(filePath),
  );
  const filesWritten = [...new Set([...newFiles, ...modifiedFiles])].sort();
  const fixtureFiles = baselineFiles.filter(
    (filePath) =>
      currentManifest.has(filePath) && !modifiedFiles.includes(filePath),
  );

  const timestamp = nowIso();
  const transcript = `# Eval Transcript: ${casePath}
**Date:** ${timestamp}
**Skill:** ${skillName || "(not specified)"}
**Model:** ${model || "(default)"}
**Mode:** ${evalMode}
**Duration:** ${duration}s
**Exit code:** ${exitCode}
**Git SHA:** ${gSha}
**Skill hash:** ${skillHash.slice(0, 12)}

---

${fullTranscript}

---

## Files Created by Skill

${renderList(newFiles)}

## Fixture Files Modified by Skill

${renderList(modifiedFiles)}

## Pre-existing Fixture Files (unmodified)

${renderList(fixtureFiles)}
`;
  writeFileSync(join(outputDir, "transcript.md"), transcript);
  success(`Transcript written to ${join(outputDir, "transcript.md")}`);

  writeFileSync(
    join(outputDir, "run-metadata.json"),
    `${JSON.stringify(
      {
        timestamp,
        skill: skillName,
        model,
        eval_mode: evalMode,
        version: VERSION,
        git_sha: gSha,
        skill_hash: skillHash,
        eval_case_hash: inputsHash,
        config_hash: configHash,
        harness_hash: harnessHash,
        fixture_hash: fixHash,
        persona_hash: personaHash,
        session_id: sessionId,
        duration_seconds: duration,
        exit_code: exitCode,
        case_path: casePath,
        files_written_count: filesWritten.length,
        fixture_files_count: fixtureFiles.length,
      },
      null,
      2,
    )}\n`,
  );
  success(`Metadata written to ${join(outputDir, "run-metadata.json")}`);

  rmSync(workDir, { recursive: true, force: true });

  let overallExitCode = exitCode;
  const structuralOk = await runStructuralChecks(casePath, outputDir);
  const hasBaselineForCompare = compare && savedBaselineDir != null;
  if (!structuralOk && !hasBaselineForCompare)
    overallExitCode = overallExitCode || 1;

  const criteriaFile = join(
    EVAL_CASES_DIR,
    casePath.split("/")[0]!,
    "judge-criteria.json",
  );
  if (existsSync(criteriaFile)) {
    const judgeOk = await runJudge(outputDir, criteriaFile);
    if (!judgeOk && !hasBaselineForCompare)
      overallExitCode = overallExitCode || 1;
  }

  process.stdout.write(`\n  Results: ${outputDir}/\n`);
  process.stdout.write(`  Files produced: ${filesWritten.length}\n`);
  process.stdout.write(`  Transcript: ${join(outputDir, "transcript.md")}\n`);

  if (compare) {
    if (savedBaselineDir) {
      const comparison = await runComparison(
        casePath,
        outputDir,
        savedBaselineDir,
      );
      if (comparison.regressions > 0) overallExitCode = overallExitCode || 1;
      rmSync(savedBaselineDir, { recursive: true, force: true });
    } else {
      info("No baseline to compare against (first run)");
    }
  }

  return overallExitCode;
}

async function main(): Promise<void> {
  const argv = process.argv.slice(2);
  const parsed = parseArgs(argv);

  const compareFlag = parsed.flags["compare"];
  const compare = compareFlag === true || typeof compareFlag === "string";
  const compareTarget = typeof compareFlag === "string" ? compareFlag : null;

  if (parsed.positional.length < 1 && compareTarget == null) {
    usage();
    process.exit(0);
  }

  if (compareTarget != null && parsed.positional.length > 0) {
    error(
      "Specify the eval target either positionally or after --compare, not both",
    );
    process.exit(1);
  }

  const target = parsed.positional[0] ?? compareTarget;
  if (!target) {
    usage();
    process.exit(0);
  }
  for (const flag of Object.keys(parsed.flags)) {
    if (flag !== "compare") {
      error(`Unknown option: --${flag}`);
      process.exit(1);
    }
  }

  process.stdout.write(`Alexandria — Eval Runner v${VERSION}\n`);
  process.stdout.write(`Plugin: ${ROOT_DIR}\n`);

  const cases = resolveCases(target);
  if (cases.length === 0) {
    error(`No eval cases found for: ${target}`);
    process.exit(1);
  }

  let passed = 0;
  let failed = 0;
  for (const casePath of cases) {
    const code = await runEvalCase(casePath, compare);
    if (code === 0) {
      passed += 1;
    } else {
      failed += 1;
    }
  }

  process.stdout.write("\n═══════════════════════════════════════════\n");
  process.stdout.write(`Eval Summary: ${passed}/${cases.length} passed\n`);
  if (failed > 0) {
    process.stdout.write(`${failed} FAILED\n`);
    process.exit(1);
  }
  process.stdout.write("ALL PASSED\n");
}

await main();
