/**
 * Alexandria Wizard Engine CLI.
 *
 * Computes tier assignments for 22 knowledge areas given (ai_mode, novelty, complexity).
 * Reads wizard-engine.yaml at runtime — no compiled copy.
 *
 * Usage:
 *   alexandria-wizard --mode factory --novelty high --complexity moderate
 *   alexandria-wizard --mode factory --novelty high --complexity moderate --format json
 *   alexandria-wizard --validate
 */

import { readFileSync } from "fs";
import { existsSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import { parseArgs } from "../lib/cli.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const REPO_ROOT = join(__dirname, "..", "..");
const DEFAULT_YAML = join(REPO_ROOT, "docs", "wizard", "wizard-engine.yaml");

const VALID_MODES = [
  "no_low_ai",
  "short_order_cook",
  "pair_programmer",
  "factory",
] as const;
const VALID_LEVELS = ["low", "moderate", "high"] as const;

type Mode = (typeof VALID_MODES)[number];
type Level = (typeof VALID_LEVELS)[number];

const TIER_ORDER: Record<string, number> = {
  foundation: 0,
  core: 1,
  amplifier: 2,
  deprioritized: 3,
};

function tierMax(a: string, b: string): string {
  return (TIER_ORDER[a] ?? 99) <= (TIER_ORDER[b] ?? 99) ? a : b;
}

// ── Types ──────────────────────────────────────────────────────────────────

interface CatalogItem {
  id: string;
  name: string;
  domain: string;
  description?: string;
  when_missing?: string;
}

interface AreaProfile {
  novelty: string | null;
  complexity: string | null;
  floors: Record<string, string>;
}

interface Engine {
  catalog: CatalogItem[];
  pools: Record<string, { areas: string[] }>;
  foundation: Record<string, string[]>;
  novelty_profiles: Record<string, Record<string, string>>;
  complexity_profiles: Record<string, Record<string, string>>;
  area_profiles: Record<string, AreaProfile>;
  progression_lookup: Record<string, string>;
  journey_maps_override: Record<string, string>;
  design_system_override: Record<string, string>;
  mode_narratives: Record<string, Record<string, string>>;
  tiers: Record<string, Record<string, string>>;
}

interface AreaResult {
  id: string;
  name: string;
  domain: string;
  tier: string;
  override?: string;
}

// ── Minimal YAML parser ────────────────────────────────────────────────────
// Purpose-built for wizard-engine.yaml structure. Not a general YAML parser.

function unquote(s: string): string {
  s = s.trim();
  if (
    (s.startsWith('"') && s.endsWith('"')) ||
    (s.startsWith("'") && s.endsWith("'"))
  ) {
    return s.slice(1, -1);
  }
  return s;
}

function parseInlineList(s: string): string[] {
  s = s.trim();
  if (s.startsWith("[") && s.endsWith("]")) {
    const items = s.slice(1, -1).split(",");
    return items.map((item) => unquote(item)).filter((item) => item.length > 0);
  }
  return [];
}

function countChar(s: string, needle: string): number {
  return [...s].filter((ch) => ch === needle).length;
}

function parseListValue(
  lines: string[],
  start: number,
  rawValue: string,
): { items: string[]; nextIndex: number } {
  let value = rawValue.trim();
  let i = start;

  if (value.startsWith("[") && value.endsWith("]")) {
    return { items: parseInlineList(value), nextIndex: i };
  }

  if (!value || value.startsWith("[")) {
    const parts = value ? [value] : [];
    let bracketBalance = countChar(value, "[") - countChar(value, "]");

    while (i + 1 < lines.length && (parts.length === 0 || bracketBalance > 0)) {
      i++;
      const next = lines[i]!.trim();
      if (!next || next.startsWith("#")) {
        continue;
      }
      parts.push(next);
      bracketBalance += countChar(next, "[") - countChar(next, "]");
    }

    value = parts.join(" ");
  }

  return { items: parseInlineList(value), nextIndex: i };
}

function indentLevel(line: string): number {
  return line.length - line.trimStart().length;
}

function skipSection(lines: string[], start: number): number {
  let i = start;
  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    if (line && !line[0]!.match(/\s/) && !line.startsWith("#")) {
      return i;
    }
    i++;
  }
  return i;
}

function parseCatalog(lines: string[], start: number, engine: Engine): number {
  let i = start;
  let currentItem: Partial<CatalogItem> = {};

  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    const stripped = line.trimStart();

    if (!stripped || stripped.startsWith("#")) {
      i++;
      continue;
    }

    if (indentLevel(line) === 0 && !stripped.startsWith("-")) {
      break;
    }

    if (stripped.startsWith("- id:")) {
      if (currentItem.id != null) {
        engine.catalog.push(currentItem as CatalogItem);
      }
      currentItem = { id: unquote(stripped.split(":", 2)[1]!) };
    } else if (stripped.startsWith("name:")) {
      currentItem.name = unquote(stripped.split(":", 2)[1]!);
    } else if (stripped.startsWith("domain:")) {
      currentItem.domain = unquote(stripped.split(":", 2)[1]!);
    } else if (stripped.startsWith("description:")) {
      currentItem.description = unquote(stripped.split(":", 2)[1]!);
    } else if (stripped.startsWith("when_missing:")) {
      currentItem.when_missing = unquote(stripped.split(":", 2)[1]!);
    }

    i++;
  }

  if (currentItem.id != null) {
    engine.catalog.push(currentItem as CatalogItem);
  }
  return i;
}

function parsePools(lines: string[], start: number, engine: Engine): number {
  let i = start;
  let currentMode: string | null = null;

  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    const stripped = line.trimStart();

    if (!stripped || stripped.startsWith("#")) {
      i++;
      continue;
    }

    if (indentLevel(line) === 0) {
      break;
    }

    const indent = indentLevel(line);
    if (indent === 2 && stripped.includes(":") && !stripped.startsWith("-")) {
      const key = stripped.split(":")[0]!.trim();
      if ((VALID_MODES as readonly string[]).includes(key)) {
        currentMode = key;
        engine.pools[currentMode] = { areas: [] };
      }
    } else if (currentMode != null && stripped.includes("areas:")) {
      const val = stripped.split(":", 2)[1]!.trim();
      const parsed = parseListValue(lines, i, val);
      engine.pools[currentMode]!.areas = parsed.items;
      i = parsed.nextIndex;
    }

    i++;
  }
  return i;
}

function parseFoundation(
  lines: string[],
  start: number,
  engine: Engine,
): number {
  let i = start;

  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    const stripped = line.trimStart();

    if (!stripped || stripped.startsWith("#")) {
      i++;
      continue;
    }

    if (indentLevel(line) === 0) {
      break;
    }

    if (stripped.includes(":")) {
      const key = stripped.split(":")[0]!.trim();
      const val = stripped.split(":", 2)[1]!.trim();
      if ((VALID_MODES as readonly string[]).includes(key)) {
        const parsed = parseListValue(lines, i, val);
        engine.foundation[key] = parsed.items;
        i = parsed.nextIndex;
      }
    }

    i++;
  }
  return i;
}

function parseProfiles(
  lines: string[],
  start: number,
  profiles: Record<string, Record<string, string>>,
): number {
  let i = start;
  let currentProfile: string | null = null;

  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    const stripped = line.trimStart();

    if (!stripped || stripped.startsWith("#")) {
      i++;
      continue;
    }

    if (indentLevel(line) === 0) {
      break;
    }

    const indent = indentLevel(line);
    if (indent === 2 && stripped.includes(":")) {
      const key = stripped.split(":")[0]!.trim();
      const val = stripped.split(":", 2)[1]!.trim();
      if (val) {
        if (currentProfile != null) {
          profiles[currentProfile]![key] = unquote(val);
        }
      } else {
        currentProfile = key;
        profiles[currentProfile] = {};
      }
    } else if (
      indent === 4 &&
      stripped.includes(":") &&
      currentProfile != null
    ) {
      const key = stripped.split(":")[0]!.trim();
      const val = unquote(stripped.split(":", 2)[1]!);
      profiles[currentProfile]![key] = val;
    }

    i++;
  }
  return i;
}

function parseAreaProfiles(
  lines: string[],
  start: number,
  engine: Engine,
): number {
  let i = start;
  let currentArea: string | null = null;
  let currentFloors: Record<string, string> = {};

  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    const stripped = line.trimStart();

    if (!stripped || stripped.startsWith("#")) {
      i++;
      continue;
    }

    if (indentLevel(line) === 0) {
      break;
    }

    const indent = indentLevel(line);
    if (indent === 2 && stripped.startsWith('"') && stripped.includes(":")) {
      // Save previous area
      if (currentArea != null) {
        engine.area_profiles[currentArea]!.floors = currentFloors;
      }

      const areaId = unquote(stripped.split(":")[0]!);
      currentArea = areaId;
      engine.area_profiles[areaId] = {
        novelty: null,
        complexity: null,
        floors: {},
      };
      currentFloors = {};
    } else if (currentArea != null && indent >= 4) {
      if (stripped.startsWith("novelty:")) {
        const val = stripped.split(":", 2)[1]!.trim();
        engine.area_profiles[currentArea]!.novelty =
          val === "null" ? null : unquote(val);
      } else if (stripped.startsWith("complexity:")) {
        const val = stripped.split(":", 2)[1]!.trim();
        engine.area_profiles[currentArea]!.complexity =
          val === "null" ? null : unquote(val);
      } else if (stripped.startsWith("floors:")) {
        currentFloors = {};
      } else if (stripped.includes(":") && !stripped.startsWith("#")) {
        const key = stripped.split(":")[0]!.trim();
        const val = unquote(stripped.split(":", 2)[1]!);
        if ((VALID_MODES as readonly string[]).includes(key)) {
          currentFloors[key] = val;
        }
      }
    }

    i++;
  }

  if (currentArea != null) {
    engine.area_profiles[currentArea]!.floors = currentFloors;
  }
  return i;
}

function parseFlatMap(
  lines: string[],
  start: number,
  target: Record<string, string>,
): number {
  let i = start;

  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    const stripped = line.trimStart();

    if (!stripped || stripped.startsWith("#")) {
      i++;
      continue;
    }

    if (indentLevel(line) === 0) {
      break;
    }

    if (stripped.includes(":")) {
      const key = stripped.split(":")[0]!.trim();
      const val = unquote(stripped.split(":", 2)[1]!);
      target[key] = val;
    }

    i++;
  }
  return i;
}

function parseOverrideBlock(
  lines: string[],
  start: number,
  target: Record<string, string>,
): number {
  let i = start;

  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    const stripped = line.trimStart();

    if (!stripped || stripped.startsWith("#")) {
      i++;
      continue;
    }

    if (indentLevel(line) === 0) {
      break;
    }

    if (stripped.includes(":")) {
      const key = stripped.split(":")[0]!.trim();
      const val = unquote(stripped.split(":", 2)[1]!);
      target[key] = val;
    }

    i++;
  }
  return i;
}

function parseModeNarratives(
  lines: string[],
  start: number,
  engine: Engine,
): number {
  let i = start;
  let currentMode: string | null = null;

  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    const stripped = line.trimStart();

    if (!stripped || stripped.startsWith("#")) {
      i++;
      continue;
    }

    if (indentLevel(line) === 0) {
      break;
    }

    const indent = indentLevel(line);
    if (indent === 2 && stripped.includes(":")) {
      const key = stripped.split(":")[0]!.trim();
      const val = stripped.split(":", 2)[1]!.trim();
      if ((VALID_MODES as readonly string[]).includes(key) && !val) {
        currentMode = key;
        engine.mode_narratives[currentMode] = {};
      } else if (currentMode != null) {
        engine.mode_narratives[currentMode]![key] = unquote(val);
      }
    } else if (indent === 4 && currentMode != null && stripped.includes(":")) {
      const key = stripped.split(":")[0]!.trim();
      const val = unquote(stripped.split(":", 2)[1]!);
      engine.mode_narratives[currentMode]![key] = val;
    }

    i++;
  }
  return i;
}

function parseTiers(lines: string[], start: number, engine: Engine): number {
  let i = start;
  let currentTier: string | null = null;

  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    const stripped = line.trimStart();

    if (!stripped || stripped.startsWith("#")) {
      i++;
      continue;
    }

    if (indentLevel(line) === 0) {
      break;
    }

    const indent = indentLevel(line);
    if (indent === 2 && stripped.includes(":")) {
      const key = stripped.split(":")[0]!.trim();
      const val = stripped.split(":", 2)[1]!.trim();
      if (!val) {
        currentTier = key;
        engine.tiers[currentTier] = {};
      } else if (currentTier != null) {
        engine.tiers[currentTier]![key] = unquote(val);
      }
    } else if (indent === 4 && currentTier != null && stripped.includes(":")) {
      const key = stripped.split(":")[0]!.trim();
      const val = unquote(stripped.split(":", 2)[1]!);
      engine.tiers[currentTier]![key] = val;
    }

    i++;
  }
  return i;
}

function parseEngineYaml(filepath: string): Engine {
  const content = readFileSync(filepath, "utf-8");
  const lines = content.split("\n");

  const engine: Engine = {
    catalog: [],
    pools: {},
    foundation: {},
    novelty_profiles: {},
    complexity_profiles: {},
    area_profiles: {},
    progression_lookup: {},
    journey_maps_override: {},
    design_system_override: {},
    mode_narratives: {},
    tiers: {},
  };

  let i = 0;
  while (i < lines.length) {
    const line = lines[i]!.trimEnd();
    const stripped = line.trimStart();

    if (!stripped || stripped.startsWith("#")) {
      i++;
      continue;
    }

    if (line.startsWith("catalog:")) {
      i = parseCatalog(lines, i + 1, engine);
    } else if (line.startsWith("pools:")) {
      i = parsePools(lines, i + 1, engine);
    } else if (line.startsWith("foundation:")) {
      i = parseFoundation(lines, i + 1, engine);
    } else if (line.startsWith("novelty_profiles:")) {
      i = parseProfiles(lines, i + 1, engine.novelty_profiles);
    } else if (line.startsWith("complexity_profiles:")) {
      i = parseProfiles(lines, i + 1, engine.complexity_profiles);
    } else if (line.startsWith("area_profiles:")) {
      i = parseAreaProfiles(lines, i + 1, engine);
    } else if (line.startsWith("progression_lookup:")) {
      i = parseFlatMap(lines, i + 1, engine.progression_lookup);
    } else if (line.startsWith("journey_maps_pair_programmer_override:")) {
      i = parseOverrideBlock(lines, i + 1, engine.journey_maps_override);
    } else if (line.startsWith("design_system_no_low_ai_override:")) {
      i = parseOverrideBlock(lines, i + 1, engine.design_system_override);
    } else if (line.startsWith("mode_narratives:")) {
      i = parseModeNarratives(lines, i + 1, engine);
    } else if (line.startsWith("tiers:")) {
      i = parseTiers(lines, i + 1, engine);
    } else if (line.startsWith("questions:")) {
      // Skip questions section — not needed for computation
      i = skipSection(lines, i + 1);
    } else {
      i++;
    }
  }

  return engine;
}

// ── Engine computation ─────────────────────────────────────────────────────

function computeTiers(
  engine: Engine,
  mode: Mode,
  novelty: Level,
  complexity: Level,
): AreaResult[] {
  const poolAreas = engine.pools[mode]?.areas ?? [];
  const foundationAreas = new Set(engine.foundation[mode] ?? []);

  const catalogMap = new Map(engine.catalog.map((item) => [item.id, item]));

  const results: AreaResult[] = [];

  for (const areaId of poolAreas) {
    const catItem = catalogMap.get(areaId);
    const areaName = catItem?.name ?? areaId;
    const domain = catItem?.domain ?? "";

    // Check if foundation
    if (foundationAreas.has(areaId)) {
      results.push({ id: areaId, name: areaName, domain, tier: "foundation" });
      continue;
    }

    // Special case: Progression / Mastery (3.4) uses lookup table
    if (areaId === "3.4") {
      const lookupKey = `${novelty}_${complexity}`;
      const tier = engine.progression_lookup[lookupKey] ?? "deprioritized";
      const result: AreaResult = {
        id: areaId,
        name: areaName,
        domain,
        tier,
        override: "progression_lookup",
      };
      // Apply floor
      const profile = engine.area_profiles[areaId];
      const floor = profile?.floors[mode];
      if (floor) {
        result.tier = tierMax(tier, floor);
      }
      results.push(result);
      continue;
    }

    // Standard computation
    const profile = engine.area_profiles[areaId];
    const noveltyProfileName = profile?.novelty ?? null;
    const complexityProfileName = profile?.complexity ?? null;

    // Get tier from novelty profile
    let noveltyTier = "deprioritized";
    if (noveltyProfileName) {
      const np = engine.novelty_profiles[noveltyProfileName];
      noveltyTier = np?.[novelty] ?? "deprioritized";
    }

    // Get tier from complexity profile
    let complexityTier = "deprioritized";
    if (complexityProfileName) {
      const cp = engine.complexity_profiles[complexityProfileName];
      complexityTier = cp?.[complexity] ?? "deprioritized";
    }

    // Combined tier = max(novelty, complexity)
    let combined: string;
    if (noveltyProfileName && complexityProfileName) {
      combined = tierMax(noveltyTier, complexityTier);
    } else if (noveltyProfileName) {
      combined = noveltyTier;
    } else if (complexityProfileName) {
      combined = complexityTier;
    } else {
      combined = "deprioritized";
    }

    // Apply floor
    const floor = profile?.floors[mode];
    if (floor) {
      combined = tierMax(combined, floor);
    }

    const result: AreaResult = {
      id: areaId,
      name: areaName,
      domain,
      tier: combined,
    };

    // Apply overrides
    // Journey Maps at pair_programmer: floor is amplifier unless novelty is low
    if (areaId === "3.1" && mode === "pair_programmer") {
      const overrideFloor = novelty === "low" ? "deprioritized" : "amplifier";
      const newTier = tierMax(combined, overrideFloor);
      if (newTier !== combined) {
        result.tier = newTier;
        result.override = "journey_maps_pair_programmer";
      }
    }

    // Design System at no_low_ai: tier is core if complexity is high, amplifier otherwise
    if (areaId === "4.1" && mode === "no_low_ai") {
      result.tier = complexity === "high" ? "core" : "amplifier";
      result.override = "design_system_no_low_ai";
    }

    results.push(result);
  }

  // Sort by tier priority then catalog order
  const areaOrder = new Map(engine.catalog.map((item, idx) => [item.id, idx]));
  results.sort((a, b) => {
    const tierDiff = (TIER_ORDER[a.tier] ?? 99) - (TIER_ORDER[b.tier] ?? 99);
    if (tierDiff !== 0) return tierDiff;
    return (areaOrder.get(a.id) ?? 99) - (areaOrder.get(b.id) ?? 99);
  });

  return results;
}

function formatJson(
  results: AreaResult[],
  mode: string,
  novelty: string,
  complexity: string,
): string {
  const summary: Record<string, number> = {};
  for (const r of results) {
    summary[r.tier] = (summary[r.tier] ?? 0) + 1;
  }

  const output = {
    inputs: { mode, novelty, complexity },
    areas: results,
    summary,
  };
  return JSON.stringify(output, null, 2);
}

function formatText(
  results: AreaResult[],
  mode: string,
  novelty: string,
  complexity: string,
): string {
  const lines: string[] = [
    `Configuration: ${mode} × ${novelty} novelty × ${complexity} complexity`,
    "",
  ];

  let currentTier: string | null = null;
  for (const r of results) {
    if (r.tier !== currentTier) {
      currentTier = r.tier;
      lines.push(`--- ${currentTier.toUpperCase()} ---`);
    }
    const override = r.override ? ` (${r.override})` : "";
    lines.push(`  ${r.id} ${r.name}${override}`);
  }

  lines.push("");
  const summary: Record<string, number> = {};
  for (const r of results) {
    summary[r.tier] = (summary[r.tier] ?? 0) + 1;
  }
  const parts = Object.entries(summary)
    .sort((a, b) => (TIER_ORDER[a[0]] ?? 99) - (TIER_ORDER[b[0]] ?? 99))
    .map(([k, v]) => `${v} ${k}`);
  lines.push(`Total: ${results.length} areas (${parts.join(", ")})`);

  return lines.join("\n");
}

function validateAll(engine: Engine): {
  passed: number;
  failed: number;
  errors: string[];
} {
  let passed = 0;
  let failed = 0;
  const errors: string[] = [];

  for (const mode of VALID_MODES) {
    for (const novelty of VALID_LEVELS) {
      for (const complexity of VALID_LEVELS) {
        try {
          const results = computeTiers(engine, mode, novelty, complexity);
          const poolSize = engine.pools[mode]?.areas.length ?? 0;
          if (results.length !== poolSize) {
            errors.push(
              `${mode}/${novelty}/${complexity}: expected ${poolSize} areas, got ${results.length}`,
            );
            failed++;
          } else {
            const foundationIds = new Set(engine.foundation[mode] ?? []);
            let ok = true;
            for (const r of results) {
              if (foundationIds.has(r.id) && r.tier !== "foundation") {
                errors.push(
                  `${mode}/${novelty}/${complexity}: ${r.id} should be foundation`,
                );
                failed++;
                ok = false;
                break;
              }
            }
            if (ok) passed++;
          }
        } catch (e) {
          errors.push(
            `${mode}/${novelty}/${complexity}: ${e instanceof Error ? e.message : e}`,
          );
          failed++;
        }
      }
    }
  }

  return { passed, failed, errors };
}

// ── Main ───────────────────────────────────────────────────────────────────

const args = parseArgs(process.argv.slice(2));

const enginePath = (args.flags["engine"] as string | undefined) ?? DEFAULT_YAML;

if (!existsSync(enginePath)) {
  console.error(`Error: engine file not found: ${enginePath}`);
  process.exit(1);
}

const engine = parseEngineYaml(enginePath);

if (args.flags["validate"] === true) {
  const { passed, failed, errors } = validateAll(engine);
  console.log(
    `Validated ${passed + failed} combinations: ${passed} passed, ${failed} failed`,
  );
  for (const err of errors) {
    console.log(`  FAIL: ${err}`);
  }
  process.exit(failed === 0 ? 0 : 1);
}

const mode = args.flags["mode"] as string | undefined;
const novelty = args.flags["novelty"] as string | undefined;
const complexity = args.flags["complexity"] as string | undefined;

if (!mode || !novelty || !complexity) {
  console.error(
    "Error: --mode, --novelty, and --complexity are required (or use --validate)",
  );
  process.exit(1);
}

if (!(VALID_MODES as readonly string[]).includes(mode)) {
  console.error(
    `Error: invalid mode '${mode}'. Valid modes: ${VALID_MODES.join(", ")}`,
  );
  process.exit(1);
}

if (!(VALID_LEVELS as readonly string[]).includes(novelty)) {
  console.error(
    `Error: invalid novelty '${novelty}'. Valid levels: ${VALID_LEVELS.join(", ")}`,
  );
  process.exit(1);
}

if (!(VALID_LEVELS as readonly string[]).includes(complexity)) {
  console.error(
    `Error: invalid complexity '${complexity}'. Valid levels: ${VALID_LEVELS.join(", ")}`,
  );
  process.exit(1);
}

const results = computeTiers(
  engine,
  mode as Mode,
  novelty as Level,
  complexity as Level,
);
const fmt = (args.flags["format"] as string | undefined) ?? "json";

if (fmt === "json") {
  console.log(formatJson(results, mode, novelty, complexity));
} else {
  console.log(formatText(results, mode, novelty, complexity));
}
