# Scoreboard Derivation Spec

Status: Draft for `LIB2-002`

This document defines how `/library` derives scoreboard fill levels from checked-in state on
disk. It is the contract for later implementation tickets:

- `LIB2-003` renderer
- `LIB2-006` session-start procedure

The scoreboard is derived, not persisted. Any agent can change the underlying state by
adding source material, building cards, grading cards, or logging open questions. Raven
recomputes the scoreboard from that state at session start.

## Scope

This spec answers four questions:

1. Which knowledge areas appear on the scoreboard
2. What evidence counts for each area
3. How an area resolves to `0 / 25 / 50 / 75 / 100`
4. How bucket aggregates and clearance messages are computed

This spec does not define:

- the ASCII rendering format
- Raven's spoken copy
- how future code parses each source artifact internally

## Path Alignment

Some upstream planning text still uses the pre-rename path `docs/context-library/...`.
The active repo paths for this spec are:

- config: `docs/alexandria/wizard-config.json`
- sources: `docs/alexandria/sources/`
- cards: `docs/alexandria/library/`
- checked-in queue artifact: `docs/alexandria/signal-queue.jsonl`
- optional operational queue path referenced elsewhere in product docs:
  `docs/alexandria/feedback-queue.jsonl`

Future implementation should read current repo paths, not the legacy path strings in older
planning docs, and should treat `feedback-queue.jsonl` as optional until a runtime workflow
actually creates it on disk.

## Configuration Basis

The current checked-in wizard engine in this repo defines `36` configurations:

- `4` modes
- `3` novelty levels
- `3` complexity levels

The scoreboard must work for any valid `wizard-config.json` produced by that engine.

Only areas in `wizard-config.json.areas[]` participate in derivation. Areas that are not in
the active pool do not receive bars, do not affect bucket means, and do not affect
clearance.

Deprioritized areas may exist in `wizard-config.json.areas[]`, but the active scoreboard
surface for Phase 2 is limited to Foundation, Core, and Amplifier buckets. Deprioritized
areas are ignored for clearance and lock logic unless a later renderer chooses to surface
them separately.

## Inputs

Derivation uses four evidence classes.

### 1. Area Configuration

From `docs/alexandria/wizard-config.json`:

- active area IDs
- area names
- tier assignment per area

This is the only authoritative source for bucket membership.

### 2. Source Evidence

From `docs/alexandria/sources/`:

- source files explicitly attributable to one or more knowledge areas
- whether source material exists at all for the area

A source file counts for an area only if the file itself explicitly names that area, for
example:

- `Source material for knowledge area 3.2.`
- `Source material for knowledge areas 5.2 and 5.4.`

Unattributed source files do not move the scoreboard.

### 3. Card Evidence

From the current library plus Conan-produced area mapping artifacts:

- card files that exist on disk under `docs/alexandria/library/`
- explicit mapping from a knowledge area to the cards expected for that area

The mapping must come from an explicit Conan artifact, such as the latest inventory or
manifest that groups cards by wizard area. Raw card existence without an explicit area
mapping does not count, because the scoreboard is per knowledge area, not per card type.

### 4. Quality And Question Evidence

From persisted operational artifacts:

- Conan grade or health-check evidence that explicitly names a card and its latest grade
- persisted open questions, contested claims, or gap flags that explicitly point to an area
  or one of its mapped cards

For Phase 2, any persisted unresolved question caps the area at `75`, even if card grades
are otherwise strong. The scoreboard reflects "functioning with no live blockers," not
"best observed grade at some point in time."

## Normalized Evidence Model

Later implementation may parse different files to assemble evidence, but it must reduce the
state for each active area to this normalized shape:

```text
AreaEvidence {
  area_id: string
  tier: foundation | core | amplifier | deprioritized
  source_files: string[]
  source_ready: boolean
  mapped_expected_cards: string[]
  mapped_existing_cards: string[]
  graded_cards_b_plus_or_better: string[]
  graded_cards_below_b_plus: string[]
  unresolved_questions: string[]
}
```

Notes:

- `source_ready` means "card-buildable source exists," not merely "a file exists."
- `mapped_expected_cards` comes from the latest explicit area-to-card mapping artifact.
- `graded_cards_b_plus_or_better` uses the existing Raven confidence threshold:
  `B+` or better counts as functioning quality for an area.
- If an input cannot be proven from disk, it is treated as absent.

## Source Readiness Rule

Source existence and source readiness are distinct.

- `source exists`: at least one explicitly attributed source file exists for the area
- `source ready`: the repo has explicit evidence that the area's source is card-buildable

An area's source is considered `ready` when at least one of these is true:

1. the latest Conan source-assessment or equivalent artifact does not flag the area as
   missing or deferred, and the area has attributed source files
2. the latest Conan inventory or manifest includes expected cards for that area, which is
   stronger proof that Conan judged the source buildable

If source files exist but there is no explicit readiness signal yet, the area remains in
the raw-material state.

## Area Matching Rules

### Sources To Areas

- A source file may map to one area or multiple areas.
- If a file explicitly names multiple areas, it counts for each named area.
- If a source file names no area, it does not count.

### Cards To Areas

- Cards count only through the latest explicit area mapping artifact.
- If the mapping artifact lists expected cards for an area, only those cards are relevant
  for that area's scoreboard state.
- Extra cards not mapped to an area do not change that area's fill level.

This conservative rule prevents the scoreboard from claiming coverage because a vaguely
related card happens to exist somewhere in the library.

## Fill-Level States

The lifecycle markers are:

| State | Fill | Meaning |
|-------|------|---------|
| Nothing | `0` | No attributable source material and no attributable cards |
| Raw material dumped | `25` | Attributable source material exists, but card-ready evidence does not |
| Elicitation done | `50` | Card-ready evidence exists, but no mapped cards exist yet |
| Cards drafted, questions remain | `75` | Mapped cards exist, but the area is not yet proven functioning |
| Functioning | `100` | Mapped cards exist, pass threshold, and have no unresolved blockers |

These are lifecycle markers, not quality percentages. `100` means "functioning enough to
serve builders reliably," not "exhaustive."

## Derivation Ladder

Evaluate each active area in this order.

### Step 1: No Evidence

If all of the following are true, the area is `0`:

- no attributed source files
- no mapped expected cards
- no mapped existing cards

This resolves the explicit ticket case:

- area present in `wizard-config.json` but no attributable source or card evidence
  -> `0`

### Step 2: Source Exists But Is Not Yet Buildable

If the area has attributed source files, but `source_ready` is false and there are no
mapped existing cards, the area is `25`.

This is the "thin dump" state. A file exists, but the repo cannot yet prove that Sam could
build reliable cards from it.

### Step 3: Source Is Buildable, Cards Not Yet Built

If `source_ready` is true and `mapped_existing_cards` is empty, the area is `50`.

This is the "elicitation done" state. The material is good enough to build from, but the
library has not turned it into card coverage yet.

### Step 4: Cards Exist, But Functioning Is Not Yet Proven

If one or more mapped cards exist, the area is at least `75`.

It stays at `75` when any of the following are true:

- one or more expected mapped cards are still missing
- no Conan grade evidence exists yet for one or more mapped existing cards
- any mapped card's latest explicit Conan grade is below `B+`
- any unresolved question explicitly targets the area or one of its mapped cards

This is the answer for the partial-card ambiguity: a card file on disk is enough to move an
area out of `50`, but until the mapped set is complete and functioning-quality evidence
exists, the area remains `75`.

### Step 5: Functioning

The area is `100` only when all of the following are true:

1. at least one mapped card exists
2. every expected mapped card exists on disk
3. every mapped existing card has explicit Conan evidence at `B+` or better
4. no unresolved questions explicitly target the area or one of its mapped cards

This is intentionally conservative. A future implementation may cache or normalize the
evidence, but it must not infer `100` from optimistic heuristics.

## Ambiguous Cases

### Multiple Cards Per Knowledge Area

Decision:

- use the full mapped card set for the area
- the area is only `100` when every mapped card meets the `100` criteria
- otherwise the area is `75`

Rationale:

- average-based scoring can hide a weak or missing card inside a "healthy looking" area
- weakest-card semantics are the right fit for a trust artifact used for build clearance
- because the mapped set comes from Conan's explicit area grouping, this does not let
  unrelated peripheral cards drag the area down

### Partial Cards

Decision:

- any mapped card file on disk moves the area into the card-built branch
- partial or structurally weak cards do not earn `100`
- until the mapped card set is complete and graded `B+` or better, the area stays `75`

Rationale:

- the user should see progress when Sam has started building
- but a half-built card is exactly "cards drafted, questions remain," not "functioning"

### Source Material Without Cards

Decision:

- source only -> `25`
- source plus explicit build-ready evidence -> `50`

Build-ready evidence must be explicit, not guessed. The preferred signals are:

- Conan source assessment
- Conan inventory or manifest

Rationale:

- the expert-calibration material explicitly warns that source presence alone is a trap
- the scoreboard should not claim "elicitation done" until the repo has proof that the
  area is card-ready

### Knowledge Area With No Matching Card Evidence

Decision:

- if the area is active in `wizard-config.json` but has no attributable source or card
  evidence, it is `0`

Rationale:

- the scoreboard is per configured area, not per vaguely related library material
- unknown mappings should fail closed

## Bucket Aggregates

Use the numeric values `0`, `25`, `50`, `75`, and `100`.

For each rendered bucket:

```text
bucket_fill_percent = mean(fill_values_for_areas_in_bucket)
```

Definitions:

- `Foundation fill %` = mean of active Foundation-area fill values
- `Core fill %` = mean of active Core-area fill values
- `Amplifier fill %` = mean of active Amplifier-area fill values

No weighting is applied inside a bucket. Each active area counts equally.

If a bucket has zero active areas, omit it rather than synthesizing `0%`.

## Clearance And Lock Rules

### Core Locked Condition

Core is locked when:

```text
mean(fill_values_for_foundation_areas) < 80
```

This is a bucket-level lock. Core can be visible on the scoreboard while still locked.

### Foundation Clearance Messages

Foundation uses three message states.

1. `Not cleared`
   - condition: Foundation mean `< 80`
   - effect: Core locked

2. `Provisionally cleared`
   - condition: Foundation mean `>= 80`, but one or more Foundation areas are below `100`
   - effect: Core unlocked, but Raven must name the remaining non-functioning Foundation
     areas

3. `Fully cleared`
   - condition: every active Foundation area is exactly `100`
   - effect: full Foundation clearance

For full Foundation clearance, the required set is:

- every area whose `tier` is `foundation` in the active `wizard-config.json`

There is no separate hard-coded list in the spec because the set varies by configuration.

## Pseudocode

```text
for each active area in wizard-config.json:
  evidence = gather_normalized_evidence(area)

  if no source_files and no mapped_expected_cards and no mapped_existing_cards:
    fill = 0
    continue

  if mapped_existing_cards is empty:
    if source_ready:
      fill = 50
    else:
      fill = 25
    continue

  missing_expected_cards = mapped_expected_cards - mapped_existing_cards

  if unresolved_questions not empty:
    fill = 75
    continue

  if missing_expected_cards not empty:
    fill = 75
    continue

  if any mapped_existing_card lacks Conan grade evidence:
    fill = 75
    continue

  if any mapped_existing_card has latest Conan grade below B+:
    fill = 75
    continue

  fill = 100
```

## Worked Review

These are sanity checks against the current checked-in wizard engine, not normative fixture
files. They show that the derivation rules behave sensibly on both a large and a small
configuration shape.

### Review A: Factory / High / High

Current wizard engine shape:

- Foundation: `5`
- Core: `15`
- Amplifier: `2`

Example evidence:

| Area | Tier | Evidence snapshot | Fill |
|------|------|-------------------|------|
| `1.1` Product Vision | Foundation | source ready, mapped cards complete, latest grades `A-/B+`, no open questions | `100` |
| `1.2` Product Strategy | Foundation | source ready, no mapped cards yet | `50` |
| `2.2` Noun Vocabulary | Foundation | attributed source file exists, no inventory/manifest proof yet | `25` |
| `3.2` Emotional / Aesthetic Goals | Foundation | no source, no cards | `0` |
| `3.5` Anti-Patterns | Foundation | mapped cards exist, one card graded below `B+` | `75` |

Foundation mean:

```text
(100 + 50 + 25 + 0 + 75) / 5 = 50
```

Result:

- Foundation is `50%`
- Core is locked because Foundation `< 80`
- The mix feels sensible for an early, uneven Factory library: some real progress, but not
  enough trustworthy Foundation coverage to unlock Core work

### Review B: Short-Order-Cook / Low / Low

Current wizard engine shape:

- Foundation: `3`
- Core: `1`
- Amplifier: `5`
- Deprioritized: `4` (not rendered in the active Phase 2 scoreboard)

Example evidence:

| Area | Tier | Evidence snapshot | Fill |
|------|------|-------------------|------|
| `1.1` Product Vision | Foundation | mapped cards complete and graded `A-/A`, no open questions | `100` |
| `2.2` Noun Vocabulary | Foundation | mapped cards complete and graded `B+`, no open questions | `100` |
| `4.1` Design System | Foundation | mapped cards exist, one unresolved design question remains | `75` |
| `4.3` Prototypes / Mockups | Core | source ready, no mapped cards yet | `50` |

Foundation mean:

```text
(100 + 100 + 75) / 3 = 91.67
```

Result:

- Foundation is provisionally cleared
- Core is unlocked because Foundation `>= 80`
- Foundation is not fully cleared because `4.1` is still below `100`
- This matches the intended behavior for a simpler product: the team can move forward, but
  Raven still points at the remaining Foundation gap explicitly

## Summary Decisions

The scoreboard is conservative by design:

- source files alone do not prove `50`
- cards alone do not prove `100`
- unresolved questions cap an area at `75`
- full Foundation clearance requires every active Foundation area at `100`

That conservatism is the feature. The scoreboard is a shared trust artifact, so it should
fail closed rather than overstate readiness.
