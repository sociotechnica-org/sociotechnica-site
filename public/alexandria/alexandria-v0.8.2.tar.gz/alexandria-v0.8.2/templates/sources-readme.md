# Sources

Snapshot documents that informed the creation of Alexandria cards. These are **provenance, not product truth** — the atomic cards in `/product/`, `/rationale/`, and `/experience/` are the canonical source of truth.

## Conventions

### What goes here

- Design documents (GDDs, briefs, specs) that seeded multiple cards
- Strategic memos or research notes that informed rationale cards
- External reference material archived for durability

### What does NOT go here

- Atomic cards (those go in their typed folders)
- Code documentation (that goes in CLAUDE.md or CONVENTIONS.md)

### Rules

1. **Sources are frozen.** Once archived here, they are never edited.
2. **Cards never link to sources.** The knowledge graph flows between cards.
3. **Sources link to cards.** Each source should list which cards it informed.
4. **Agents do not search sources.** Agents work with cards, not sources.
5. **Include a snapshot date.** Note when the document was captured.

### Naming

Use the document's natural name, no type prefix:

```
sources/
├── README.md
├── product-spec-v1.md
├── design-review-2025-03.md
└── user-research-findings.md
```
