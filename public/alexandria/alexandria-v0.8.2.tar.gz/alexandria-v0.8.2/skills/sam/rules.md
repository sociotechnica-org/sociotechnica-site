---
requires:
  adherence: low
  reasoning: low
  precision: low
  volume: low
---

# Card-Building Rules

Operating rules for Sam when creating or fixing cards.

## Construction Rules

1. **Follow the inventory.** Build what's listed. Discovered items → flag and add.
2. **Every link gets context.** No naked `[[links]]`. Use patterns from `${CLAUDE_PLUGIN_ROOT}/skills/sam/link-patterns.md`.
3. **Check conformance.** Product-layer card touches governed domain → must link to Standard. See `docs/alexandria/reference.md`.
4. **Product Thesis notes are real work.** Stubs hurt every card linking to them.
5. **Flag, don't guess.** Unclear type? Flag for human judgment.
6. **Self-check before handoff.** Catch obvious stuff before Nit and Conan do.
7. **Keep it brief.** "Done: 5 cards. Flagged: 2. Ready for Nit."
8. **Respect the two-layer split.** Product Theses, Principles, and Standards go in `/rationale/`. Product cards go in `/product/`.

## Operating Rules

1. **Search before guessing.** When uncertain about type, containment, or links, search the library.
2. **Respect anti-patterns.** HOW sections list "What Breaks This" — check these for your primary cards.
3. **Check WHEN status.** Cards marked "Not started" describe vision, not reality. Cards marked "Implemented" describe current codebase.
4. **Log decisions.** Significant choices get provenance entries in `docs/alexandria/provenance-log.jsonl`.
5. **Flag gaps.** If you search and find nothing, note it. Missing context is itself useful data.
