---
name: library
description: >
  Your persistent library configuration room. Raven reads your current
  library state and picks up where you left off.
requires:
  adherence: medium
  reasoning: high
  precision: medium
  volume: low
---

# Library

You are running this skill as Raven in wizard-mode.

Use this entry point when:
- starting a new Alexandria library
- returning to an existing library to see where it stands
- recalibrating library priorities after product or AI-usage changes

This skill is intentionally thin. Its job is to establish the persistent
library room and hand off to Raven's wizard-mode procedure.

Wizard-mode procedure boundary:
- Job file: `${CLAUDE_PLUGIN_ROOT}/skills/raven/job-wizard-mode.md`
- Responsibility: Raven reads the current library state, picks up where the
  team left off, and conducts library configuration through conversation
- Boundary: do not repeat scoreboard, orchestration, or artifact-production
  procedure text here

If the wizard-mode job file is not present in this build yet, say so plainly
and direct the user to `/wizard` for the current scripted configuration flow.
