# Assessment Generation

Reference material for generating the assessment document with impact statements and
solicitation prompts. Loaded on demand during Step 6 of the wizard flow.

---

## 6a: Load Gap Analysis

If running independently (not immediately after gap analysis), load the gap analysis:

```
Read docs/alexandria/wizard-config.json from the target project.
Verify it contains a gap_analysis section. If not, tell the user to run
the gap analysis first.
```

Extract: mode, novelty, complexity, gaps array, sequence, and summary.

---

## 6b: Generate Impact Statements

For each gap (where action != "none"), generate a mode-sensitive impact statement.

Read the area's `when_missing` text from
`${CLAUDE_PLUGIN_ROOT}/docs/wizard/wizard-engine.yaml` (the catalog section) and the
mode narrative from the `mode_narratives` section.

Use these templates based on the area's tier:

**Foundation gap:**
> Without [area name], [when_missing text]. At [mode label] mode, this means
> [mode-specific consequence derived from the mode narrative risk]. This is a
> Foundation gap — other knowledge areas depend on it for coherence. Seed this first.

**Core gap:**
> [When_missing text]. For your [novelty]-novelty, [complexity]-complexity product
> at [mode label] mode, this is a primary value driver — [explain why this area is
> Core at this configuration, referencing the sensitivity that elevated it].

**Amplifier gap:**
> [When_missing text]. This area multiplies the effectiveness of your Foundation and
> Core knowledge. With [area name] in place, [describe the specific amplification
> effect for this area].

**Deprioritized gap:**
> [When_missing text]. At your configuration ([novelty] novelty, [complexity]
> complexity), this is lower priority because [explain why the sensitivity profiles
> place it here]. Seed this after higher-priority areas are in place.

The impact statements should be specific to the team's configuration, not generic.
Combine the `when_missing` text with the mode narrative to explain the concrete risk.

---

## 6c: Select Solicitation Prompts

For each gap, select the appropriate solicitation prompt from
`${CLAUDE_PLUGIN_ROOT}/docs/wizard/phase-6-intake-engine.md` (the "Solicitation
Prompt Library" section).

Each area has:
- A **base solicitation prompt** (always present)
- **Mode variants** (some areas have variants for Short-Order Cook, Pair Programmer,
  and/or Factory modes)
- **"What good looks like"** benchmark
- **"Common pitfall"** warning

**Mode variant selection rules:**
- If the area has a variant that matches the user's mode, use it instead of the base
  prompt
- Some variants cover multiple modes (e.g., "Short-Order Cook / Pair Programmer") —
  use these when the user's mode is listed
- If no variant matches, use the base prompt
- Area 1.2 (Product Strategy) has a "Thesis nudge" — include it as additional guidance

---

## Step 6 runs automatically

After presenting the gap analysis summary (whether there are gaps or not), proceed
automatically to assessment generation. Do not ask the user whether to generate the
assessment — it is a standard output artifact of every wizard run.
