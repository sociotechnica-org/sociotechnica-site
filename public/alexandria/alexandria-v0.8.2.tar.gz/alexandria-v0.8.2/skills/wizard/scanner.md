---
name: scanner
description: >
  Scan a codebase to discover product-level entities and domain structure.
  Tier 1: uses only directory and file names (no file content reading).
  Tier 2: reads file contents for Tier 1 candidates to extract fields, routes, and relationships.
  Called by the wizard when the user has code to scan.
requires:
  adherence: low
  reasoning: low
  precision: low
  volume: low
---

# Codebase Scanner

Discover product-level entities and domain structure by analyzing a codebase. Tier 1 uses
only the file tree (directory and file names). Tier 2 optionally reads file contents for
Tier 1 candidates to extract fields, routes, relationships, and dead code signals.

## When to Use

- When setting up an Alexandria and the product already has code
- When the wizard needs candidate nouns to seed the knowledge graph
- When you want a quick structural overview of a codebase's domain model

## Tier 1: File Tree Investigation

Tier 1 uses ONLY the file tree — it never reads file contents.

### Step 1: Read the File Tree

Use Glob to get the directory structure of the target project. Scan in two passes:

**Pass 1 — Discover the project layout:**

Glob for top-level directories to understand the project shape:
- `*/` — top-level directories
- `src/*/`, `app/*/`, `lib/*/` — source root directories (if present)

**Pass 2 — Scan pattern directories:**

Glob for files inside directories that typically contain domain entities. Focus on these
framework-agnostic patterns:

| Directory Pattern | What It Suggests | Glob |
|-------------------|------------------|------|
| `**/models/**/*` | Entity definitions | `**/models/**/*.{py,rb,ts,js,go,rs,java,kt,cs,ex,scala}` |
| `**/schemas/**/*` | Data shapes / entities | `**/schemas/**/*.{py,rb,ts,js,go,rs,java,kt,cs,ex,scala,graphql,prisma}` |
| `**/entities/**/*` | Domain entities (DDD style) | `**/entities/**/*` |
| `**/domains/**/*` | Domain modules | `**/domains/**/*` |
| `**/routes/**/*`, `**/api/**/*` | API resources | `**/routes/**/*`, `**/api/**/*` |
| `**/controllers/**/*` | Request handlers / resources | `**/controllers/**/*` |
| `**/views/**/*`, `**/templates/**/*` | Server-rendered views | `**/views/**/*`, `**/templates/**/*` |
| `**/components/**/*` | UI components | `**/components/**/*` |
| `**/pages/**/*` | Page-level UI features | `**/pages/**/*` |
| `**/features/**/*` | Feature modules | `**/features/**/*` |
| `**/modules/**/*` | Domain modules | `**/modules/**/*` |
| `**/apps/**/*` | Sub-applications | `**/apps/**/*` |
| `**/services/**/*` | Service layer | `**/services/**/*` |

Do NOT read file contents at any point. Only use directory names and file names.

### Step 2: Extract Candidate Nouns

For each file found in pattern directories, extract a candidate noun:

**Extraction rules:**

1. **Strip the file extension** — `User.py` becomes `User`, `subscription.rb` becomes `subscription`
2. **Strip common suffixes** — `UserModel`, `UserController`, `UserService`, `UserSchema`, `UserEntity` all become `User`
3. **Convert to PascalCase** — `user_profile` becomes `UserProfile`, `order-item` becomes `OrderItem`
4. **Handle index/init files** — `models/billing/index.ts` extracts `Billing` from the parent directory, not `index`
5. **Handle plural directories** — If a directory is plural (e.g., `users/`) and contains individual files, the directory name suggests a collection; extract singular forms from the file names within

**Source classification:**

- Files in `models/`, `schemas/`, `entities/` directories -> entity candidates
- Files in `routes/`, `api/`, `controllers/` directories -> feature/resource candidates
- Files in `components/`, `pages/`, `views/` directories -> UI feature candidates
- Top-level domain directories (`billing/`, `auth/`, `notifications/`) -> domain group candidates
- Files in `features/`, `modules/`, `domains/`, `apps/` directories -> domain module candidates
- Files in `services/` directories -> service/capability candidates

### Step 3: Filter Infrastructure Names

Remove candidates that match infrastructure or utility patterns. These are implementation
details, not product-level nouns:

**Always filter out these directory/file names:**

- Build/tooling: `utils`, `helpers`, `lib`, `common`, `shared`, `internal`, `pkg`
- Configuration: `config`, `configuration`, `settings`, `env`, `constants`
- Infrastructure: `middleware`, `interceptors`, `filters`, `guards`, `pipes`, `decorators`
- Base classes: `base`, `abstract`, `generic`, `core`, `foundation`
- Testing: `test`, `tests`, `spec`, `specs`, `__tests__`, `fixtures`, `mocks`, `stubs`, `factories`
- Database: `migrations`, `seeds`, `seeders`, `migrate`
- Dependencies: `vendor`, `node_modules`, `__pycache__`, `.git`, `dist`, `build`, `target`, `.next`, `.nuxt`
- Scripts/tooling: `scripts`, `tools`, `tasks`, `bin`, `cli`
- Documentation: `docs`, `documentation`, `examples`, `samples`
- Type plumbing: `types`, `interfaces`, `dto`, `dtos`, `mappers`, `serializers`, `deserializers`, `converters`, `adapters`
- Generic: `index`, `main`, `app`, `application`, `server`, `client`, `handler`, `manager`, `processor`, `worker`, `job`, `task`, `queue`, `cache`, `logger`, `error`, `exception`, `response`, `request`

**Also filter:**
- Files starting with `.` (dotfiles)
- Files starting with `_` (private/internal by convention)
- Files that are ALL_CAPS (typically constants: `CONSTANTS.py`, `DEFAULTS.ts`)
- Files that match test patterns: `*_test.*`, `*_spec.*`, `*.test.*`, `*.spec.*`

When in doubt about whether something is infrastructure or product-level, keep it with
`confidence: low` rather than filtering it out. Let the human decide.

### Step 4: Group by Domain

Determine domain groupings using the project's own organizational structure:

**Strategy A — Domain-based organization (preferred):**

If the project uses domain directories (`features/billing/`, `modules/auth/`,
`domains/notifications/`, `apps/storefront/`), use those as domain groups directly.
Each domain directory becomes a group, and entities within it belong to that group.

**Strategy B — Structural inference:**

If the project uses flat organization (e.g., `models/user.py`, `models/subscription.py`,
`models/invoice.py`), infer groups by:

1. **Shared prefixes** — `billing_plan`, `billing_invoice`, `billing_subscription` suggest a "Billing" domain
2. **Co-location in subdirectories** — `models/billing/plan.py` and `models/billing/invoice.py` suggest "Billing"
3. **Common domain clusters** — Group by well-known product domains:
   - Auth/Identity: user, account, session, role, permission, team, organization
   - Billing/Payments: subscription, plan, invoice, payment, price, coupon, charge
   - Content: post, article, comment, page, document, media, file, asset
   - Communication: notification, message, email, chat, conversation, thread
   - Commerce: product, order, cart, catalog, inventory, shipping, fulfillment
   - Social: profile, follow, connection, feed, activity, reaction

4. **Fallback** — If no clear grouping emerges, present as "Ungrouped" with a note:
   "Flat project structure — domain grouping is speculative. Review and adjust."

### Step 5: Assign Confidence Levels

For each candidate noun, assess confidence based on the breadth of evidence:

| Confidence | Criteria |
|-----------|---------|
| **high** | Entity appears in 3+ layers: model/schema + routes/API + UI (components/pages). This is almost certainly a core product entity. |
| **medium** | Entity appears in 2 layers: model + routes, OR model + UI, OR routes + UI. Likely a real entity but may be secondary. |
| **low** | Entity appears in only 1 layer: model only, route only, UI only, or directory name only. Could be real but needs validation. |

**Counting layers:**
- Model layer: `models/`, `schemas/`, `entities/`
- API layer: `routes/`, `api/`, `controllers/`, `services/`
- UI layer: `components/`, `pages/`, `views/`, `templates/`
- Domain layer: `features/`, `modules/`, `domains/`, `apps/`

A candidate that appears in `models/user.py` AND `routes/users.py` AND `components/UserProfile.tsx`
has evidence in 3 layers = high confidence.

A candidate that only appears in `models/audit_log.py` has evidence in 1 layer = low confidence.

### Step 6: Classify Type Hints

Assign a type hint based on where the entity was found:

| Type Hint | When to Assign |
|-----------|---------------|
| `entity` | Found in models/, schemas/, or entities/ — this is a data entity |
| `feature` | Found in features/, modules/, routes/, controllers/, or api/ without a model — this is a feature/capability |
| `page` | Found only in pages/ or views/ — this is a UI surface |
| `domain` | A domain-level grouping directory (features/billing/, modules/auth/) — represents a bounded context |
| `service` | Found only in services/ — this is a backend capability |

If an entity appears in multiple locations, prefer `entity` > `feature` > `service` > `page`.
The `domain` type is only for the group itself, not for entities within it.

### Step 7: Present Results

Format the output as a structured summary.

**If only Tier 1 was run:**

```
## Codebase Discovery — Tier 1 (File Tree)

Scanned [N] directories, [M] files.
Found [X] candidate product entities in [Y] domain groups.

### [Domain Group 1]
| Entity | Type | Confidence | Evidence |
|--------|------|-----------|----------|
| [name] | [entity/feature/page/domain/service] | [high/medium/low] | [comma-separated file paths] |

### [Domain Group 2]
| Entity | Type | Confidence | Evidence |
|--------|------|-----------|----------|
| [name] | [entity/feature/page/domain/service] | [high/medium/low] | [comma-separated file paths] |

### Ungrouped (if any)
| Entity | Type | Confidence | Evidence |
|--------|------|-----------|----------|
| [name] | [entity/feature/page/domain/service] | [high/medium/low] | [comma-separated file paths] |

---

**Summary:**
- High confidence: [N] entities (appear across 3+ layers)
- Medium confidence: [N] entities (appear across 2 layers)
- Low confidence: [N] entities (appear in 1 layer only)

**Filtered out:** [N] infrastructure/utility names excluded (e.g., [list a few examples])

**Note:** This is Tier 1 (file tree only). Confidence levels are based on directory
structure alone. A Tier 2 scan (file contents) would refine these proposals by examining
actual class definitions, schema fields, and route handlers.
```

**If Tier 2 was also run, enrich the output:**

```
## Codebase Discovery — Tier 1 + Tier 2

Scanned [N] directories, [M] files. Read [K] files for Tier 2 evidence.
Found [X] candidate product entities in [Y] domain groups.

### [Domain Group]
| Entity | Type | Confidence | Fields | Routes | UI | Dead Code? |
|--------|------|-----------|--------|--------|----|------------|
| [name] | [type] | [high/medium/low] | [N fields] | [CRUD coverage] | [N components] | [yes/no] |

#### [Entity Name] — Detail
- **Fields:** id, name, email, status (active/archived), created_at
- **Routes:** GET /users, POST /users, GET /users/:id, PUT /users/:id (CRUD)
- **UI components:** UserProfile, UserList, UserSettings
- **Relationships:** has_many Orders, belongs_to Organization
- **Dead code signals:** none

#### [Entity Name] — Detail (dead code flagged)
- **Fields:** id, code, amount, expires_at
- **Routes:** none found
- **UI components:** none found
- **Relationships:** belongs_to User
- **Dead code signals:** Model exists but no routes or UI reference it — possibly abandoned

---

**Summary:**
- High confidence: [N] entities (3+ evidence layers)
- Medium confidence: [N] entities (2 evidence layers)
- Low confidence: [N] entities (1 evidence layer)
- Dead code signals: [N] entities flagged for review

**Filtered out:** [N] infrastructure/utility names excluded
**Tier 2 files read:** [K] files ([token estimate] tokens)
```

Only show the detail blocks for entities where Tier 2 found meaningful enrichment (fields,
routes, or dead code signals). Low-confidence entities with no Tier 2 enrichment can stay
in the summary table without a detail block.

**Presentation guidelines:**

- Sort domain groups alphabetically
- Within each group, sort by confidence (high first), then alphabetically
- Show at most 5 evidence paths per entity; if more exist, show 5 and append "(+N more)"
- Use relative paths from the project root
- If the project is very large (500+ candidate files), summarize by domain group counts
  and only show high/medium confidence entities in the table. List low-confidence entities
  as a bullet list below.

## Tier 2: Schema + Route Scanning

Tier 2 deepens Tier 1 proposals by reading actual file contents. It ONLY reads files
associated with Tier 1 candidates — it does not scan the entire codebase.

### When to run Tier 2

Run Tier 2 after Tier 1 completes. Tier 2 is recommended when:
- Tier 1 found candidates with low confidence (only directory-level evidence)
- The user wants richer evidence before confirming entities
- The codebase is large enough that domain grouping needs refinement

Tier 2 is optional — Tier 1 proposals are sufficient for the noun proposal dialogue.

### Step T2-1: Read model/schema files

For each Tier 1 entity candidate found in a models/, schemas/, or entities/ directory:
1. Read the file content
2. Extract field names and types
3. Identify relationships: foreign keys, references to other entities, belongs_to/has_many
4. Note any status/state fields that suggest lifecycle (e.g., status, state, active, archived)

Record: entity name → fields list, relationships list, lifecycle indicators

### Step T2-2: Read route/API files

For each Tier 1 candidate found in routes/, api/, or controllers/ directories:
1. Read the file content
2. Extract route patterns and HTTP methods (GET /users, POST /billing/subscribe, etc.)
3. Group routes by resource (all /users/* routes → User entity)
4. Note CRUD completeness: does this entity have create, read, update, delete?

Record: entity name → routes list, CRUD coverage

### Step T2-3: Read component/page files

For each Tier 1 candidate found in components/, pages/, views/, or templates/ directories:
1. Read the file (or at minimum the imports and export name)
2. Extract component names and props
3. Note which entities are referenced in the UI layer
4. Identify page-level components vs. reusable components

Record: entity name → UI components list, page presence

### Step T2-4: Detect dead code signals

Cross-reference Tier 1 + Tier 2 evidence to flag potential dead code:
- **Model without routes:** Entity has a model/schema but no API endpoints → possibly abandoned
- **Routes without UI:** API endpoints exist but no UI components reference them → possibly backend-only or abandoned
- **Model without any references:** Schema exists but nothing references it → likely dead

Flag these as `dead_code_signal: true` on the proposal. Do NOT remove them from proposals — present them to the user with the flag so they can decide.

### Step T2-5: Enrich proposals

Update each Tier 1 proposal with Tier 2 evidence:
- Add `fields` array (from model/schema reading)
- Add `routes` array (from route/API reading)
- Add `ui_components` array (from component/page reading)
- Add `relationships` array (foreign keys, references)
- Upgrade confidence: low → medium if 2+ evidence layers found, medium → high if 3+ layers
- Add `dead_code_signal` boolean
- Add `crud_coverage` summary (e.g., "CR" for create+read only, "CRUD" for full)

### Token cost control

Tier 2 reads file CONTENTS, which is more expensive than Tier 1. Control costs:
- Only read files associated with Tier 1 candidates (not all files)
- For large files (>200 lines), read only the first 50 lines (usually enough for models/schemas) and the export/class declaration
- Skip test files, migration files, and generated files
- If more than 50 files would need reading, ask the user: "Tier 2 scanning would read [N] files. Want to proceed, or focus on [top 10 by confidence]?"

## Key Constraints

1. **Tier 1: file tree only** — Tier 1 never reads file contents. Only use directory names and file names.
2. **Tier 2: candidate files only** — Tier 2 reads file contents ONLY for Tier 1 candidates. Never scan the entire codebase.
3. **Dead code signals are flags, not removals** — Tier 2 flags potential dead code but never removes candidates. The user decides.
4. **Token cost control** — Tier 2 limits file reading: skip tests/migrations/generated files, truncate large files, prompt user if >50 files.
5. **Product-level nouns** — Output should be things a product person would recognize, not implementation details like "BaseRepository" or "AbstractFactory."
6. **Framework-agnostic** — These heuristics work across Python, JavaScript/TypeScript, Ruby, Go, Rust, Java, Kotlin, C#, Elixir, and Scala projects. Do not assume any specific framework.
7. **Filter aggressively, but keep borderline cases** — It is better to include a low-confidence candidate than to miss a real product entity. The human will review.
8. **No hallucination** — Every candidate must have at least one real file path as evidence. Never invent entities that do not appear in the file tree.
