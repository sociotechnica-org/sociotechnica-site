---
requires:
  adherence: low
  reasoning: low
  precision: low
  volume: low
---

# Provenance Log Schema

Append-only log tracking context assembly and decision provenance.

**File:** `docs/alexandria/provenance-log.jsonl` (one JSON object per line)

---

## Entry Schema

```json
{
  "timestamp": "2026-02-11T14:30:00Z",
  "session_id": "uuid-v4",
  "agent": "conan | sam | builder",

  "task": {
    "description": "Implement Notification Engine toggle in Settings Panel",
    "target_type": "Component",
    "task_type": "feature"
  },

  "assembly": {
    "profile_used": "Component",
    "seeds": ["Component - Dashboard Widget", "Section - Settings Panel"],
    "candidates_found": 12,
    "retrieved": [
      "Component - Dashboard Widget",
      "Section - Settings Panel",
      "Standard - Widget Slot Behaviors",
      "System - Notification Engine"
    ],
    "delivered": {
      "primary": ["Component - Dashboard Widget", "Section - Settings Panel"],
      "supporting": ["Standard - Widget Slot Behaviors", "System - Notification Engine"]
    },
    "gaps": [
      {
        "dimension": "HOW",
        "topic": "Notification Engine state transitions",
        "searched": true,
        "found": false
      }
    ]
  },

  "queries": [
    {
      "round": 1,
      "technique": "Grep",
      "terms": "Notification Engine toggle states",
      "path": "docs/alexandria/product/systems/",
      "result_count": 0,
      "action": "reported_gap"
    }
  ],

  "decisions": [
    {
      "id": "decision-001",
      "description": "Used binary toggle instead of multi-state selector",
      "confidence": "medium",
      "signals": {
        "reversibility": "proceed",
        "coverage": "search",
        "precedent": "proceed",
        "blast_radius": "proceed",
        "domain": "proceed"
      },
      "cards_used": ["Component - Dashboard Widget"],
      "default_used": true,
      "outcome": "pending"
    }
  ]
}
```

---

## Outcome Updates

After task completion, append an outcome entry:

```json
{
  "timestamp": "2026-02-11T16:00:00Z",
  "type": "outcome_update",
  "session_id": "uuid-v4",
  "decision_id": "decision-001",
  "outcome": "success | failure | partial",
  "notes": "PR approved without changes to toggle implementation"
}
```

---

## Field Reference

### Top-level fields

| Field        | Type     | Required | Description                           |
| ------------ | -------- | -------- | ------------------------------------- |
| `timestamp`  | ISO-8601 | yes      | When the entry was created            |
| `session_id` | UUID v4  | yes      | Groups entries from same task session |
| `agent`      | string   | yes      | Which agent created this entry        |

### task object

| Field         | Type   | Required | Description                                     |
| ------------- | ------ | -------- | ----------------------------------------------- |
| `description` | string | yes      | What needs to be built/modified                 |
| `target_type` | string | yes      | Card type being built (System, Component, etc.) |
| `task_type`   | string | yes      | feature, bug, refactor, new, architecture       |

### assembly object (Conan entries only)

| Field                  | Type     | Required | Description                         |
| ---------------------- | -------- | -------- | ----------------------------------- |
| `profile_used`         | string   | yes      | Which retrieval profile was applied |
| `seeds`                | string[] | yes      | Initial cards found via search      |
| `candidates_found`     | number   | no       | Total cards considered              |
| `retrieved`            | string[] | yes      | All cards read during assembly      |
| `delivered.primary`    | string[] | yes      | Cards included in full              |
| `delivered.supporting` | string[] | yes      | Cards included as summaries         |
| `gaps`                 | object[] | no       | Identified context gaps             |

### queries array (consuming agent entries — builder agents or Sam)

Tracks library searches triggered by the 5-signal decision matrix. Builder agents log queries about code-level product decisions. Sam logs queries about card classification and content decisions.

| Field          | Type   | Required | Description                |
| -------------- | ------ | -------- | -------------------------- |
| `round`        | number | yes      | Query round (1-3)          |
| `technique`    | string | yes      | Grep, Glob, or Read        |
| `terms`        | string | yes      | Search terms used          |
| `path`         | string | no       | Search scope               |
| `result_count` | number | yes      | Number of results          |
| `action`       | string | yes      | What was done with results |

### decisions array (consuming agent entries — builder agents or Sam)

Tracks product-domain decisions informed by library context. Builder agents log code-level decisions (schema choices, API contracts, component architecture). Sam logs card-level decisions (type classification, link choices, content scope). Both use the same 5-signal evaluation.

| Field          | Type     | Required | Description                         |
| -------------- | -------- | -------- | ----------------------------------- |
| `id`           | string   | yes      | Unique decision identifier          |
| `description`  | string   | yes      | What was decided                    |
| `confidence`   | string   | yes      | high, medium, or low                |
| `signals`      | object   | yes      | 5-signal evaluation                 |
| `cards_used`   | string[] | yes      | Cards that informed decision        |
| `default_used` | boolean  | no       | Whether default assumption was used |
| `outcome`      | string   | yes      | pending, success, failure, partial  |

---

## Weekly Review Queries

Analyze `provenance-log.jsonl` weekly to answer:

1. **Which cards correlate with success?** Cards in successful sessions → validate quality. Cards in failures → review accuracy.
2. **Which cards are retrieved but unused?** High retrieval + low decision reference → over-weighted or poorly structured.
3. **What gaps repeat?** Same topic in multiple gap reports → priority for card creation.
4. **Where does confidence fail?** Medium confidence + failure → calibration needed. High confidence + failure → serious review.
5. **Which profiles under/over-retrieve?** Count cards per profile. Profiles with consistently large candidate sets may need narrowing.
