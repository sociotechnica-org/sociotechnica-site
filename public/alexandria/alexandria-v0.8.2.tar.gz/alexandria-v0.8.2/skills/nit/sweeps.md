---
requires:
  adherence: low
  reasoning: low
  precision: low
  volume: low
---

# Nit Sweep Definitions

Six sweep levels from narrowest to widest scope. When invoked, identify the appropriate
sweeps from the trigger context, or run all six if asked for a full sweep.

---

## Sweep 1: Line (within a card)

Single-line hygiene checks applied to every card in scope.

- **Markdown hygiene**: Heading levels follow H1 > H2 > H3 (no skips). No trailing
  whitespace on non-empty lines. No tab indentation (spaces only). Fenced code blocks
  have a language tag.
- **Terminology consistency**: Key terms match the project's noun vocabulary. Grep for
  known variant spellings (e.g., "wiki-link" vs "wikilink"). Flag inconsistencies.
- **Wikilink syntax**: Every `[[...]]` follows `[[Type - Name]]` format. No bare names
  without type prefix. No broken syntax (unclosed brackets, nested brackets).
- **Naked links**: A line containing `[[...]]` must have surrounding text explaining the
  relationship. Naked wikilink on its own line with no context = warning.

**Not your job:** Whether the link *target* exists (that's Sweep 3) or whether the
relationship description is *meaningful* (that's Conan).

---

## Sweep 2: Card (single card structure)

Per-card structural checks.

- **Five H2 sections**: Every card must have `## WHAT`, `## WHERE`, `## WHY`, `## WHEN`,
  `## HOW`. Missing section = critical.
- **Naming convention**: Filename must match `Type - Name.md`. Regex:
  `^[A-Z][a-zA-Z ]+ - .+\.md$`. Non-matching = critical.
- **Folder placement**: Card is in the correct layer folder per type. Rationale types
  (Product Thesis, Principle, Standard) in `rationale/`. Product types in `product/` or
  subfolder. Experience types in `experience/`. Temporal types in `temporal/`. Wrong
  folder = critical.
- **Stub sections**: Any H2 section containing only whitespace, "TBD", "TODO", or fewer
  than 10 words after the heading = warning.
- **Word count**: Cards over 700 words flagged for atomicity review = note.
- **Link count**: WHERE section should contain 3+ wikilinks. Fewer than 3 = note.

**Not your job:** Whether the card's type classification is correct (Conan's Job 6),
whether content is substantive (Conan's Job 2), or whether the card should be split
(Conan's atomicity judgment).

---

## Sweep 3: Graph (card-to-card)

Cross-card relationship integrity.

- **Broken wikilinks**: Every `[[Type - Name]]` reference must resolve to an actual file.
  Glob for the filename. Missing file = critical.
- **Orphan cards**: Cards with zero incoming wikilinks from other cards. Grep the library
  for `[[Card Name]]`. Zero hits = warning (product/experience layer) or critical
  (rationale layer — rationale cards exist to be referenced).
- **Bidirectional link gaps**: If card A links to card B, does card B link back? Grep both
  directions. Systematic one-way linking = note. (Some asymmetry is expected.)
- **Duplicate detection**: Multiple cards with the same concept name but different type
  prefixes (e.g., `Component - Foo.md` and `System - Foo.md`). Flag for Conan to resolve.
  Duplicate = warning.

---

## Sweep 4: Layer (rationale / product / experience / temporal)

Layer-level population and cross-layer integrity.

- **Minimum population**: Each active layer should have a minimum number of cards. An
  empty layer that should be populated per the wizard configuration = warning.
- **Cross-layer link presence**: Product-layer cards should link to at least one rationale
  card (WHY chain). Experience-layer cards should link to product-layer cards. No
  cross-layer links = warning.
- **Inventory reconciliation**: If an inventory manifest exists, compare file system to
  manifest. Cards in manifest but not on disk = warning. Cards on disk but not in
  manifest = note. This is a file-exists check only — not a content check.
- **Manifest fidelity**: If an inventory manifest exists, verify its claims against actual
  card content. Three sub-checks:
  - **Cross-reference completeness**: For each card listed in the manifest's cross-references
    table, grep the card's WHERE section for the dependency wikilinks claimed. Dependency
    declared in the card but missing from the manifest table = warning. Dependency in the
    manifest table but absent from the card = warning.
  - **Conformance map accuracy**: For each card listed in the manifest's conformance map,
    verify the card's WHERE section contains a `Conforms to:` link matching the claimed
    standard. Mismatch = warning.
  - **Enumeration decision drift**: For each enumeration decision, verify the decision
    matches reality. If the manifest says "5 separate Capability cards," count the actual
    Capability cards on disk that match. Count mismatch = warning.

---

## Sweep 5: Library (whole library)

Library-wide metrics and health indicators.

- **Coverage metrics**: Total cards, cards per type, cards per layer. Report as a table.
- **Type distribution**: Flag types with zero cards that the wizard configuration says
  should be present.
- **Feedback queue schema validation**: If `feedback-queue.jsonl` exists, verify each
  entry matches the expected schema fields. Malformed entries = warning.
- **Terminology sweep**: Grep for known terminology variants across all cards. Report
  inconsistency clusters.
- **Link density**: Average incoming + outgoing links per card. Cards with 0 outgoing
  links = note.

---

## Sweep 6: Cross-System (library + agents + skills + wizard + templates)

Full system integrity across all repo components.

- **Path resolution**: Skill files and agent definitions that reference other files by
  path — does the target exist? Missing = warning.
- **Plan status verification**: Plan steps marked `[x]` that claim to produce a file —
  does that file exist? Missing output = warning. Steps marked `[ ]` whose output
  already exists = note.
- **Wizard arithmetic**: Pool sizes must total correctly (mode-specific counts). Count
  assignments vs. expected per configuration table. Mismatch = critical.
- **Design doc counts**: Documents that state specific counts ("22 knowledge areas",
  "16 card types") — verify against reality. Mismatch = warning.
- **Grade-evidence reconciliation**: After Conan grades, verify grades match countable
  mechanical evidence:
  - WHERE link count: A grade requires 3+ contextualized wikilinks. Count them.
  - Missing dimensions: A card with a missing H2 cannot score above F on that dimension.
  - HOW example count: A grade requires 2+ examples and 1+ anti-example.
  - Word count vs. atomicity flag: Cards over 700 words should have an atomicity note.
  - Discrepancy between grade and evidence = note.
- **Briefing compliance**: After Bridget assembles, verify:
  - Mandatory categories from retrieval profile present in briefing?
  - Card budget met (not exceeded)?
  - Provenance logged?
  - All referenced cards exist?
  - Compliance failure = warning.
- **Internal consistency**: When a document contains both prose descriptions and structured
  data (YAML, pseudocode, tables, dependency graphs) for the same concept, verify they
  agree. Common patterns to check:
  - A YAML/JSON definition that lists items (phases, paths, areas) must match the prose
    description of those same items. Different counts or missing entries = warning.
  - A dependency graph that annotates edges ("requires X", "can be incremental") must
    not contradict itself. Mutually exclusive annotations on the same node = warning.
  - A table that assigns values (paths to personas, phases to paths, tiers to areas)
    must match every prose reference to those same assignments. Mismatch = warning.
  - Acceptance criteria that reference a capability must correspond to a design section
    that specifies that capability. Orphaned criteria = note.
- **Regression detection** (PR context):
  - New broken links introduced by the change = critical.
  - New orphan cards created = warning.
  - New stub sections introduced = warning.
  - New naming/folder violations = critical.
