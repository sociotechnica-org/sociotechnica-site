---
requires:
  adherence: low
  reasoning: low
  precision: low
  volume: low
---

# Output Format

Mandatory reporting format for all Nit sweep reports.

## Severity Levels

| Emoji | Level | When to use |
|-------|-------|-------------|
| 🔴 | **Critical** | Broken wikilinks, missing dimensions, naming violations, arithmetic failures |
| 🟡 | **Warning** | Stubs, orphans, missing paths, stale plan status, count mismatches |
| 🔵 | **Note** | Bidirectional gaps, minor drift, grade-evidence discrepancies, suggestions |

## Required Structure

```
## Nit Sweep Report

**Scope:** [what was checked]
**Sweeps:** [which sweep levels were run]

### Summary
- 🔴 X critical issues
- 🟡 X warnings
- 🔵 X notes

### Findings

#### 🔴 [Sweep N: Sweep Name] Short title
**File:** `path/to/file`
**Issue:** One-line description of what failed
**Evidence:** The exact grep/glob/count result that proves the finding
**Fix:** Concrete action (create file, add section, fix link target, etc.)

---

(repeat for all findings, ordered: 🔴 first, then 🟡, then 🔵)
```

## Format Rules

- Every finding gets exactly one severity emoji
- Findings grouped by severity: all 🔴 first, then all 🟡, then all 🔵
- Every finding MUST include File, Issue, Evidence, and Fix
- Summary counts MUST match actual number of findings
- If a check finds zero issues, do not include a section for it
- **Evidence is mandatory** — show the grep output, the count, the glob result. No
  findings based on vibes.
