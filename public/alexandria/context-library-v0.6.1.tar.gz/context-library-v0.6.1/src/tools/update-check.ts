/**
 * Check whether a newer Context Library version is available.
 *
 * Output (stdout):
 *   up_to_date
 *   upgrade_available|X.Y.Z
 *   upgrade_available|X.Y.Z|https://download.url/  (when a download URL is available)
 *   check_failed
 *
 * Exit codes:
 *   0 for successful or non-blocking failures
 *   1 when the local VERSION file is missing
 */

import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";
import {
  envValueOrDefault,
  resolvePluginRoot,
  resolveStateDir,
} from "../lib/plugin-paths.js";
import { readContextLibraryVersion } from "../lib/version.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const UP_TO_DATE_TTL_SECONDS = 60 * 60;
const UPGRADE_TTL_SECONDS = 12 * 60 * 60;
// Bun fetch does not expose a socket-level connect timeout, so this guards the
// request until response headers arrive, which is the closest available fit.
const RESPONSE_START_TIMEOUT_MS = 5_000;
const TOTAL_TIMEOUT_MS = 10_000;

type CheckResult = "up_to_date" | "upgrade_available";

interface ParsedVersion {
  major: number;
  minor: number;
  patch: number;
}

interface CacheEntry {
  result: CheckResult;
  remote_version: string;
  timestamp: number;
  local_version: string;
}

interface UpdateCheckConfig {
  versionFile: string;
  cacheDir: string;
  cacheFile: string;
  remoteUrl: string;
}

export interface UpdateCheckRunResult {
  status: "up_to_date" | "upgrade_available" | "check_failed";
  stdout: string;
  exitCode: number;
}

interface UpdateCheckOptions {
  env?: NodeJS.ProcessEnv;
  fetchImpl?: typeof fetch;
  now?: number;
}

function resolveUpdateCheckConfig(
  env: NodeJS.ProcessEnv = process.env,
): UpdateCheckConfig {
  const repoRoot = resolvePluginRoot(env, __dirname);
  const versionFile = join(repoRoot, "VERSION");
  const cacheDir = resolveStateDir(env);

  return {
    versionFile,
    cacheDir,
    cacheFile: join(cacheDir, "update-cache.json"),
    remoteUrl: envValueOrDefault(
      env.CONTEXT_LIBRARY_REMOTE_VERSION_URL,
      "https://sociotechnica.org/alexandria/latest-version.txt",
    ),
  };
}

function parseSemver(version: string): ParsedVersion | null {
  const match = /^v?(\d+)\.(\d+)\.(\d+)$/.exec(version.trim());
  if (!match) {
    return null;
  }

  return {
    major: Number(match[1]),
    minor: Number(match[2]),
    patch: Number(match[3]),
  };
}

function compareSemver(left: ParsedVersion, right: ParsedVersion): number {
  if (left.major !== right.major) {
    return left.major - right.major;
  }
  if (left.minor !== right.minor) {
    return left.minor - right.minor;
  }
  return left.patch - right.patch;
}

function readCache(cacheFile: string): CacheEntry | null {
  if (!existsSync(cacheFile)) {
    return null;
  }

  try {
    const parsed = JSON.parse(
      readFileSync(cacheFile, "utf-8"),
    ) as Partial<CacheEntry>;
    if (
      (parsed.result === "up_to_date" ||
        parsed.result === "upgrade_available") &&
      typeof parsed.remote_version === "string" &&
      (parsed.result !== "upgrade_available" ||
        parsed.remote_version.length > 0) &&
      typeof parsed.local_version === "string" &&
      typeof parsed.timestamp === "number" &&
      Number.isFinite(parsed.timestamp)
    ) {
      return parsed as CacheEntry;
    }
  } catch {
    return null;
  }

  return null;
}

function writeCache(
  cacheDir: string,
  cacheFile: string,
  entry: CacheEntry,
): void {
  mkdirSync(cacheDir, { recursive: true });
  writeFileSync(cacheFile, JSON.stringify(entry, null, 2) + "\n");
}

function deriveDownloadUrl(remoteUrl: string, version: string): string | null {
  const lastSlash = remoteUrl.lastIndexOf("/");
  if (lastSlash < 0) return null;
  const base = remoteUrl.substring(0, lastSlash + 1);
  const vVersion = version.startsWith("v") ? version : `v${version}`;
  return `${base}context-library-${vVersion}.tar.gz`;
}

function toRunResult(
  status: UpdateCheckRunResult["status"],
  exitCode: number,
  remoteVersion?: string,
  downloadUrl?: string,
): UpdateCheckRunResult {
  if (status === "upgrade_available" && remoteVersion) {
    const stdout = downloadUrl
      ? `upgrade_available|${remoteVersion}|${downloadUrl}`
      : `upgrade_available|${remoteVersion}`;
    return { status, stdout, exitCode };
  }

  return {
    status,
    stdout: status,
    exitCode,
  };
}

async function fetchRemoteVersion(
  remoteUrl: string,
  fetchImpl: typeof fetch,
): Promise<string | null> {
  const controller = new AbortController();
  const totalTimeout = setTimeout(() => controller.abort(), TOTAL_TIMEOUT_MS);
  const responseStartTimeout = setTimeout(
    () => controller.abort(),
    RESPONSE_START_TIMEOUT_MS,
  );

  try {
    const response = await fetchImpl(remoteUrl, { signal: controller.signal });
    clearTimeout(responseStartTimeout);

    if (!response.ok) {
      return null;
    }

    const version = (await response.text()).trim();
    return version.length > 0 ? version : null;
  } catch {
    return null;
  } finally {
    clearTimeout(responseStartTimeout);
    clearTimeout(totalTimeout);
  }
}

export async function runUpdateCheck(
  options: UpdateCheckOptions = {},
): Promise<UpdateCheckRunResult> {
  const env = options.env ?? process.env;
  const config = resolveUpdateCheckConfig(env);
  const fetchImpl = options.fetchImpl ?? fetch;
  const now = options.now ?? Math.floor(Date.now() / 1000);

  const localVersion = readContextLibraryVersion(config.versionFile);
  if (!localVersion) {
    return toRunResult("check_failed", 1);
  }

  const parsedLocalVersion = parseSemver(localVersion);
  if (!parsedLocalVersion) {
    return toRunResult("check_failed", 0);
  }

  const cached = readCache(config.cacheFile);
  if (cached && cached.local_version === localVersion) {
    const ageSeconds = now - cached.timestamp;
    if (cached.result === "up_to_date" && ageSeconds < UP_TO_DATE_TTL_SECONDS) {
      return toRunResult("up_to_date", 0);
    }
    if (
      cached.result === "upgrade_available" &&
      ageSeconds < UPGRADE_TTL_SECONDS
    ) {
      const downloadUrl = deriveDownloadUrl(
        config.remoteUrl,
        cached.remote_version,
      );
      return toRunResult(
        "upgrade_available",
        0,
        cached.remote_version,
        downloadUrl ?? undefined,
      );
    }
  }

  const remoteVersion = await fetchRemoteVersion(config.remoteUrl, fetchImpl);
  if (!remoteVersion) {
    return toRunResult("check_failed", 0);
  }

  const parsedRemoteVersion = parseSemver(remoteVersion);
  if (!parsedRemoteVersion) {
    return toRunResult("check_failed", 0);
  }

  const resultEntry: CacheEntry =
    compareSemver(parsedRemoteVersion, parsedLocalVersion) > 0
      ? {
          result: "upgrade_available",
          remote_version: remoteVersion,
          timestamp: now,
          local_version: localVersion,
        }
      : {
          result: "up_to_date",
          remote_version: remoteVersion,
          timestamp: now,
          local_version: localVersion,
        };

  try {
    writeCache(config.cacheDir, config.cacheFile, resultEntry);
  } catch {
    // Update checks should stay non-blocking even if the cache path is unwritable.
  }

  const downloadUrl =
    resultEntry.result === "upgrade_available"
      ? deriveDownloadUrl(config.remoteUrl, resultEntry.remote_version)
      : undefined;
  return toRunResult(
    resultEntry.result,
    0,
    resultEntry.remote_version,
    downloadUrl ?? undefined,
  );
}

async function main(): Promise<void> {
  const result = await runUpdateCheck();
  console.log(result.stdout);
  process.exit(result.exitCode);
}

if (import.meta.main) {
  await main();
}
