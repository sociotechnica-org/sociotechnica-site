/**
 * Context Library graph retrieval CLI.
 *
 * Selects and orders cards for context briefings using the graph parser library.
 * Given seed cards, a retrieval profile, and complexity tier, returns an ordered
 * card list with budget applied and U-shaped attention ordering.
 *
 * Usage:
 *   context-library-retrieve --seeds "System - Foo,Component - Bar" --profile system --complexity medium --library docs/context-library/
 *   context-library-retrieve --seeds "System - Foo" --profile system --complexity simple --library docs/context-library/ --format text
 */

import { existsSync, statSync } from "fs";
import { Library } from "../lib/graph.js";
import { parseArgs } from "../lib/cli.js";

// ── Retrieval profiles ─────────────────────────────────────────────────
// Encoded from skills/context-briefing/retrieval-profiles.md

interface Profile {
  hops: number;
  direction: "outgoing" | "incoming" | "both";
  lateral: "narrow" | "medium" | "broad";
}

const PROFILES: Record<string, Profile> = {
  system: { hops: 3, direction: "both", lateral: "broad" },
  component: { hops: 1, direction: "both", lateral: "narrow" },
  section: { hops: 2, direction: "both", lateral: "medium" },
  domain: { hops: 2, direction: "both", lateral: "medium" },
  template: { hops: 2, direction: "both", lateral: "narrow" },
  governance: { hops: 2, direction: "both", lateral: "medium" },
  artifact: { hops: 1, direction: "both", lateral: "narrow" },
  capability: { hops: 2, direction: "both", lateral: "medium" },
  primitive: { hops: 2, direction: "incoming", lateral: "broad" },
  "product thesis": { hops: 2, direction: "outgoing", lateral: "broad" },
  principle: { hops: 2, direction: "both", lateral: "medium" },
  standard: { hops: 2, direction: "incoming", lateral: "medium" },
  loop: { hops: 2, direction: "both", lateral: "medium" },
  journey: { hops: 2, direction: "both", lateral: "medium" },
  "experience goal": { hops: 1, direction: "both", lateral: "medium" },
  force: { hops: 2, direction: "both", lateral: "medium" },
  agent: { hops: 2, direction: "both", lateral: "medium" },
  default: { hops: 2, direction: "both", lateral: "medium" },
};

// Card budgets per complexity tier
interface Budget {
  primary: number;
  supporting: number;
}

const BUDGETS: Record<string, Budget> = {
  simple: { primary: 3, supporting: 5 },
  medium: { primary: 5, supporting: 8 },
  complex: { primary: 6, supporting: 10 },
  architecture: { primary: 8, supporting: 12 },
};

// Architectural types (placed at end of U-shaped ordering)
const ARCHITECTURAL_TYPES = new Set([
  "Product Thesis",
  "Principle",
  "Standard",
]);

// ── Result types ───────────────────────────────────────────────────────

interface OrderedEntry {
  card: string;
  role: "primary" | "supporting" | "architectural";
  position: "beginning" | "middle" | "end";
}

interface BudgetInfo {
  primary_max: number;
  supporting_max: number;
  used_primary: number;
  used_supporting: number;
  used_architectural: number;
}

interface RetrieveResult {
  seeds: string[];
  profile: string;
  complexity: string;
  primary: string[];
  supporting: string[];
  architectural: string[];
  budget: BudgetInfo;
  ordered: OrderedEntry[];
  warnings?: string[];
}

interface ErrorResult {
  error: string;
  seeds: string[];
  profile: string;
  complexity: string;
}

type Result = RetrieveResult | ErrorResult;

// ── Core logic ─────────────────────────────────────────────────────────

function getProfile(name: string): Profile {
  return PROFILES[name.toLowerCase()] ?? PROFILES["default"]!;
}

function retrieveCards(
  library: Library,
  seeds: string[],
  profileName: string,
  complexity: string,
): Result {
  const profile = getProfile(profileName);
  const budget = BUDGETS[complexity] ?? BUDGETS["medium"]!;

  // Validate seeds
  const missingSeeds = seeds.filter((s) => !library.cards.has(s));
  const validSeeds = seeds.filter((s) => library.cards.has(s));

  if (validSeeds.length === 0) {
    return {
      error: `No valid seed cards found. Missing: ${JSON.stringify(missingSeeds)}`,
      seeds,
      profile: profileName,
      complexity,
    };
  }

  // Traverse graph from seeds
  const allNeighbors = new Map<string, number>(); // card_name → min distance

  for (const seed of validSeeds) {
    const neighbors = library.neighbors(seed, profile.hops, profile.direction);
    for (const [name, dist] of neighbors) {
      const existing = allNeighbors.get(name);
      if (existing === undefined || dist < existing) {
        allNeighbors.set(name, dist);
      }
    }
  }

  // Add seeds themselves at distance 0
  for (const seed of validSeeds) {
    allNeighbors.set(seed, 0);
  }

  // Classify cards — sort by (distance, name) for determinism
  const sorted = [...allNeighbors.entries()].sort(
    ([nameA, distA], [nameB, distB]) => {
      if (distA !== distB) return distA - distB;
      return nameA.localeCompare(nameB);
    },
  );

  const primaryCandidates: Array<[string, number]> = [];
  const supportingCandidates: Array<[string, number]> = [];
  const architecturalCandidates: string[] = [];

  for (const [name, dist] of sorted) {
    const card = library.cards.get(name);
    if (!card) continue;

    if (card.cardType !== null && ARCHITECTURAL_TYPES.has(card.cardType)) {
      architecturalCandidates.push(name);
    } else if (dist <= 1) {
      primaryCandidates.push([name, dist]);
    } else {
      supportingCandidates.push([name, dist]);
    }
  }

  // Apply budgets
  const archSet = new Set(architecturalCandidates);
  let primary = primaryCandidates.slice(0, budget.primary).map(([n]) => n);
  let supporting = supportingCandidates
    .slice(0, budget.supporting)
    .map(([n]) => n);
  const architectural = architecturalCandidates; // Always include (not budgeted separately)

  // Remove architectural from primary/supporting to avoid duplicates
  primary = primary.filter((p) => !archSet.has(p));
  supporting = supporting.filter((s) => !archSet.has(s));

  // U-shaped attention ordering:
  // Beginning (strongest): primary cards
  // Middle (weakest): supporting cards
  // End (second-strongest): architectural cards
  const ordered: OrderedEntry[] = [];
  for (const name of primary) {
    ordered.push({ card: name, role: "primary", position: "beginning" });
  }
  for (const name of supporting) {
    ordered.push({ card: name, role: "supporting", position: "middle" });
  }
  for (const name of architectural) {
    ordered.push({ card: name, role: "architectural", position: "end" });
  }

  const result: RetrieveResult = {
    seeds,
    profile: profileName,
    complexity,
    primary,
    supporting,
    architectural,
    budget: {
      primary_max: budget.primary,
      supporting_max: budget.supporting,
      used_primary: primary.length,
      used_supporting: supporting.length,
      used_architectural: architectural.length,
    },
    ordered,
  };

  if (missingSeeds.length > 0) {
    result.warnings = missingSeeds.map((s) => `Seed not found: ${s}`);
  }

  return result;
}

function formatText(result: Result): string {
  if ("error" in result) {
    return `Error: ${result.error}`;
  }

  const lines: string[] = [];
  lines.push(`Profile: ${result.profile} | Complexity: ${result.complexity}`);
  lines.push(`Seeds: ${result.seeds.join(", ")}`);
  lines.push("");

  const b = result.budget;
  lines.push(
    `Budget: ${b.used_primary}/${b.primary_max} primary, ` +
      `${b.used_supporting}/${b.supporting_max} supporting, ` +
      `${b.used_architectural} architectural`,
  );
  lines.push("");

  lines.push("=== Ordered Card List (U-shaped attention) ===");
  lines.push("");
  lines.push("--- Beginning (strongest) ---");
  for (const entry of result.ordered) {
    if (entry.position === "beginning") {
      lines.push(`  [${entry.role}] ${entry.card}`);
    }
  }

  lines.push("");
  lines.push("--- Middle (weakest) ---");
  for (const entry of result.ordered) {
    if (entry.position === "middle") {
      lines.push(`  [${entry.role}] ${entry.card}`);
    }
  }

  lines.push("");
  lines.push("--- End (second-strongest) ---");
  for (const entry of result.ordered) {
    if (entry.position === "end") {
      lines.push(`  [${entry.role}] ${entry.card}`);
    }
  }

  if (result.warnings && result.warnings.length > 0) {
    lines.push("");
    lines.push("Warnings:");
    for (const w of result.warnings) {
      lines.push(`  - ${w}`);
    }
  }

  return lines.join("\n");
}

// ── CLI entry point ────────────────────────────────────────────────────

const { flags } = parseArgs(process.argv.slice(2));

const seedsArg = flags["seeds"] as string | undefined;
const profileArg = flags["profile"] as string | undefined;
const complexityArg = (flags["complexity"] as string | undefined) ?? "medium";
const libraryArg = flags["library"] as string | undefined;
const fmtArg = (flags["format"] as string | undefined) ?? "json";

if (
  !seedsArg ||
  typeof seedsArg !== "string" ||
  !profileArg ||
  typeof profileArg !== "string" ||
  !libraryArg ||
  typeof libraryArg !== "string"
) {
  const missing = [
    (!seedsArg || typeof seedsArg !== "string") && "--seeds",
    (!profileArg || typeof profileArg !== "string") && "--profile",
    (!libraryArg || typeof libraryArg !== "string") && "--library",
  ]
    .filter(Boolean)
    .join(", ");
  process.stderr.write(`Error: missing required arguments: ${missing}\n`);
  process.exit(1);
}

const validComplexities = ["simple", "medium", "complex", "architecture"];
if (!validComplexities.includes(complexityArg)) {
  process.stderr.write(
    `Error: --complexity must be one of: ${validComplexities.join(", ")}\n`,
  );
  process.exit(1);
}

const validFormats = ["json", "text"];
if (!validFormats.includes(fmtArg)) {
  process.stderr.write(
    `Error: --format must be one of: ${validFormats.join(", ")}\n`,
  );
  process.exit(1);
}

if (!existsSync(libraryArg) || !statSync(libraryArg).isDirectory()) {
  process.stderr.write(`Error: not a directory: ${libraryArg}\n`);
  process.exit(1);
}

const library = Library.fromDirectory(libraryArg);
const seeds = seedsArg
  .split(",")
  .map((s: string) => s.trim())
  .filter((s: string) => s.length > 0);

const result = retrieveCards(library, seeds, profileArg, complexityArg);

if (fmtArg === "json") {
  console.log(JSON.stringify(result, null, 2));
} else {
  console.log(formatText(result));
}

if ("error" in result) {
  process.exit(1);
}
