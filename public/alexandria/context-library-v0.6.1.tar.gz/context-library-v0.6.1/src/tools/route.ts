/**
 * Context Library capability-based model router.
 *
 * Reads a skill file's `requires:` frontmatter block, consults the routing
 * config, and returns the model name.
 *
 * Usage:
 *   context-library-route <skill-file>           # route a single file
 *   context-library-route --dir <skill-dir>      # route by max capability in dir
 *   context-library-route --dump <skill-file>    # show parsed capabilities
 *   context-library-route --dump-all             # audit all skill files
 */

import { readFileSync, existsSync, readdirSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";
import { parseSkillFrontmatter } from "../lib/frontmatter.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const REPO_ROOT = resolve(__dirname, "../..");
const ROUTING_CONFIG = resolve(REPO_ROOT, "config/model-routing.yaml");

// ── Types ──────────────────────────────────────────────────────────────

type Level = "high" | "medium" | "low";

interface Capabilities {
  adherence: Level;
  reasoning: Level;
  precision: Level;
  volume: Level;
}

interface RoutingConfig {
  primary_high: string;
  primary_medium: string;
  primary_low: string;
}

// ── Helpers ────────────────────────────────────────────────────────────

function die(msg: string): never {
  process.stderr.write(`error: ${msg}\n`);
  process.exit(1);
}

function levelNum(level: Level): number {
  switch (level) {
    case "high":
      return 3;
    case "medium":
      return 2;
    default:
      return 1;
  }
}

function numLevel(n: number): Level {
  if (n >= 3) return "high";
  if (n >= 2) return "medium";
  return "low";
}

function toLevel(v: unknown): Level {
  if (v === "high" || v === "medium" || v === "low") return v;
  return "low";
}

/** Parse the routing section from model-routing.yaml (line-based; no external YAML dep). */
function parseRoutingConfig(): RoutingConfig {
  if (!existsSync(ROUTING_CONFIG)) {
    die(`routing config not found: ${ROUTING_CONFIG}`);
  }

  const content = readFileSync(ROUTING_CONFIG, "utf-8");
  const lines = content.split("\n");

  let inRouting = false;
  const result: Record<string, string> = {};

  for (const line of lines) {
    if (/^routing:/.test(line)) {
      inRouting = true;
      continue;
    }
    // Leave routing section when we hit another top-level key
    if (inRouting && /^[a-zA-Z]/.test(line)) {
      inRouting = false;
      continue;
    }
    if (inRouting) {
      const match = line.match(/^\s+(primary_\w+):\s*(\S+)/);
      if (match) {
        // Strip inline comments
        result[match[1]!] = match[2]!.replace(/#.*$/, "").trim();
      }
    }
  }

  return {
    primary_high: result["primary_high"] ?? "opus",
    primary_medium: result["primary_medium"] ?? "sonnet",
    primary_low: result["primary_low"] ?? "haiku",
  };
}

/** Parse `requires:` frontmatter from a skill file. */
function parseCapabilities(filePath: string): Capabilities {
  if (!existsSync(filePath)) {
    die(`file not found: ${filePath}`);
  }

  const content = readFileSync(filePath, "utf-8");
  const { data } = parseSkillFrontmatter(content);
  const requires = data.requires ?? {};

  return {
    adherence: toLevel(requires.adherence),
    reasoning: toLevel(requires.reasoning),
    precision: toLevel(requires.precision),
    volume: toLevel(requires.volume),
  };
}

/** Compute primary capability level from adherence and reasoning. */
function primaryLevel(adherence: Level, reasoning: Level): Level {
  return numLevel(Math.max(levelNum(adherence), levelNum(reasoning)));
}

/** Resolve a primary level to a model name. */
function resolveModel(config: RoutingConfig, level: Level): string {
  switch (level) {
    case "high":
      return config.primary_high;
    case "medium":
      return config.primary_medium;
    default:
      return config.primary_low;
  }
}

// ── Route operations ───────────────────────────────────────────────────

/** Route a single skill file to a model name. */
export function routeFile(filePath: string): string {
  const caps = parseCapabilities(filePath);
  const config = parseRoutingConfig();
  const level = primaryLevel(caps.adherence, caps.reasoning);
  return resolveModel(config, level);
}

/** Route a directory — returns model for max primary capability across all .md files. */
export function routeDir(dir: string): string {
  if (!existsSync(dir)) {
    die(`directory not found: ${dir}`);
  }

  const config = parseRoutingConfig();
  let maxNum = 0;

  const files = readdirSync(dir).filter((f) => f.endsWith(".md"));
  for (const file of files) {
    const fullPath = resolve(dir, file);
    const caps = parseCapabilities(fullPath);
    const level = primaryLevel(caps.adherence, caps.reasoning);
    const n = levelNum(level);
    if (n > maxNum) maxNum = n;
  }

  const topLevel = numLevel(maxNum);
  return resolveModel(config, topLevel);
}

/** Dump parsed capabilities and resolved model for a skill file. */
export function dumpFile(filePath: string): string {
  const caps = parseCapabilities(filePath);
  const config = parseRoutingConfig();
  const level = primaryLevel(caps.adherence, caps.reasoning);
  const model = resolveModel(config, level);

  return (
    `adherence=${caps.adherence} reasoning=${caps.reasoning} ` +
    `precision=${caps.precision} volume=${caps.volume} primary=${level} model=${model}`
  );
}

// ── Main ───────────────────────────────────────────────────────────────

const args = process.argv.slice(2);

if (args.length === 0) {
  die(
    "usage: context-library-route <skill-file | --dir <dir> | --dump <file>>",
  );
}

switch (args[0]) {
  case "--dir":
    if (!args[1]) die("usage: context-library-route --dir <skill-directory>");
    console.log(routeDir(args[1]));
    break;

  case "--dump":
    if (!args[1]) die("usage: context-library-route --dump <skill-file>");
    console.log(dumpFile(args[1]));
    break;

  case "--dump-all": {
    const skillsDir = resolve(REPO_ROOT, "skills");
    if (!existsSync(skillsDir)) die("skills directory not found");
    const dirs = readdirSync(skillsDir, { withFileTypes: true })
      .filter((e) => e.isDirectory())
      .map((e) => e.name)
      .sort();
    for (const dirName of dirs) {
      const dirPath = resolve(skillsDir, dirName);
      const files = readdirSync(dirPath)
        .filter((f) => f.endsWith(".md"))
        .sort();
      for (const file of files) {
        const fullPath = resolve(dirPath, file);
        const label = `${dirName}/${file}`;
        const dump = dumpFile(fullPath);
        process.stdout.write(`${label.padEnd(45)} ${dump}\n`);
      }
    }
    break;
  }

  case "--help":
  case "-h":
    console.log(`Usage: context-library-route <skill-file>
       context-library-route --dir <skill-directory>
       context-library-route --dump <skill-file>
       context-library-route --dump-all

Routes a skill to a model based on its capability requirements.
Reads requires: frontmatter and consults config/model-routing.yaml.`);
    break;

  default:
    console.log(routeFile(args[0]!));
    break;
}
