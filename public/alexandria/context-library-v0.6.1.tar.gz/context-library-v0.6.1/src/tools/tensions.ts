/**
 * Context Library tension pre-screening CLI.
 *
 * Checks extracted claims against the library graph and signal queue to flag
 * T1 (direct contradiction), T5 (echo in queue), and T6 (blast radius) tensions.
 *
 * Usage:
 *   echo '{"claims": [...], "library_path": "..."}' | context-library-tensions
 *   context-library-tensions --input claims.json
 *   context-library-tensions --input claims.json --format text
 */

import { readFileSync, existsSync } from "fs";
import { Library } from "../lib/graph.js";
import { parseArgs } from "../lib/cli.js";

// ── Types ──────────────────────────────────────────────────────────────

interface Claim {
  id: string | number;
  assertion: string;
  affected_cards?: string[];
  keywords?: string[];
}

interface QueueEntry {
  claim?: string;
  affected_cards?: string[];
  [key: string]: unknown;
}

interface T1Flag {
  card: string;
  section: string;
  evidence: string;
  overlap_keywords: string[];
  confidence: "low" | "medium" | "high";
}

interface T5Flag {
  queue_entry: string;
  keyword_overlap: string[];
  card_overlap: string[];
}

interface T6BlastRadius {
  count: number;
  cards: string[];
}

interface ClaimResult {
  t1_flags: T1Flag[];
  t5_flags: T5Flag[];
  t6_blast_radius: T6BlastRadius;
  tension_count: number;
}

interface TensionsResult {
  [claimKey: string]: ClaimResult;
}

// ── Keyword extraction ─────────────────────────────────────────────────

const STOPWORDS = new Set([
  "the",
  "and",
  "for",
  "are",
  "but",
  "not",
  "you",
  "all",
  "can",
  "had",
  "her",
  "was",
  "one",
  "our",
  "out",
  "has",
  "have",
  "been",
  "this",
  "that",
  "with",
  "they",
  "from",
  "will",
  "would",
  "could",
  "should",
  "what",
  "when",
  "where",
  "which",
  "their",
  "there",
  "about",
  "each",
  "make",
  "like",
  "into",
  "than",
  "them",
  "then",
  "some",
  "also",
  "more",
  "other",
]);

function extractKeywords(text: string): Set<string> {
  const words = text.toLowerCase().match(/[a-zA-Z]{3,}/g) ?? [];
  return new Set(words.filter((w) => !STOPWORDS.has(w)));
}

// ── Signal queue loader ────────────────────────────────────────────────

function loadSignalQueue(path: string): QueueEntry[] {
  if (!existsSync(path)) return [];
  try {
    const content = readFileSync(path, "utf8");
    return content
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line.length > 0)
      .flatMap((line) => {
        try {
          return [JSON.parse(line) as QueueEntry];
        } catch {
          return [];
        }
      });
  } catch {
    return [];
  }
}

// ── Tension checks ─────────────────────────────────────────────────────

function checkT1Contradiction(claim: Claim, library: Library): T1Flag[] {
  const flags: T1Flag[] = [];
  const affected = claim.affected_cards ?? [];
  const assertion = claim.assertion ?? "";
  const claimKeywords = extractKeywords(assertion);

  if (claimKeywords.size === 0) return flags;

  for (const cardName of affected) {
    const card = library.cards.get(cardName);
    if (!card) continue;

    for (const sectionName of ["WHAT", "HOW"]) {
      const section = card.sections.get(sectionName);
      if (!section) continue;

      const sectionKeywords = extractKeywords(section.content);
      const overlap = new Set(
        [...claimKeywords].filter((k) => sectionKeywords.has(k)),
      );

      if (overlap.size < 2) continue;

      const evidenceLines: string[] = [];
      for (const line of section.content.split("\n")) {
        const lineTrimmed = line.trim();
        if (!lineTrimmed) continue;
        const lineKeywords = extractKeywords(lineTrimmed);
        const lineOverlap = [...claimKeywords].filter((k) =>
          lineKeywords.has(k),
        );
        if (lineOverlap.length >= 2) {
          evidenceLines.push(lineTrimmed);
        }
      }

      if (evidenceLines.length > 0) {
        const overlapSize = overlap.size;
        const confidence: "low" | "medium" | "high" =
          overlapSize >= 4 ? "high" : overlapSize >= 3 ? "medium" : "low";
        flags.push({
          card: cardName,
          section: sectionName,
          evidence: evidenceLines[0]!.slice(0, 200),
          overlap_keywords: [...overlap].sort().slice(0, 10),
          confidence,
        });
      }
    }
  }

  return flags;
}

function checkT5Echo(claim: Claim, queueEntries: QueueEntry[]): T5Flag[] {
  const flags: T5Flag[] = [];
  const claimKeywords = extractKeywords(claim.assertion ?? "");
  const claimAffected = new Set(claim.affected_cards ?? []);

  for (const entry of queueEntries) {
    const entryClaim = entry.claim ?? "";
    const entryKeywords = extractKeywords(String(entryClaim));
    const entryAffected = new Set(entry.affected_cards ?? []);

    const keywordOverlap = [...claimKeywords].filter((k) =>
      entryKeywords.has(k),
    );
    const cardOverlap = [...claimAffected].filter((c) => entryAffected.has(c));

    if (keywordOverlap.length >= 2 || cardOverlap.length > 0) {
      const raw = entryClaim ? String(entryClaim) : JSON.stringify(entry);
      flags.push({
        queue_entry: raw.slice(0, 200),
        keyword_overlap: keywordOverlap.sort().slice(0, 10),
        card_overlap: cardOverlap.sort(),
      });
    }
  }

  return flags;
}

function checkT6BlastRadius(claim: Claim, library: Library): T6BlastRadius {
  const affected = claim.affected_cards ?? [];
  const dependentCards = new Set<string>();

  for (const cardName of affected) {
    if (!library.cards.has(cardName)) continue;
    const neighbors = library.neighbors(cardName, 1, "incoming");
    for (const [name] of neighbors) {
      dependentCards.add(name);
    }
  }

  // Remove directly affected cards from dependents
  for (const cardName of affected) {
    dependentCards.delete(cardName);
  }

  return {
    count: dependentCards.size,
    cards: [...dependentCards].sort(),
  };
}

// ── Main processor ─────────────────────────────────────────────────────

function processClaims(data: {
  claims?: Claim[];
  library_path?: string;
  signal_queue_path?: string;
}): TensionsResult {
  const claims = data.claims ?? [];
  const libraryPath = data.library_path ?? "";
  const signalQueuePath = data.signal_queue_path ?? "";

  const library = libraryPath
    ? Library.fromDirectory(libraryPath)
    : new Library();
  const queueEntries = signalQueuePath ? loadSignalQueue(signalQueuePath) : [];

  const results: TensionsResult = {};

  for (const claim of claims) {
    const claimId = String(claim.id ?? "unknown");
    const key = `claim_${claimId}`;

    const t1Flags = checkT1Contradiction(claim, library);
    const t5Flags = checkT5Echo(claim, queueEntries);
    const t6Blast = checkT6BlastRadius(claim, library);

    results[key] = {
      t1_flags: t1Flags,
      t5_flags: t5Flags,
      t6_blast_radius: t6Blast,
      tension_count:
        t1Flags.length + t5Flags.length + (t6Blast.count > 0 ? 1 : 0),
    };
  }

  return results;
}

// ── Text formatter ─────────────────────────────────────────────────────

function formatText(results: TensionsResult): string {
  const lines: string[] = [];

  for (const claimKey of Object.keys(results).sort()) {
    const data = results[claimKey]!;
    lines.push(`\n${claimKey}:`);
    lines.push(`  Tensions found: ${data.tension_count}`);

    if (data.t1_flags.length > 0) {
      lines.push("  T1 (Contradiction):");
      for (const flag of data.t1_flags) {
        lines.push(`    - ${flag.card} [${flag.section}] (${flag.confidence})`);
        lines.push(`      Evidence: ${flag.evidence.slice(0, 100)}`);
      }
    }

    if (data.t5_flags.length > 0) {
      lines.push("  T5 (Echo in queue):");
      for (const flag of data.t5_flags) {
        lines.push(`    - ${flag.queue_entry.slice(0, 80)}`);
        if (flag.keyword_overlap.length > 0) {
          lines.push(`      Keywords: ${flag.keyword_overlap.join(", ")}`);
        }
      }
    }

    const blast = data.t6_blast_radius;
    if (blast.count > 0) {
      lines.push(`  T6 (Blast radius): ${blast.count} dependent cards`);
      for (const card of blast.cards.slice(0, 10)) {
        lines.push(`    - ${card}`);
      }
    }
  }

  return lines.join("\n");
}

// ── CLI entry point ────────────────────────────────────────────────────

const { flags } = parseArgs(process.argv.slice(2));

const inputArg = flags["input"] as string | undefined;
const fmtArg = (flags["format"] as string | undefined) ?? "json";

const validFormats = ["json", "text"];
if (!validFormats.includes(fmtArg)) {
  process.stderr.write(
    `Error: --format must be one of: ${validFormats.join(", ")}\n`,
  );
  process.exit(1);
}

let rawInput: string;
if (inputArg) {
  if (!existsSync(inputArg)) {
    process.stderr.write(`Error reading input: file not found: ${inputArg}\n`);
    process.exit(1);
  }
  try {
    rawInput = readFileSync(inputArg, "utf8");
  } catch (err) {
    process.stderr.write(`Error reading input: ${err}\n`);
    process.exit(1);
  }
} else {
  try {
    rawInput = readFileSync(0, "utf8");
  } catch (err) {
    process.stderr.write(`Error reading stdin: ${err}\n`);
    process.exit(1);
  }
}

let data: {
  claims?: Claim[];
  library_path?: string;
  signal_queue_path?: string;
};
try {
  data = JSON.parse(rawInput);
} catch (err) {
  process.stderr.write(
    `Error parsing JSON from ${inputArg ?? "stdin"}: ${err}\n`,
  );
  process.exit(1);
}

const results = processClaims(data);

if (fmtArg === "json") {
  console.log(JSON.stringify(results, null, 2));
} else {
  console.log(formatText(results));
}
