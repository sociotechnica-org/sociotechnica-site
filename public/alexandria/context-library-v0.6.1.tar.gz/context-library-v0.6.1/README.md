# Context Library

A construction system for product knowledge. AI agents that build and maintain structured knowledge graphs so your AI-assisted production process stays aligned with your vision.

## What Is This?

The Context Library is a **Claude Code plugin** that creates and maintains a product knowledge graph in any software project. It gives your AI builder agents the product context they need to make aligned decisions — not just technically correct ones.

A **context library** is a set of typed markdown cards organized as a knowledge graph. Each card documents a concept in your product with five dimensions:

- **WHAT** — Standalone definition
- **WHERE** — Relationships to other concepts via `[[wikilinks]]`
- **WHY** — Strategic rationale (links to principles and strategies)
- **WHEN** — Implementation status, timeline, reality notes
- **HOW** — Implementation guidance, examples, anti-patterns

The graph is encoded in the filesystem:
- **Folder paths** = type taxonomy
- **File names** = card identifiers (`Type - Name.md`)
- **`[[wikilinks]]`** = relationship edges
- **Section headers** = dimension boundaries

## Why?

Without specification context, AI agents produce technically correct but contextually wrong code. They implement features that work but don't fit — wrong naming, wrong UX patterns, wrong architectural assumptions.

The Context Library makes implicit product knowledge explicit and queryable. When an agent needs to implement a feature, it gets a context briefing assembled from the relevant cards so it makes aligned decisions.

**Think of it as onboarding documentation that AI agents actually read.**

## Quick Start

### Prerequisites

- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) installed and authenticated
- A Git repository for your project

### 1. Install the plugin

Run the installer from your project directory:

```bash
curl -fsSL https://sociotechnica.org/alexandria/install.sh | bash
```

The installer:

- **Detects context** — inside a Git repo it installs to `.claude/plugins/context-library/`
  (project-local, version-pinned per project); outside a repo it falls back to
  `~/.claude/plugins/context-library/` (global, shared across all projects)
- **Prompts for confirmation** before writing anything, showing the target path
- **Auto-installs Bun** if it is not already present (Bun compiles the CLI tools
  on first setup; plugin consumers do not need Bun for day-to-day use after that)

After installation, launch Claude Code. For project-local installs:

```bash
claude --plugin-dir .claude/plugins/context-library
```

Add the plugin directory to `.gitignore` to keep it out of version control:

```bash
echo '.claude/plugins/context-library/' >> .gitignore
```

For global installs, the plugin is auto-discovered — no flag needed:

```bash
claude
```

You can pin a specific version by setting `CONTEXT_LIBRARY_VERSION` before running
the installer:

```bash
curl -fsSL https://sociotechnica.org/alexandria/install.sh | CONTEXT_LIBRARY_VERSION=0.6.0 bash
```

<details>
<summary>Alternative: clone for contributors</summary>

If you are contributing to this repository or want the full source (tests, docs, evals):

```bash
git clone https://github.com/sociotechnica-org/context-library.git
cd context-library
bun install
./scripts/setup-dev
```

`./scripts/setup-dev` installs `shellcheck` and `shfmt` when missing, runs
product setup, and additionally symlinks `contributor-skills/` into
`~/.claude/skills/` and `~/.codex/skills/`.

Formatting policy on this repo is intentionally split:

- Prettier formats only TypeScript, JSON, and YAML
- Shell files are checked with `shfmt` and `shellcheck`
- Markdown is linted separately with `markdownlint-cli2` plus repo-specific
  semantic checks

</details>

### 2. Configure your library

In Claude Code, run the wizard:

```
Use the wizard to configure a context library for this project
```

The wizard asks three questions — your AI mode, domain novelty, and product complexity — then produces a prioritized list of knowledge areas to build first.

### 3. Add your source material

Drop your product spec, design doc, or GDD into `docs/context-library/sources/`:

```bash
cp my-product-spec.md your-project/docs/context-library/sources/
```

### 4. Build the library

```
Use the Conan agent to inventory cards from the source material in docs/context-library/sources/
```

Conan reads your source material and produces an inventory. Then:

```
Use the Sam agent to build the cards from Conan's inventory
```

Sam creates the cards. Conan grades them. You iterate.

### 5. Use the library during development

When implementing a feature:

```
Use the Bridget agent to assemble a context briefing for implementing the user dashboard
```

Bridget pulls relevant cards into a `CONTEXT_BRIEFING.md`. Your implementing agent reads it and builds with full product context.

## The Agent Team

Six agents with separated responsibilities — the critic cannot build, the builder cannot grade, the linter is adversarial.

| Agent | Role | Job |
|-------|------|-----|
| **Conan** | Librarian | Grades cards, diagnoses gaps, plans surgery, runs health checks. Produces surgery plans for Sam. |
| **Sam** | Scribe | Builds cards, fixes cards, runs self-checks. The only agent that writes card content. |
| **Nit** | Picker | Mechanical linter. Boolean checks on card format, wikilinks, file paths, wizard arithmetic. |
| **Bridget** | Briefer | Assembles context briefings for builder agents. Logs gaps as demand signal back to the library. |
| **Raven** | Maven | Product thinking partner. Brainstorms, pressure-tests, traces implications. Produces handoffs. |
| **Solomon** | Sorter | Signal intake and triage. Classifies raw signal by epistemic status before it enters the library. |

## Type Taxonomy

Cards are organized into 18 types across four layers:

### Why Layer (product rationale)

| Type | Purpose |
|------|---------|
| Product Thesis | Guiding philosophy — a bet the product makes |
| Principle | Judgment guidance — a rule of thumb |
| Standard | Testable specification — concrete rules |

### Builder-Facing Layer (things builders interact with)

| Type | Purpose |
|------|---------|
| Domain | Top-level navigation destination |
| Section | Nested area within a Domain |
| Governance | Persistent across all Domains |
| Template | Spatial canvas within a Section |
| Component | Discrete widget or UI element |
| Artifact | Content object |
| Capability | Action or workflow |
| Primitive | Core data entity |

### Infrastructure Layer

| Type | Purpose |
|------|---------|
| System | Invisible mechanism or rule |
| Agent | AI team member |
| Prompt | Agent implementation |

### Experience-Over-Time Layer

| Type | Purpose |
|------|---------|
| Loop | Repeating activity cycle |
| Journey | Multi-phase progression arc |
| Experience Goal | Target emotional state |
| Force | Emergent cross-system behavior |

Not every type applies to every product. The wizard helps you figure out which ones matter for yours.

## The Configuration Wizard

The wizard determines which knowledge areas your project needs based on three inputs:

1. **AI Mode** — How much product decision authority do AI builders have? (No AI → Short-Order Cook → Pair Programmer → Factory)
2. **Novelty** — How well-understood is your product category? (Low → Moderate → High)
3. **Complexity** — How much structural coupling exists? (Low → Moderate → High)

Output: each of the 22 knowledge areas is assigned to a tier — **Foundation** (build first), **Core** (primary value), **Amplifier** (multiplies value), or **Deprioritized** (build later if at all).

## Model Routing

Skills declare capability requirements instead of hardcoding model names. Four dimensions — `adherence`, `reasoning`, `precision`, `volume` — scored low/medium/high. The routing config maps these to models automatically:

| Capability Level | Model |
|-----------------|-------|
| Any primary dimension = high | opus |
| Any primary dimension = medium | sonnet |
| All primary dimensions = low | haiku |

## The Workflow

```
Source material → Conan inventories → Sam builds → Nit sweeps → Conan grades
                                                                    ↓
                                                              Sam fixes → repeat
```

During development:
```
Task arrives → Bridget assembles context → Agent implements with full product context
                    ↓
              Assembly gaps logged → feed back into library priorities
```

For work on this repository itself, the plugin also supports a repo-local issue workflow:

1. `Use /context-library-dev-technical-planning` to translate a GitHub issue plus linked product plan into
   `docs/context-library/plans/<issue>-<task>/plan.md`
2. `Use /context-library-dev-issue-execution` to carry an issue from GitHub reference through branch, plan,
   implementation, local review, PR, and review follow-through
3. `Use /context-library-dev-targeted-evals` after local review to rerun only the evals whose behavior
   surfaces changed
4. `Use /context-library-dev-release-deployment` to validate the Alexandria release path, tag a release,
   and watch the cross-repo publication workflow through completion

## Deployment

The Alexandria distribution path is documented in [RELEASING.md](./RELEASING.md).

In short:

1. validate the repo locally with `bun run check`, `bun test`, and `./scripts/build-tarball.sh`
2. tag `v$(cat VERSION)` from a clean `main`
3. let `.github/workflows/release.yml` create the GitHub Release and publish
   `latest-version.txt`, `install.sh`, and the tarball into `sociotechnica-site/public/alexandria/`

The workflow intentionally fails if `install.sh` is missing, because Alexandria should not
publish a partial installer surface.

## Updating

Check your current version:

```bash
bin/context-library-version
```

Check if a newer version is available:

```bash
bin/context-library-update-check
```

Or use the upgrade skill in Claude Code:

```
Run /context-library-upgrade
```

## Customization

The wizard handles initial configuration. For manual adjustment, edit `docs/context-library/reference.md` to add or remove types. The agents adapt to whatever types exist.

## Obsidian Integration

The library works with [Obsidian](https://obsidian.md) for graph visualization. Open `docs/context-library/` as a vault to get graph view, backlinks, and wikilink resolution.

## License

MIT

## Contributing

Maintained by [SocioTechnica](https://github.com/sociotechnica-org). Issues and PRs welcome.
