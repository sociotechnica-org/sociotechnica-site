---
name: wizard
description: >
  Configure a new Context Library by asking three questions about your product and AI usage.
  Produces a prioritized seeding plan that tells Conan and Sam what knowledge to build first.
  Use when initializing a context library in a new project.
requires:
  adherence: medium
  reasoning: medium
  precision: medium
  volume: low
---

# Context Library Wizard

Configure a Context Library for your product by answering three questions. The wizard
determines which of 22 knowledge areas matter for your team, in what order to seed them,
and what risks to watch for.

## When to Use

Use this skill when:
- Setting up a Context Library in a new project
- Re-evaluating library priorities after your AI usage model changes
- Understanding what knowledge gaps pose the most risk

## How It Works

First, determine what inputs the user has. Then ask three configuration questions,
apply an engine, and produce a seeding plan.

### Step 0: Input Routing

Before configuring the library, ask two yes/no questions to determine what the user
is working with:

> **Before we configure your Context Library, two quick questions:**
>
> 1. **Do you have existing product documentation** (strategy docs, PRDs, design docs)?
> 2. **Do you have a codebase to scan?**

Based on the answers, follow one of four paths:

| Docs? | Code? | Path |
|-------|-------|------|
| Yes | No | **Docs only** — Proceed to Step 1 below. The wizard will configure your library based on your documentation. |
| No | Yes | **Code only** — Before configuring, let's scan your codebase to discover what exists. [This invokes the scanner skill — see scanner.md] After scanning completes, proceed to Step 1 with your discovered entities pre-loaded. |
| Yes | Yes | **Both** — Before configuring, let's scan your codebase to discover what exists. [This invokes the scanner skill — see scanner.md] After scanning completes, proceed to Step 1 with your discovered entities pre-loaded. Your documentation will also be available for reference during later steps. |
| No | No | **Neither** — Proceed to Step 1 below. You'll provide knowledge directly during the solicitation phase. |

**Notes:**
- The routing questions determine which *path* the user takes, not configuration values.
  They are not passed to the engine.
- **Interim behavior (until scanner skill is available):** For "code only" and "both"
  paths, tell the user: "Codebase scanning is coming soon. For now, let's proceed with
  configuration — you can describe your product's entities directly during the
  solicitation phase." Then proceed to Step 1.
- All four paths converge at Step 1 — the three configuration questions are always asked.

### Step 0b: Noun Proposal Dialogue

After the scanner completes (Step 0), present the discovered entities to the user
for confirmation. The user is the product expert — the scanner proposes, the human
decides.

**1. Summary layer:**

Present a high-level overview before any details:

> "I scanned your codebase and found **[N] candidate product entities** organized
> in **[M] domain groups**. Here's the overview:"
>
> | Domain | Entities | Top Confidence |
> |--------|----------|---------------|
> | [domain] | [count] | [highest confidence entity] |
>
> "Let's go through each domain. You can confirm, rename, merge, split, or
> reject any entity."

**2. Domain-by-domain confirmation:**

For each domain group, present the entities:

> "**[Domain Name]** — I found [N] entities:"
>
> | Entity | Confidence | Evidence |
> |--------|-----------|----------|
> | [name] | [high/medium/low] | [brief evidence summary] |
>
> "Which of these are real product concepts? You can:
> - **Confirm** — yes, this is a real product entity
> - **Rename** — right concept, wrong name (e.g., 'Subscription' → 'Plan')
> - **Merge** — these are actually the same thing (e.g., 'User' + 'Account')
> - **Split** — this is actually multiple things
> - **Reject** — this is an implementation detail, not a product concept"

Wait for the user to respond before moving to the next domain.

**3. Annotation (optional):**

For each confirmed entity, optionally ask:

> "Anything I should know about **[entity]**? What role does it play in your product?"
> (Skip if you'd rather move on — you can always add context later.)

Record any annotations. These become product intent that enriches the entity beyond
what code can tell us.

**4. Confirmation summary:**

After all domains are reviewed:

> "Here's what we confirmed:"
>
> | Entity | Domain | Annotation |
> |--------|--------|-----------|
> | [name] | [domain] | [annotation or "—"] |
>
> "[N] entities confirmed, [M] rejected, [K] renamed/merged/split."
>
> "These will be pre-loaded as existing knowledge when we configure your library.
> Ready to proceed to configuration?"

**Anti-pattern guard:** NEVER dump all proposals at once. Always show the summary
layer first, then walk through domains one at a time. If there are more than 5
domains, ask "Want to see all [N] domains, or focus on the top ones by confidence?"

### Step 0c: Pre-load Discovered Entities

After the noun proposal dialogue completes, pre-load confirmed entities into the
wizard's knowledge state before proceeding to configuration.

**What happens:**
1. Confirmed entities are recorded for use in Step 5 (Gap Analysis)
2. Each confirmed entity maps to knowledge area 2.3 (Product Entities) and
   potentially 2.2 (Noun Vocabulary)
3. During Step 5b (Knowledge Declaration), areas with discovered entities are
   pre-populated as "present" with freshness "fresh"
4. The user can still override: "The scanner found your User entity, but is your
   User documentation actually complete?" → user can downgrade to "partial"

**What is written to wizard-config.json:**

Add a `discovery` section as a sibling to the existing config:

```json
{
  "discovery": {
    "scan_date": "[ISO timestamp]",
    "scan_tiers": ["tier1"] or ["tier1", "tier2"],
    "confirmed_entities": [
      {
        "name": "[entity name]",
        "domain": "[domain group]",
        "annotation": "[user annotation or null]",
        "confidence": "high|medium|low",
        "evidence": ["file paths"]
      }
    ],
    "rejected_entities": ["[names of rejected proposals]"]
  }
}
```

**Integration with Step 5b:**

When Step 5b runs (Knowledge Declaration), check for the `discovery` section:
- If it exists, pre-populate area 2.3 (Product Entities) as "present/fresh" if
  confirmed entities exist
- Show the user: "Based on your codebase scan, I've pre-populated these areas as
  present. Adjust if needed."
- Other areas (Vision, Strategy, etc.) are NOT affected by code discovery — they
  still require human declaration

**Key constraint:** Discovery pre-populates, it does not override. The user always
has final say on gap analysis status.

### Step 0d: Code Walk — Doc vs. Code Validation (Both path only)

This step only runs when the user answered "yes" to both routing questions (has docs
AND has code). It compares what documentation claims against what the scanner found.

**When to run:** After Step 0c (entity pre-loading) and before Step 1. Only for the
"both" routing path.

**Divergence classification:**

Compare each documented product entity/feature against scanner findings:

| Classification | Meaning | Example |
|---------------|---------|---------|
| **Missing from code** | Docs describe it, scanner found no evidence | "Your docs mention a Referral system but the codebase has no referral models, routes, or UI" |
| **Missing from docs** | Scanner found it, docs don't mention it | "The scanner found a Notification entity with models and routes, but your docs don't mention notifications" |
| **Evolved past docs** | Both exist but code has diverged | "Your docs describe Billing with 3 plan types, but the code shows 5 plan types and a trial system" |

**Flow:**

1. **Load documentation context:** Read existing library cards or user-provided docs
   that describe the product's entities and features.

2. **Cross-reference with scanner output:** For each documented entity, check if the
   scanner found matching evidence. For each scanner entity, check if docs mention it.

3. **Classify divergences:** Apply the three-type classification above.

4. **Present divergences to user:**

> "I compared your documentation against your codebase. Here's what I found:"
>
> **Missing from code** ([N] items):
> | Entity | Doc Source | Scanner Finding |
> |--------|-----------|-----------------|
> | [name] | [where in docs] | No code evidence found |
>
> **Missing from docs** ([N] items):
> | Entity | Scanner Evidence | Confidence |
> |--------|-----------------|-----------|
> | [name] | [file paths] | [high/medium/low] |
>
> **Evolved past docs** ([N] items):
> | Entity | Doc Description | Code Reality |
> |--------|----------------|-------------|
> | [name] | [what docs say] | [what code shows] |

5. **User decides:** For each divergence:
   - "Update docs" — flag for library card update
   - "Acknowledge" — known divergence, no action needed
   - "Investigate" — needs more research before deciding

**Key constraints:**
- This step is OPTIONAL — only for "both" routing path
- Scanner output from Tier 1 + Tier 2 is used for comparison
- The code walk does NOT modify any library cards — it flags divergences for the user
- "Missing from code" does NOT mean "delete from docs" — the feature might be planned

### Step 1: Ask the Three Questions

Read the questions and guidance from `${CLAUDE_PLUGIN_ROOT}/docs/wizard/wizard-engine.yaml`
(the `questions` section). Present each question with its options and guidance text.

**Question 1: AI Mode**
> "How much product decision authority do your AI builders have?"

| Mode | Description |
|------|-------------|
| **No/Low AI** | A product person makes every product decision. AI assists but doesn't decide. |
| **Short-Order Cook** | A product person scopes each task. AI executes bounded work but doesn't decide what to build. |
| **Pair Programmer** | AI participates in design. It proposes and evaluates, but a product person approves. |
| **Factory** | AI is the primary implementer. It makes hundreds of product micro-decisions autonomously. |

If the user is unsure, use the disambiguation prompt: "Think about the last 10 product
decisions. How many did a product person explicitly make vs. how many did the builder
decide on their own?"

**After Q1: Show Risk Narrative**

Once the user answers Q1, immediately present the mode's risk narrative from the
`mode_narratives` section of `${CLAUDE_PLUGIN_ROOT}/docs/wizard/wizard-engine.yaml`.
Use the key that matches their answer (no_low_ai, short_order_cook, pair_programmer,
or factory).

Present it as:

> **Your risk profile at [Mode] mode:**
> [risk text from mode_narratives]
>
> [story text from mode_narratives]
>
> Keep this in mind as you answer the next two questions.

Then continue with Q2.

**Question 2: Domain Novelty**
> "If you described your product in one sentence, would someone from your industry correctly guess what using it feels like?"

| Level | Description |
|-------|-------------|
| **Low** | Established category. "It's a CRM" and people picture something close. |
| **Moderate** | Familiar space, novel approach. People get the purpose but picture something different. |
| **High** | Pioneering. No established category. People look confused or compare to the wrong thing. |

**After the user answers Q2, apply a disambiguation bump:**

> **If the user said Low:**
> "Quick check — when you onboard a new team member, how long before they stop saying
> 'oh, I assumed it would work like [familiar product]'? If that's more than a week,
> you might be Moderate."
>
> **If the user said High:**
> "Quick check — do you have any direct competitors, even bad ones? If yes, your
> domain has a category forming — you might be Moderate."
>
> **If the user said Moderate:** No bump needed.

Accept whatever the user decides after the bump — these are gentle nudges, not corrections.
If they confirm their original answer, use it. If they change to Moderate, use that.

**Question 3: Product Complexity**
> "Which of these are true about your product? (Check all that apply)"

| Signal | What it indicates |
|--------|------------------|
| Features share data or state (e.g., a user's action in one area shows up in another) | Cross-feature coupling |
| The product has invisible mechanisms: scoring, recommendations, matching, progression | Hidden interconnection |
| Permissions or roles change what people see or can do | Access-layer complexity |
| There are workflows that span multiple screens or features | Cross-boundary flows |
| Changing one feature's rules has broken or surprised another feature before | Observed ripple effects |
| The product has an internal economy, points, or resource system | Shared resource coupling |

**Mapping:** Count the checked items:
- **0-1 checked → Low** complexity
- **2-3 checked → Moderate** complexity
- **4+ checked → High** complexity

Each signal is binary and observable — the checklist does the systems thinking so the user doesn't have to. Use the mapped Low/Moderate/High value as the complexity input to the engine.

**Important:** These signals are about your PRODUCT's behavior, not your tech stack.
"Permissions or roles" means user-facing permission systems, not your deployment IAM.
"Workflows spanning multiple screens" means user journeys, not microservice calls.

### Step 2: Run the Engine

Use the wizard CLI to compute tier assignments:

```bash
bin/context-library-wizard --mode <mode> --novelty <novelty> --complexity <complexity> --format json
```

This reads the engine YAML and produces the tier assignment for each knowledge area. If the
CLI is not available, load the engine data from `${CLAUDE_PLUGIN_ROOT}/docs/wizard/wizard-engine.yaml`
and apply the algorithm from `${CLAUDE_PLUGIN_ROOT}/skills/wizard/engine.md` manually.

The engine takes (mode, novelty, complexity) and produces a tier assignment (Foundation,
Core, Amplifier, or Deprioritized) for each knowledge area in the mode's pool (10-22 areas
depending on AI mode).

### Step 3: Write the Output

Write the results to `docs/context-library/wizard-output.md` in the target project:

```markdown
# Context Library Configuration

**Generated by:** Context Library Wizard v1.0
**Date:** [date]
**Configuration:** [Mode] × [Novelty] Novelty × [Complexity] Complexity

## Your Risk Profile

> [Mode narrative risk statement from wizard-engine.yaml mode_narratives]

[Mode narrative story]

## Knowledge Areas by Priority

### Foundation (seed first)
[These must exist before anything else. Other knowledge depends on them.]

| # | Area | Domain | Why It Matters |
|---|------|--------|---------------|
| [id] | [name] | [domain] | [when_missing] |

### Core (seed after Foundation)
[Primary value drivers for your configuration.]

| # | Area | Domain | Why It Matters |
|---|------|--------|---------------|
| [id] | [name] | [domain] | [when_missing] |

### Amplifier (seed when Foundation + Core are in place)
[Makes Foundation and Core more effective.]

| # | Area | Domain | Why It Matters |
|---|------|--------|---------------|
| [id] | [name] | [domain] | [when_missing] |

### Deprioritized (seed last, if at all)
[In your pool but low urgency for your configuration.]

| # | Area | Domain | Why It Matters |
|---|------|--------|---------------|
| [id] | [name] | [domain] | [when_missing] |

### Not In Pool
[These knowledge areas are not relevant at your AI mode level.]

- [name]: [description of when it becomes relevant]

## What This Means

[2-3 sentences interpreting the configuration. Highlight any surprising results —
e.g., areas that are higher priority than expected, or areas that are deprioritized
despite seeming important.]

## Next Steps

1. Add source material to `docs/context-library/sources/`
2. Ask Conan to inventory cards, prioritizing Foundation areas first
3. Ask Sam to build cards from the inventory
4. Iterate: Conan grades → Sam fixes → repeat
5. When Foundation and Core are solid, move to Amplifier areas
```

Also write a machine-readable `docs/context-library/wizard-config.json`:

```json
{
  "version": "1.0",
  "generated": "[ISO timestamp]",
  "inputs": {
    "mode": "[mode value]",
    "novelty": "[novelty value]",
    "complexity": "[complexity value]"
  },
  "pool_size": [N],
  "distribution": {
    "foundation": [N],
    "core": [N],
    "amplifier": [N],
    "deprioritized": [N]
  },
  "areas": [
    {
      "id": "[area id]",
      "name": "[area name]",
      "domain": "[domain]",
      "tier": "[tier]"
    }
  ]
}
```

### Step 4: Present Summary

After writing the files, present a concise summary to the user:

```
Context Library configured: [Mode] × [Novelty] × [Complexity]
Pool: [N] areas | [F] Foundation, [C] Core, [A] Amplifier, [D] Deprioritized

Risk: [mode risk statement]

Foundation areas (seed first):
- [list]

Full plan written to docs/context-library/wizard-output.md
```

**Before asking about gap analysis, present a confirmation check:**

> **Does this ring true?** Look at the Foundation areas above — these are the ones
> your library needs most. Think about whether your team has experienced the kinds of
> problems that come from missing this knowledge. For example, if Product Vision is
> Foundation, has your team ever had builders filling the vacuum with their own
> assumptions? If the Foundation areas match real problems you've seen, the
> configuration is well-calibrated. If they seem irrelevant to your experience,
> say **"reconfigure"** to adjust your answers.

If the user says "reconfigure," return to Step 1 with their Q1 answer preserved
(since AI Mode is the least likely to be wrong) and re-ask Q2 and Q3.

If the user confirms or says anything other than "reconfigure," proceed to ask about
gap analysis as normal.

Then ask: **"Would you like to run a gap analysis to assess what knowledge you already have?"**

If yes, proceed to Step 5. If no, stop here.

---

### Step 5: Gap Analysis

The gap analysis compares the wizard's recommendations against the team's existing knowledge
and produces a prioritized seeding sequence. It can run immediately after Step 4, or later
against an existing `docs/context-library/wizard-config.json`.

Apply the gap analysis algorithm from `${CLAUDE_PLUGIN_ROOT}/skills/wizard/engine.md`
(the "Gap Analysis Engine" section).

#### 5a: Load Configuration

If running independently (not immediately after Steps 1-4), load the existing configuration:

```
Read docs/context-library/wizard-config.json from the target project.
Extract: mode, novelty, complexity, and the areas array with tier assignments.
```

If the file doesn't exist, tell the user to run the wizard configuration first (Steps 1-4).

#### 5b: Knowledge Declaration

For each area in the pool, collect the team's current knowledge state. Present areas grouped
by domain to reduce context switching.

**Pre-population from discovery:** Before presenting areas, check if
`wizard-config.json` contains a `discovery` section (written by Step 0c). If it does:
- Pre-populate area 2.3 (Product Entities) as "present" / "fresh" if `confirmed_entities`
  is non-empty
- Pre-populate area 2.2 (Noun Vocabulary) as "partial" / "fresh" if confirmed entities
  include annotations
- Show the user which areas were pre-populated and let them adjust:
  > "Based on your codebase scan, I've pre-populated these areas: [list]. Adjust if needed."
- All other areas remain undeclared and follow the normal collection flow below

**For each domain** (Vision & Strategy, Architecture & Nouns, Experience & Feel,
Visual & Interaction, Decision History):

> **[Domain Name]** — [N] areas in your pool:
>
> | # | Area | What Goes Wrong Without It | Your Status |
> |---|------|---------------------------|-------------|
> | [id] | [name] | [when_missing text from wizard-engine.yaml catalog] | ? |
>
> For each area, what's your current state?
> - **Absent** — no documentation exists
> - **Partial** — some documentation but with significant gaps
> - **Robust** — documentation exists and adequately covers the area
>
> (Your answer is recorded as "absent", "partial", or "present" in the configuration data.)
>
> The "What Goes Wrong Without It" column shows real symptoms. If those problems
> sound familiar, your documentation for that area may not be as complete as you think.
>
> For Robust or Partial areas, how current is it?
> - **Fresh** — reflects current product state
> - **Stale** — exists but outdated
> - **Unknown** — not sure if it's current
>
> You can also say **"all absent"** or **"all robust + fresh"** for the whole domain.

**Defaults:** Any undeclared area is treated as Absent / Unknown.

Collect optional free-text notes if the user provides them.

#### 5c: Score and Sequence

Apply the gap scoring and sequencing algorithms from the engine:

1. Score each area using `priority_score = tier_weight × gap_severity` (or `tier_weight × freshness_penalty` for present items)
2. Assign actions: create / update / refresh / none
3. Sort by priority score descending, then tier rank, then catalog order
4. Group into phases: Foundation Gaps → Core Gaps → Amplifier Gaps → Deprioritized Gaps → Already Covered

See `${CLAUDE_PLUGIN_ROOT}/skills/wizard/engine.md` for the complete algorithm and edge cases.

#### 5d: Write Output

Update `docs/context-library/wizard-config.json` in the target project, adding `intake` and
`gap_analysis` sections as sibling properties to the existing wizard configuration:

```json
{
  "version": "1.0",
  "generated": "[ISO timestamp]",
  "inputs": { "...existing..." },
  "pool_size": "...existing...",
  "distribution": { "...existing..." },
  "areas": [ "...existing..." ],
  "intake": {
    "existing_knowledge": [
      {
        "area_id": "[id]",
        "status": "absent|partial|present",
        "freshness": "fresh|stale|unknown",
        "notes": "[optional]"
      }
    ]
  },
  "gap_analysis": {
    "gaps": [
      {
        "area_id": "[id]",
        "name": "[name]",
        "recommended_tier": "[tier]",
        "current_status": "absent|partial|present",
        "current_freshness": "fresh|stale|unknown",
        "priority_score": 0.0,
        "action": "create|update|refresh|none"
      }
    ],
    "sequence": ["[ordered area ids]"],
    "summary": {
      "total_areas": 0,
      "gaps_to_fill": 0,
      "areas_to_refresh": 0,
      "areas_complete": 0
    }
  }
}
```

#### 5e: Present Summary

**If there are gaps:**

```
Gap analysis complete: [Mode] × [Novelty] × [Complexity]
Pool: [N] areas | [G] gaps, [R] to refresh, [C] complete

Phase 1 — Foundation Gaps (seed first):
- [area name] ([id]) — [status] — score: [score]

Phase 2 — Core Gaps:
- [area name] ([id]) — [status] — score: [score]

Phase 3 — Amplifier Gaps:
- [area name] ([id]) — [status] — score: [score]

Phase 3b — Deprioritized Gaps (low priority):
- [area name] ([id]) — [status] — score: [score]

[Omit Phase 3b if no deprioritized gaps exist.]

[If foundation gaps exist alongside present core areas:]
⚠ Warning: You have Core knowledge but missing Foundation prerequisites.
The Core knowledge may be internally inconsistent without [Foundation area names].
Prioritize Foundation gaps before building on Core.

Results written to docs/context-library/wizard-config.json
```

**If everything is present and fresh:**

```
✓ Clean bill of health — your library covers all [N] recommended areas.
No gaps detected. Consider scheduling a refresh review in [3 months].

Results written to docs/context-library/wizard-config.json
```

After presenting the summary (whether there are gaps or not), proceed automatically to Step 6.

---

### Step 6: Assessment Document & Solicitation Prompts

Generate a human-readable assessment document with impact statements and solicitation prompts
for each gap. This step runs automatically after Step 5, or can be re-run independently
against an existing `docs/context-library/wizard-config.json` that contains gap analysis data.

#### 6a: Load Gap Analysis

If running independently (not immediately after Step 5), load the gap analysis:

```
Read docs/context-library/wizard-config.json from the target project.
Verify it contains a gap_analysis section. If not, tell the user to run
the gap analysis first (Step 5).
```

Extract: mode, novelty, complexity, gaps array, sequence, and summary.

#### 6b: Generate Impact Statements

For each gap (where action != "none"), generate a mode-sensitive impact statement.

Read the area's `when_missing` text from `${CLAUDE_PLUGIN_ROOT}/docs/wizard/wizard-engine.yaml`
(the catalog section) and the mode narrative from the `mode_narratives` section.

Use these templates based on the area's tier:

**Foundation gap:**
> Without [area name], [when_missing text]. At [mode label] mode, this means
> [mode-specific consequence derived from the mode narrative risk]. This is a
> Foundation gap — other knowledge areas depend on it for coherence. Seed this first.

**Core gap:**
> [When_missing text]. For your [novelty]-novelty, [complexity]-complexity product
> at [mode label] mode, this is a primary value driver — [explain why this area is
> Core at this configuration, referencing the sensitivity that elevated it].

**Amplifier gap:**
> [When_missing text]. This area multiplies the effectiveness of your Foundation and
> Core knowledge. With [area name] in place, [describe the specific amplification
> effect for this area].

**Deprioritized gap:**
> [When_missing text]. At your configuration ([novelty] novelty, [complexity]
> complexity), this is lower priority because [explain why the sensitivity profiles
> place it here]. Seed this after higher-priority areas are in place.

The impact statements should be specific to the team's configuration, not generic.
Combine the `when_missing` text with the mode narrative to explain the concrete risk.

#### 6c: Select Solicitation Prompts

For each gap, select the appropriate solicitation prompt from
`${CLAUDE_PLUGIN_ROOT}/docs/wizard/phase-6-intake-engine.md` (the "Solicitation Prompt
Library" section).

Each area has:
- A **base solicitation prompt** (always present)
- **Mode variants** (some areas have variants for Short-Order Cook, Pair Programmer,
  and/or Factory modes)
- **"What good looks like"** benchmark
- **"Common pitfall"** warning

**Mode variant selection rules:**
- If the area has a variant that matches the user's mode, use it instead of the base prompt
- Some variants cover multiple modes (e.g., "Short-Order Cook / Pair Programmer") — use
  these when the user's mode is listed
- If no variant matches, use the base prompt
- Area 1.2 (Product Strategy) has a "Thesis nudge" — include it as additional guidance

#### 6d: Write Assessment Document

Write `docs/context-library/assessment.md` in the target project following the template
from `${CLAUDE_PLUGIN_ROOT}/docs/wizard/intake-output-template.md`.

The document has these sections:

**1. Header:**
```markdown
# Context Library Assessment

**Configuration:** [Mode label] × [Novelty] Novelty × [Complexity] Complexity
**Pool:** [N] knowledge areas | **Gaps:** [N] to create, [N] to refresh, [N] complete
```

**2. Risk statement:**
```markdown
## Your Library's Risk

> [Mode narrative risk from wizard-engine.yaml]

[1-2 sentences explaining what this means for this specific configuration.]
```

**3. Seeding sequence** (phased tables with impact statements):

Only include phases that have gaps. The phases are:
- Phase 1: Foundation Gaps
- Phase 2: Core Gaps
- Phase 3: Amplifier Gaps
- Phase 3b: Deprioritized Gaps (only if deprioritized gaps exist)

Each phase shows:

```markdown
### Phase [N]: [Tier] Gaps

[Phase description]

| Priority | Area | Status | Action | Impact |
|---|---|---|---|---|
| [rank] | [Name] ([id]) | [status] | [action] | [impact statement] |
```

Phase 4 (Already Covered) always appears if any areas have action = "none":

```markdown
### Phase 4: Already Covered

| Area | Status | Last Refreshed |
|---|---|---|
| [Name] ([id]) | Present | [Date or "Current"] |
```

**4. Solicitation prompts** (one per gap, ordered by priority):

```markdown
## Solicitation Prompts

### [Area Name] ([id]) — [Action: Create/Update/Refresh]

> [Solicitation prompt — base or mode variant as selected in 6c]

**What good looks like:** [benchmark text from spec]

**Common pitfall:** [pitfall text from spec]
```

**If everything is present and fresh** (no gaps), write a shorter document:

```markdown
# Context Library Assessment

**Configuration:** [Mode label] × [Novelty] Novelty × [Complexity] Complexity
**Pool:** [N] knowledge areas | **Gaps:** 0 to create, 0 to refresh, [N] complete

## Your Library's Risk

> [Mode narrative risk]

[Explanation]

## Status: Clean Bill of Health

Your library covers all [N] recommended knowledge areas. No gaps detected.

Consider scheduling a refresh review in 3 months to ensure documentation stays
current as your product evolves.

### All Areas

| Area | Status |
|---|---|
| [Name] ([id]) | Present |
```

#### 6e: Present Summary

After writing the assessment document:

**If there are gaps:**

```
Assessment written to docs/context-library/assessment.md

[N] solicitation prompts ready for:
- Phase 1 (Foundation): [area names]
- Phase 2 (Core): [area names]
- Phase 3 (Amplifier): [area names]
- Phase 3b (Deprioritized): [area names]

[Omit Phase 3b if no deprioritized gaps exist.]

Next: Work through the solicitation prompts with your team, starting with
Foundation gaps. Add responses to docs/context-library/sources/ and then
ask Conan to inventory them.
```

**If clean bill of health:**

```
Assessment written to docs/context-library/assessment.md

✓ Clean bill of health — no solicitation prompts needed.
Consider scheduling a refresh review in 3 months.
```
