## Context Library Workflow

When touching product concepts (features, components, systems, agents):

- Search cards in `docs/context-library/` first.
- For complex work, use the Conan agent (`${CLAUDE_PLUGIN_ROOT}/agents/conan.md`) to assemble a context briefing.
- After structural library changes, run Conan Downstream Sync (Job 9).

Quick lookup:

- Find cards: `docs/context-library/**/[Type] - [Name].md`
- Search topic: `rg <term> docs/context-library`
